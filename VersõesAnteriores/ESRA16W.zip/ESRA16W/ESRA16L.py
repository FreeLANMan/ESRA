# -*- coding: UTF-8 -*-
# Versão Linux
# Copyright 2012, 2016 Carlos Adrian Rupp
#from __future__ import unicode_literals
import sqlite3
from random import *

# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

# ESRA versão 2016
# objetivo: Reformulação geral do sistema para superar limites e apresentar raciocinios mais complexos
# está apagando a memória em cada inicialização pois está em versão testes

# Indice:
# 168 - entradas do usuario
# 506 - PERGUNTAS DO USUARIO
# 1066 - RACIOCÍNIOS E RESPOSTA A 'O QUE PENSA SOBRE'
# 1260 - raciocinios
# 1545 - raciocínios de nível 3
# 2492 - Raciocinios nível 2
# 3070 - Perguntas ao usuário

# Variáveis
# entendi = quando 1 significa que o sistema identificou a entrada do usuário
# sei = quando for perguntado e souber sobre um assunto
# pergunta = 1 significa q foi perguntado o q pensa sobre algo
# resposta = variável onde fica as frases raiocinadas pelo sistema
# anterior = guarda a resposta q ele acabou de dar

diga = "oi"
conn=sqlite3.connect('memoria.db')
cursor=conn.cursor()

# apaga as tabelas anteriores:
#cursor.execute("DROP TABLE IF EXISTS memo1")
#cursor.execute("DROP TABLE IF EXISTS memo2")
#cursor.execute("DROP TABLE IF EXISTS memo3")
#cursor.execute("DROP TABLE IF EXISTS memo4")
#cursor.execute("DROP TABLE IF EXISTS memo5")
#cursor.execute("DROP TABLE IF EXISTS memo6")
#cursor.execute("DROP TABLE IF EXISTS memo7")
#cursor.execute("DROP TABLE IF EXISTS memo8")
#cursor.execute("DROP TABLE IF EXISTS memo9")
#cursor.execute("DROP TABLE IF EXISTS memo10")

#sql1 = tabela de categorias femininas 
#sql1 = """CREATE TABLE MEMO1 (
#          item  CHAR(100) NOT NULL,
#          categ  CHAR(100) NOT NULL)"""
# sql2 = tabela de categorias masculinas
#sql2 = """CREATE TABLE MEMO2 (
#          item  CHAR(100) NOT NULL,
#          categ  CHAR(100) NOT NULL)"""
## sql3 = tabela de itens femininos negados
#sql3 = """CREATE TABLE MEMO3 (
#          item  CHAR(100) NOT NULL,
#          categ  CHAR(100) NOT NULL)"""
# sql4 = tabela de itens masculinos negados
##sql4 = """CREATE TABLE MEMO4 (
##          item  CHAR(100) NOT NULL,
#          categ  CHAR(100) NOT NULL)"""
# sql5 = tabela de sinonimos
#sql5 = """CREATE TABLE MEMO5 (
##          item  CHAR(100) NOT NULL,
#          sinon  CHAR(100) NOT NULL)"""
# sql6 = tabela de sinonimos negados
#sql6 = """CREATE TABLE MEMO6 (
#          item  CHAR(100) NOT NULL,
#          sinon  CHAR(100) NOT NULL)"""
# sql7 = tabela de possibilidades
#sql7 = """CREATE TABLE MEMO7 (
#          item  CHAR(100) NOT NULL,
#          pode  CHAR(100) NOT NULL)"""
# sql8 = tabela de possibilidades negadas
#sql8 = """CREATE TABLE MEMO8 (
#          item  CHAR(100) NOT NULL,
#          pode  CHAR(100) NOT NULL)"""
#Cria tabela de itens hierarquicos
#cursor.execute("CREATE TABLE MEMO9 (parte1 CHAR(100),conectivo CHAR(30),parte2 CHAR(100))")
#Cria tabela de NEGAÇÃO de itens hierarquicos
#cursor.execute("CREATE TABLE MEMO10 (parte1 CHAR(100),conectivo CHAR(30),parte2 CHAR(100))")
#Cria tabela de conclusões
#cursor.execute("CREATE TABLE MEMO10 (nivel INT,parte1 CHAR(100),conectivo CHAR(25),parte2 CHAR(100))")

# Cria a tabela de categorias masculinas no banco de dados
#cursor.execute(sql1)
# Cria a tabela para categorias femininas no banco de dados
#cursor.execute(sql2)
# Cria a tabela para categorias femininas negadas no banco de dados
#cursor.execute(sql3)
# Cria a tabela para categorias masculinas negadas no banco de dados
#cursor.execute(sql4)
# Cria a tabela para sinonimos
#cursor.execute(sql5)
# Cria a tabela para sinonimos negados
#cursor.execute(sql6)
# Cria a tabela para possibilidades
#cursor.execute(sql7)
# Cria a tabela para possibilidades negadas
#cursor.execute(sql8)

# Mensagens iniciais para o usuário:
print "   "
print "   "
print "   "
print "   "
print "   "
print "Olá, bem vindo ao ESRA (Esboço de Sistema de Raciocinio Artificial)"
print "Versão 2016 - Para Linux"
print "Copyright 2012, 2016 Adrian Rupp"
print "   "
print "Instruções:"
print "   "
print "- Não use apóstrofos ', ponto final, de exclamação, de interrogação e não inicie frases com letra maiuscúla"
print "- Evite usar artigos (o, a, um, umas, etc.)"
print " "
print "- O ESRA está identificando essas frases: "
print "    x é um y - como: maçã é uma fruta, para associar um item a uma categoria"
print "    x é igual a y - como: bergamota é igual a tangerina, para sinônimos"
print "    x pode y - como: maçã pode ser podre, para possibilidades"
print "    x não é um y; x não é igual a y; x não pode y; para negar"
print "    O que sabe sobre x - para ele repetir o que foi dito sobre um assunto"
print "    O que pensa sobre x - para ele dar suas conclusões sobre um assunto"
print "    fui - para sair do programa"
print " "
print "Para mais detalhes veja o arquivo 'Manual.odt'"
anterior = " "
print " "

# testa se o banco de dados está vazio
cursor.execute("SELECT * FROM memo1")
conteudo = cursor.fetchone()
if conteudo is None:
  cursor.execute("SELECT * FROM memo2")
  conteudo = cursor.fetchone()
  if conteudo is None:
    cursor.execute("SELECT * FROM memo3")
    conteudo = cursor.fetchone()
    if conteudo is None:
      cursor.execute("SELECT * FROM memo4")
      conteudo = cursor.fetchone()
      if conteudo is None:
	cursor.execute("SELECT * FROM memo5")
	conteudo = cursor.fetchone()
	if conteudo is None:
	  cursor.execute("SELECT * FROM memo6")
	  conteudo = cursor.fetchone()
	  if conteudo is None:
	    cursor.execute("SELECT * FROM memo7")
	    conteudo = cursor.fetchone()
	    if conteudo is None:
	      cursor.execute("SELECT * FROM memo8")
	      conteudo = cursor.fetchone()
	      if conteudo is None:
		cursor.execute("SELECT * FROM memo9")
	        conteudo = cursor.fetchone()
	        if conteudo is None:
		  cursor.execute("SELECT * FROM memo10")
	          conteudo = cursor.fetchone()
	          if conteudo is None:
		    print "ATENÇÃO! Memória vazia!"
		
while diga != "fui":
  print " "
  entendi = 0
  achou = 0
  achou2 = 0
  achou3 = 0
  # achou4 = 1 significa que o sistema achou uma analogia
  achou4 = 0
  falei = 0
  pergunta = " "
  
  rndfive = randint(0, 2)
  if rndfive == 0 or rndfive == 1:
      palpite = 'desconfio que'
  if rndfive == 2:
      palpite = 'acho que'
#  if rndfive == 3:
#      palpite = 'suponho que'
#  if rndfive == 4:
#      palpite = 'penso que'
  
  diga1 = "   "
  diga2 = "   "
  # pegar a entrada do usuário:
  diga=raw_input("Diga: ")
  #.decode('utf-8')
  print " "
  
  # evitar que tenha mais de um 'é' na frase
  if (diga.count(' pode ') >= 2):
    print "- Não consigo identificar frases que tenham mais de um 'pode'"
  
 
  elif 'pare de memorizar' == diga:
    conn.commit()
    cursor.close()
    conn.close()      
    conn=sqlite3.connect(':memory:')
    cursor=conn.cursor()
    print "- OK! Não memorizarei as próximas frases ditas"
    falei = 1
    cursor.execute("CREATE TABLE MEMO1 (item  CHAR(100) NOT NULL,categ  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO2 (item  CHAR(100) NOT NULL,categ  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO3 (item  CHAR(100) NOT NULL,categ  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO4 (item  CHAR(100) NOT NULL,categ  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO5 (item  CHAR(100) NOT NULL,sinon  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO6 (item  CHAR(100) NOT NULL,sinon  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO7 (item  CHAR(100) NOT NULL,pode  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO8 (item  CHAR(100) NOT NULL,pode  CHAR(100) NOT NULL)")
    cursor.execute("CREATE TABLE MEMO9 (parte1 CHAR(100),conectivo CHAR(30),parte2 CHAR(100))")
    cursor.execute("CREATE TABLE MEMO10 (parte1 CHAR(100),conectivo CHAR(30),parte2 CHAR(100))")


  # +++++++++++++++++++++++++++++++++++++++++++++++++
  # + IDENTIFICANDO E GRAVANDO ENTRADAS DO USUARIO  +
  # +++++++++++++++++++++++++++++++++++++++++++++++++

  # Maior antes da menor
  
  

  # buscar conectivo 'não é igual a' na entrada e repartir em 2as partes:
  elif ' não é igual a ' in diga:
    parte1, parte2 = diga.split(' não é igual a ')
    achou = 0        
    entendi = 1
    # Busca por catega e parte1 na memória, se não achou adiciona item
    for linha in cursor.execute("SELECT * FROM memo5"):
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))):
	cursor.execute("DELETE FROM memo5 WHERE item = '%s' AND sinon = '%s'" %(parte1, parte2))
      elif ((parte1 == linha[1].encode('utf-8')) and (parte2 == linha[0].encode('utf-8'))):
	cursor.execute("DELETE FROM memo5 WHERE item = '%s' AND sinon = '%s'" %(parte1, parte2))
	#print "linha já gravada antes, mas apagada agora"
    cursor.execute("SELECT * FROM memo6")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))) or ((parte1 == linha[1].encode('utf-8')) and (parte2 == linha[0].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo6(item, sinon) VALUES('%s', '%s')" %(parte1, parte2))
          #print "linha nova gravada"
          conn.commit()

  # buscar conectivo 'é igual a' na entrada e repartir em 2as partes:
  elif ' é igual a ' in diga:
    parte1, parte2 = diga.split(' é igual a ')
    achou = 0        
    entendi = 1
    # Busca por catega e parte1 na memória, se não achou adiciona item
    cursor.execute("SELECT * FROM memo6")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))):
	cursor.execute("DELETE FROM memo6 WHERE item = '%s' AND sinon = '%s'" %(parte1, parte2))
      elif ((parte1 == linha[1].encode('utf-8')) and (parte2 == linha[0].encode('utf-8'))):
	cursor.execute("DELETE FROM memo6 WHERE item = '%s' AND sinon = '%s'" %(parte2, parte1))
	#print "linha já gravada antes, mas apagada agora"
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))) or ((parte1 == linha[1].encode('utf-8')) and (parte2 == linha[0].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo5(item, sinon) VALUES('%s', '%s')" %(parte1, parte2))
          #print "linha nova gravada"
          conn.commit()

  # buscar conectivo 'não é uma' na entrada e repartir em 2as partes:
  elif ' não é uma ' in diga:
    parte1, catega = diga.split(' não é uma ')
    achou = 0        
    entendi = 1
    # Busca por catega e parte1 na memória, se achou deleta item
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	cursor.execute("DELETE FROM memo1 WHERE item = '%s' AND categ = '%s'" %(parte1, catega))
	#print "linha já gravada antes, mas apagada agora"
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
      #print "percorrendo a memória"
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	#print "linha já gravada antes"
	achou = 1
    if achou == 0:
      cursor.execute("INSERT INTO memo3(item, categ) VALUES('%s', '%s')" %(parte1, catega))
      #print "linha nova gravada"
      conn.commit()

  # buscar conectivo 'é uma' na entrada e repartir em 2as partes:
  elif ' não é um ' in diga:
    parte1, catega = diga.split(' não é um ')
    achou = 0        
    entendi = 1
    # Busca por catega e parte1 na memória, se não achou adiciona item
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	cursor.execute("DELETE FROM memo2 WHERE item = '%s' AND categ = '%s'" %(parte1, catega))
	#print "linha já gravada antes, mas apagada agora"
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
      #print "percorrendo a memória"
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	#print "linha já gravada antes"
	achou = 1
    if achou == 0:
      cursor.execute("INSERT INTO memo4(item, categ) VALUES('%s', '%s')" %(parte1, catega))
      #print "linha nova gravada"
      conn.commit()

  # buscar conectivo 'é uma' na entrada e repartir em 2as partes:
  elif ' é uma ' in diga:
    parte1, catega = diga.split(' é uma ')
    achou = 0        
    entendi = 1
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	cursor.execute("DELETE FROM memo3 WHERE item = '%s' AND categ = '%s'" %(parte1, catega))
	#print "linha já gravada antes, mas apagada agora"
    # Busca por catega e parte1 na memória, se não achou adiciona item
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      #print "percorrendo a memória"
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	#print "linha já gravada antes"
	achou = 1
    if achou == 0:
      cursor.execute("INSERT INTO memo1(item, categ) VALUES('%s', '%s')" %(parte1, catega))
      #print "linha nova gravada"
      conn.commit()
      
  # buscar conectivo 'é um' na entrada e repartir em 2as partes:
  elif ' é um ' in diga:
    parte1, catego = diga.split(' é um ')
    achou = 0        
    entendi = 1
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
      if (parte1 == linha[0].encode('utf-8')) and (catega == linha[1].encode('utf-8')):
	cursor.execute("DELETE FROM memo4 WHERE item = '%s' AND categ = '%s'" %(parte1, catego))
	#print "linha já gravada antes, mas apagada agora"
    # Busca por catega e parte1 na memória, se não achou adiciona item
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:  
      if parte1 == linha[0].encode('utf-8') and catego == linha[1].encode('utf-8'):
	#print "linha já gravada antes"
        achou = 1
    if achou == 0:
      cursor.execute("INSERT INTO memo2(item, categ) VALUES('%s', '%s')" %(parte1, catego))
      #print "linha nova gravada"
      conn.commit()

  # buscar conectivo 'não pode' na entrada e repartir em 2as partes:
  elif ' não pode ' in diga:
    parte1, parte2 = diga.split(' não pode ')
    achou = 0        
    entendi = 1
    # Busca por catega e parte1 na memória, se não achou adiciona item
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))):
	cursor.execute("DELETE FROM memo7 WHERE item = '%s' AND pode = '%s'" %(parte1, parte2))
	#print "linha já gravada antes, mas apagada agora"
    cursor.execute("SELECT * FROM memo8")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo8(item, pode) VALUES('%s', '%s')" %(parte1, parte2))
          #print "linha nova gravada"
          conn.commit()

  # buscar conectivo 'pode' na entrada e repartir em 2as partes:
  elif ' pode ' in diga:
    parte1, parte2 = diga.split(' pode ')
    achou = 0        
    entendi = 1
    # Busca por catega e parte1 na memória, se não achou adiciona item
    cursor.execute("SELECT * FROM memo8")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))):
	cursor.execute("DELETE FROM memo8 WHERE item = '%s' AND pode = '%s'" %(parte1, parte2))
	#print "linha já gravada antes, mas apagada agora"
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if ((parte1 == linha[0].encode('utf-8')) and (parte2 == linha[1].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo7(item, pode) VALUES('%s', '%s')" %(parte1, parte2))
          #print "linha nova gravada"
          conn.commit()

  # buscar conectivo 'NÃO foi depois d' na entrada e repartir em 2as partes:
  elif ' não foi depois do ' in diga or ' não foi depois de ' in diga or ' não foi depois da ' in diga:
    achou = 0        
    entendi = 1
    conectivo = "foi depois d"
    if ' não foi depois de ' in diga:
      parte1, parte2 = diga.split(' não foi depois de ')
    elif ' não foi depois da ' in diga:
      parte1, parte2 = diga.split(' não foi depois da ')
    elif ' não foi depois do ' in diga:
      parte1, parte2 = diga.split(' não foi depois do ')
      
    # Busca por parte1 e parte2 na memória, se não achou adiciona item
    for linha in cursor.execute("SELECT * FROM memo9"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	cursor.execute("DELETE FROM memo9 WHERE parte1 = '%s' AND conectivo = '%s' AND parte2 = '%s'" %(parte1, conectivo, parte2))
    for linha in cursor.execute("SELECT * FROM memo10"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo10(parte1, conectivo, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
          conn.commit()

  # buscar conectivo 'NÃO foi ANTES d' na entrada e repartir em 2as partes:
  elif ' não foi antes do ' in diga or ' não foi antes de ' in diga or ' não foi antes da ' in diga:
    achou = 0        
    entendi = 1
    conectivo = "foi antes d"
    if ' não foi antes de ' in diga:
      parte1, parte2 = diga.split(' não foi antes de ')
    elif ' não foi antes da ' in diga:
      parte1, parte2 = diga.split(' não foi antes da ')
    elif ' não foi antes do ' in diga:
      parte1, parte2 = diga.split(' não foi antes do ')
      
    # Busca por parte1 e parte2 na memória, se não achou adiciona item
    for linha in cursor.execute("SELECT * FROM memo9"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	cursor.execute("DELETE FROM memo9 WHERE parte1 = '%s' AND conectivo = '%s' AND parte2 = '%s'" %(parte1, conectivo, parte2))
    for linha in cursor.execute("SELECT * FROM memo10"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo10(parte1, conectivo, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
          conn.commit()

  # buscar conectivo 'foi depois d' na entrada e repartir em 2as partes:
  elif ' foi depois do ' in diga or ' foi depois de ' in diga or ' foi depois da ' in diga:
    achou = 0        
    entendi = 1
    conectivo = "foi depois d"
    if ' foi depois de ' in diga:
      parte1, parte2 = diga.split(' foi depois de ')
    elif ' foi depois da ' in diga:
      parte1, parte2 = diga.split(' foi depois da ')
    elif ' foi depois do ' in diga:
      parte1, parte2 = diga.split(' foi depois do ')
      
    # Busca por parte1 e parte2 na memória, se não achou adiciona item
    for linha in cursor.execute("SELECT * FROM memo10"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	cursor.execute("DELETE FROM memo10 WHERE parte1 = '%s' AND conectivo = '%s' AND parte2 = '%s'" %(parte1, conectivo, parte2))
    for linha in cursor.execute("SELECT * FROM memo9"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo9(parte1, conectivo, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
          conn.commit()

  # buscar conectivo 'foi ANTES d' na entrada e repartir em 2as partes:
  elif ' foi antes do ' in diga or ' foi antes de ' in diga or ' foi antes da ' in diga:
    achou = 0        
    entendi = 1
    conectivo = "foi antes d"
    if ' foi antes de ' in diga:
      parte1, parte2 = diga.split(' foi antes de ')
    elif ' foi antes da ' in diga:
      parte1, parte2 = diga.split(' foi antes da ')
    elif ' foi antes do ' in diga:
      parte1, parte2 = diga.split(' foi antes do ')
      
    # Busca por parte1 e parte2 na memória, se não achou adiciona item
    for linha in cursor.execute("SELECT * FROM memo10"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	cursor.execute("DELETE FROM memo10 WHERE parte1 = '%s' AND conectivo = '%s' AND parte2 = '%s'" %(parte1, conectivo, parte2))
    for linha in cursor.execute("SELECT * FROM memo9"):
      if ((parte1 == linha[0].encode('utf-8')) and (conectivo == linha[1].encode('utf-8')) and (parte2 == linha[2].encode('utf-8'))):
	achou = 1
    if achou == 0:
	  cursor.execute("INSERT INTO memo9(parte1, conectivo, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
          conn.commit()





  # ++++++++++++++++++++++++
  # + PERGUNTAS DO USUARIO +
  # ++++++++++++++++++++++++

  #imprime o que sabe sobre a expressão 
  elif 'o que sabe sobre ' in diga:
    entendi = 1
    sei = 0
    pontos = 0
    tab1 = 0
    tab2 = 0
    tab5 = 0
    tab7 = 0
    tab9 = 0
    tem = 0
    conta1 = -1
    diga1,diga2 = diga.split('o que sabe sobre ')
    
    # Busca nas categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      # educação é um processo de formação
      # se " processo" em ... ou "educação" em .... ou 
      if " "+diga2 in linha[0].encode('utf-8') or diga2 == linha[0].encode('utf-8') or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "é uma", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab1 = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "é uma", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab1 = 1

    # Busca nas categorias masculinas
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "é um", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab2 = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "é um", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab2 = 1
        
    # Busca nas negações de itens femininos
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não é uma", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não é uma", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1

    # Busca nas negações de itens masculinos
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não é um", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não é um", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1

    # Busca nos sinonimos
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "é igual a", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab5 = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[1].encode('utf-8'), "é igual a", linha[0].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab5 = 1

    # Busca na negação dos sinonimos
    cursor.execute("SELECT * FROM memo6")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não é igual a", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[1].encode('utf-8'), "não é igual a", linha[0].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1

    # Busca nas possibilidades
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "pode", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab7 = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "pode", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab7 = 1
        
    # Busca nas possibilidades negadas
    cursor.execute("SELECT * FROM memo8")
    for linha in cursor:
      #print linha
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não pode", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
      elif (" "+diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
        print " -",linha[0].encode('utf-8'), "não pode", linha[1].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1

    # Busca na tabela das hierarquias
    for linha in cursor.execute("SELECT * FROM memo9"):
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " - "+linha[0].encode('utf-8')+" "+linha[1].encode('utf-8')+"e "+linha[2].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab9 = 1
      elif (" "+diga2 in linha[2].encode('utf-8')) or (diga2 == linha[2].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
	print " - "+linha[0].encode('utf-8')+" "+linha[1].encode('utf-8')+"e "+linha[2].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
        tab9 = 1

    # Busca na tabela das hierarquias NEGADAS
    for linha in cursor.execute("SELECT * FROM memo10"):
      if (" "+diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or " "+diga2 in " "+linha[0].encode('utf-8'):
        print " - "+linha[0].encode('utf-8')+" não "+linha[1].encode('utf-8')+"e "+linha[2].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1
      elif (" "+diga2 in linha[2].encode('utf-8')) or (diga2 == linha[2].encode('utf-8')) or " "+diga2 in " "+linha[1].encode('utf-8'):
	print " - "+linha[0].encode('utf-8')+" não "+linha[1].encode('utf-8')+"e "+linha[2].encode('utf-8')
        pontos = pontos + 1
        sei = 1
        falei = 1



    # Respondendo com nivel 2 de profundidade 222222222222222222222222222222 2222222222222222222222222222222222222222222222222
    if sei == 1:
      print "   "
      print "  - Outras informações relacionadas:"
      resposta = "   "
      achei = 0

      # Conta as expressões relacionadas que estão em cada tabela 

      # Se na tabela1 tinha coisas...
      if tab1 == 1:
	cursor.execute("SELECT * FROM memo1")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nos itens
	  if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	    conta1 = conta1 + 1
	cursor.execute("SELECT * FROM memo1")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nas categorias
	  if (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	    conta1 = conta1 + 1

      # Se na tabela2 tinha coisas...
      if tab2 == 1:
	cursor.execute("SELECT * FROM memo2")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nos itens
	  if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	    conta1 = conta1 + 1
	cursor.execute("SELECT * FROM memo2")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nas categorias
	  if (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	    conta1 = conta1 + 1

      # Se na tabela5 tinha coisas...
      if tab5 == 1:
	cursor.execute("SELECT * FROM memo5")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nos itens
	  if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	    conta1 = conta1 + 1
	cursor.execute("SELECT * FROM memo5")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nas categorias
	  if (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	    conta1 = conta1 + 1
	    
      # Se na tabela7 tinha coisas...
      if tab7 == 1:
	cursor.execute("SELECT * FROM memo7")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nos itens
	  if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	    conta1 = conta1 + 1
	cursor.execute("SELECT * FROM memo7")
	for linha in cursor:
	  #conta quantas vezes a expressão buscada aparece nas categorias
	  if (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	    conta1 = conta1 + 1
	    
      # Se na tabela9 tinha coisas...
      if tab9 == 1:
	#conta quantas vezes a expressão buscada aparece na parte1
	for linha in cursor.execute("SELECT * FROM memo9"):
	  if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	    conta1 = conta1 + 1
	#conta quantas vezes a expressão buscada aparece na parte2
	for linha in cursor.execute("SELECT * FROM memo9"):
	  if (diga2 in linha[2].encode('utf-8')) or (diga2 == linha[2].encode('utf-8')):
	    conta1 = conta1 + 1

      conta1 = conta1 + 2
      lista1 = range(conta1)
      x = -1
      #print "expressões relacionadas:",conta1
      #print "expressões relacionadas:",lista1
      
      # salva numa lista as expressões relacionadas de cada tabela

      for linha in cursor.execute("SELECT * FROM memo1"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[1].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[1].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	    elif (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[0].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[0].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1

      for linha in cursor.execute("SELECT * FROM memo2"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[1].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[1].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	    elif (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[0].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[0].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	        
      for linha in cursor.execute("SELECT * FROM memo5"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[1].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[1].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	    elif (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[0].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[0].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	        
      for linha in cursor.execute("SELECT * FROM memo7"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[1].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[1].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	    elif (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[0].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[0].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1

      for linha in cursor.execute("SELECT * FROM memo9"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		  if linha[1].encode('utf-8') == lista1[y]:
		    achei = 1
              if achei == 0:
		lista1[x+1] = linha[1].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1
	    elif (diga2 in linha[2].encode('utf-8')) or (diga2 == linha[2].encode('utf-8')):
	      for y in range(conta1):
		if type(lista1[y]) is str:
		 if linha[0].encode('utf-8') == lista1[y]:
		  achei = 1
              if achei == 0:
		lista1[x+1] = linha[0].encode('utf-8')
	        #print "item q foi pra lista1:",linha[1].encode('utf-8')
	        x = x + 1

      # Busca em cada tabela as expressões da lista1
      
      #for x in range(conta1):
      #  print "expressões relacionadas: ",lista1[x],
      
      #print "   "

      # Busca por cada expressão relacionada na tabela1
      for x in range(conta1):
	  for linha in cursor.execute("SELECT * FROM memo1"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" é uma "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" é uma "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela2
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo2"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" é um "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" é um "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela3
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo3"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" não é uma "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" não é uma "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela4
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo4"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" não é um "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" não é um "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela5
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo5"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" é igual a "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" é igual a "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela6
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo6"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" não é igual a "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" não é igual a "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela7
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo7"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" pode "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" pode "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	      
      # Busca por cada expressão na tabela8
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo8"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')) or (diga2 == linha[1].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" não pode "+linha[1].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[1].encode('utf-8')) or (lista1[x] == linha[1].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" não pode "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	     
      # Busca por cada expressão na tabela9
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo9"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[2].encode('utf-8')) or (diga2 == linha[2].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" "+linha[1].encode('utf-8')+"e "+linha[2].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[2].encode('utf-8')) or (lista1[x] == linha[2].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" "+linha[1].encode('utf-8')+"e "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

      # Busca por cada expressão na tabela10
      for x in range(conta1):
	  #print lista1[x]
	  for linha in cursor.execute("SELECT * FROM memo10"):
	    if (diga2 in linha[0].encode('utf-8')) or (diga2 == linha[0].encode('utf-8')) or (diga2 in linha[2].encode('utf-8')) or (diga2 == linha[2].encode('utf-8')):
	      # frase repetida
	      achei = 1
	    elif (lista1[x] == linha[0].encode('utf-8')) or (lista1[x] == linha[0].encode('utf-8')):
	      resposta = "    - "+lista1[x]+" não "+linha[1].encode('utf-8')+"e "+linha[2].encode('utf-8')
	      print resposta
	      pontos = pontos + 1
	      tem = 1
	    elif (lista1[x] == linha[2].encode('utf-8')) or (lista1[x] == linha[2].encode('utf-8')):
	      resposta = "    - "+linha[0].encode('utf-8')+" não "+linha[1].encode('utf-8')+"e "+lista1[x]
	      print resposta
	      pontos = pontos + 1
	      tem = 1

    if tem == 0:
      print "  - Não encontrei informações relacionadas"
      falei = 1


    if sei == 0:
      print " - não sei sobre isso"
      falei = 1

    if pontos > 0:
      print " "
      print "(Assunto: "+diga2+" Pontos: ",pontos,")"
      falei = 1





  # ++++++++++++++++++++++++++++++++++++++++++++++++
  # + RACIOCÍNIOS E RESPOSTA A 'O QUE PENSA SOBRE' +
  # ++++++++++++++++++++++++++++++++++++++++++++++++
  
  elif ('o que pensa sobre ' in diga):
      pergunta = 1     
      diga1,diga2 = diga.split('o que pensa sobre ')
  
  if diga != "fui":
    #falei = 0

    # Identificando contradições ########################################

    # NÍVEL 3
    
    # contradições partindo de 'x é igual a y'
    
    # Procurar o digitado nos sinonimos e salva se achou
    item1 = "   "
    item2 = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8') == diga) or (diga2 in linha[0].encode('utf-8')) or (diga2 in linha[1].encode('utf-8')):
	item1 = linha[0].encode('utf-8')
        item2 = linha[1].encode('utf-8')

    # procurar por item1 e item2 nos itens das categorias femininas
    link1 = "   "
    achei = 0
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if item1 == linha[0].encode('utf-8'):
	link1 = linha[1].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das categorias femininas
      for linha in cursor.execute("SELECT * FROM memo3"):
	if item2 == linha[0].encode('utf-8') and link1 == linha[1].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+item1+" é uma "+link1
	  resposta3 = " - "+item2+" não é uma "+link1
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if item2 == linha[0].encode('utf-8'):
	link1 = linha[1].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das categorias femininas
      for linha in cursor.execute("SELECT * FROM memo3"):
	if item1 == linha[0].encode('utf-8') and link1 == linha[1].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+item2+" é uma "+link1
	  resposta3 = " - "+item1+" não é uma "+link1
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1

    # procurar por categorias femininas contraditórias
    link1 = "   "
    achei = 0
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if item1 == linha[1].encode('utf-8'):
	link1 = linha[0].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das categorias femininas
      for linha in cursor.execute("SELECT * FROM memo3"):
	if item2 == linha[1].encode('utf-8') and link1 == linha[0].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+link1+" é uma "+item1
	  resposta3 = " - "+link1+" não é uma "+item2
	  
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if item2 == linha[1].encode('utf-8'):
	link1 = linha[0].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre as categorias femininas
      for linha in cursor.execute("SELECT * FROM memo3"):
	if item1 == linha[1].encode('utf-8') and link1 == linha[0].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+link1+" é uma "+item2
	  resposta3 = " - "+link1+" não é uma "+item1
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1

    # procurar por item1 e item2 nos itens das categorias masculinas
    link1 = "   "
    achei = 0
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if item1 == linha[0].encode('utf-8'):
	link1 = linha[1].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das categorias masculinas
      for linha in cursor.execute("SELECT * FROM memo4"):
	if item2 == linha[0].encode('utf-8') and link1 == linha[1].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+item1+" é um "+link1
	  resposta3 = " - "+item2+" não é um "+link1
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if item2 == linha[0].encode('utf-8'):
	link1 = linha[1].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das categorias femininas
      for linha in cursor.execute("SELECT * FROM memo4"):
	if item1 == linha[0].encode('utf-8') and link1 == linha[1].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+item2+" é um "+link1
	  resposta3 = " - "+item1+" não é um "+link1
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1

    # procurar por categorias masculinas contraditórias
    link1 = "   "
    achei = 0
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if item1 == linha[1].encode('utf-8'):
	link1 = linha[0].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das categorias femininas
      for linha in cursor.execute("SELECT * FROM memo4"):
	if item2 == linha[1].encode('utf-8') and link1 == linha[0].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+link1+" é um "+item1
	  resposta3 = " - "+link1+" não é um "+item2
	  
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if item2 == linha[1].encode('utf-8'):
	link1 = linha[0].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre as categorias femininas
      for linha in cursor.execute("SELECT * FROM memo4"):
	if item1 == linha[1].encode('utf-8') and link1 == linha[0].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+link1+" é um "+item2
	  resposta3 = " - "+link1+" não é um "+item1
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1

    # procurar por item1 e item2 nas possibilidades
    link1 = "   "
    achei = 0
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if item1 == linha[0].encode('utf-8'):
	link1 = linha[1].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das possibilidas
      for linha in cursor.execute("SELECT * FROM memo8"):
	if item2 == linha[0].encode('utf-8') and link1 == linha[1].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+item1+" pode "+link1
	  resposta3 = " - "+item2+" não pode "+link1
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if item2 == linha[0].encode('utf-8'):
	link1 = linha[1].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre os itens das possibilidades
      for linha in cursor.execute("SELECT * FROM memo8"):
	if item1 == linha[0].encode('utf-8') and link1 == linha[1].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+item2+" pode "+link1
	  resposta3 = " - "+item1+" não pode "+link1
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1

    # procurar por possibilidades contraditórias: possibilidades
    link1 = "   "
    achei = 0
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if item1 == linha[1].encode('utf-8'):
	link1 = linha[0].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre as possibilidades
      for linha in cursor.execute("SELECT * FROM memo8"):
	if item2 == linha[1].encode('utf-8') and link1 == linha[0].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+link1+" pode "+item1
	  resposta3 = " - "+link1+" não pode "+item2
	  
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if item2 == linha[1].encode('utf-8'):
	link1 = linha[0].encode('utf-8')
	#print "link1:",link1
	# checando se tem uma frase que contradiz entre as possibilidades
      for linha in cursor.execute("SELECT * FROM memo8"):
	if item1 == linha[1].encode('utf-8') and link1 == linha[0].encode('utf-8'):
	  achei = 1
	  #print "achei a contradição (feminina)"
	  resposta1 = " - "+item1+" é igual a "+item2
	  resposta2 = " - "+link1+" pode "+item2
	  resposta3 = " - "+link1+" não pode "+item1
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1



    # NÍVEL 3 (3 frases anteriores) 3333333333333333333333333333333333333
    
    # (Z é um X, X é igual a Y, Z não é um Y)
    #print "1º contradição"
    achei = 0
    resposta1 = "   "
    resposta = "   "
    link1 = "   "
    link2 = "   "
    item1 = "   "
    # Buscando o digitado nas categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8') == diga) or (diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        link1 = linha[1].encode('utf-8')
        #print "primeiro item:",item1,"     link1:",link1
    # Buscando o digitado nas categorias masculinas
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if (" "+linha[0].encode('utf-8')) in diga or (diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        link1 = linha[1].encode('utf-8')
        #print "primeiro item:",item1,"     link1:",link1
    # procurar por link1 nos sinonimos
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
        if ((linha[0].encode('utf-8') != item1) and (link1 == linha[1].encode('utf-8')) and ("   " != item1)):
          link2 = linha[0].encode('utf-8')
          #print "link2:",link2
        elif ((linha[1].encode('utf-8') != item1) and (link1 == linha[0].encode('utf-8')) and ("   " != item1)):
          link2 = linha[1].encode('utf-8')
          #print "link2:",link2
    # procurar por frase item1 não é umA link2
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
          if ((linha[0].encode('utf-8') == item1) and (link2 == linha[1].encode('utf-8')) and ("   " != item1)):
            achei = 1
            #print "achei a negação (feminina)"
	    resposta1 = " - "+item1+" é um(a) "+link1+". "
	    resposta2 = " - "+link1+" é igual a "+link2+". "
	    resposta3 = " - "+item1+" não é uma "+link2+". "
    # procurar por frase item1 não é uM link2
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
          if ((linha[0].encode('utf-8') == item1) and (link2 == linha[1].encode('utf-8')) and ("   " != item1)):
            achei = 1
            #print "achei a negação (masculina)"
	    resposta1 = " - "+item1+" é um(a) "+link1+". "
	    resposta2 = " - "+link1+" é igual a "+link2+". "
	    resposta3 = " - "+item1+" não é um "+link2+". "
    if falei == 0:
      if resposta1 != "   ":
	print " - As coisas não estão se encaixando. Uma dessas 3 frases está errada:"
        print resposta1
        print resposta2
        print resposta3
        falei = 1








    # Raciocínios +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    # NÍVEL 4 a infinito?
    # Raciocínio "a minoria de x é também y"

    # De categoria feminina para feminina
    achei1 = 0
    achei11 = 0.0
    achei2 = 0
    achei22 = 0.0
    cat1 = "   "
    cat2 = "   "
    itens1 = [" "]
    x = -1
    # Procurar o digitado nas categorias femininas
    for linha in cursor.execute("SELECT * FROM memo1"):
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8')+" " in diga) or (diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
	#item1 = linha[0].encode('utf-8')
        cat1 = linha[1].encode('utf-8')
        # checa quantos itens tem na categoria
        for linha in cursor.execute("SELECT * FROM memo1"):
	  if (cat1 == linha[1].encode('utf-8')):
	    achei1 = achei1 + 1
	#print "total de itens: ",achei1
	# Colocando todos os itens da categoria numa lista
	itens1 = range(achei1)
	for linha in cursor.execute("SELECT * FROM memo1"):
	    if (cat1 == linha[1].encode('utf-8')):
	      itens1[x+1] = linha[0].encode('utf-8')
	      #print "item q foi pra lista1:",linha[0].encode('utf-8')
	      x = x + 1
	#print itens1
	# identificando a candidata a 2º categoria entre as femininas
	for linha in cursor.execute("SELECT * FROM memo1"):
	  for y in range(achei1):
	    if (itens1[y] == linha[0].encode('utf-8')) and (cat1 != linha[1].encode('utf-8')):
	      cat2 = linha[1].encode('utf-8')
	      #print "cat2: ", cat2
              for linha in cursor.execute("SELECT * FROM memo1"):
	        if cat2 == linha[1].encode('utf-8'):
	  	  if linha[0].encode('utf-8') in itens1:
		    #print "item encontrado na lista2:",linha[0].encode('utf-8')
		    achei2 = achei2 + 1      
        #print "itens na cat2", achei2
        achei11 = (achei1 / 2.0)
        #print achei11
        achei22 = achei2
	if (achei1 != 0) and (achei11 >= achei22) and (cat2 != "   ") and (achei2 != 0) and (achei11 != achei22):
	      resposta = " - considerando cada "+cat1+" que conheço, a minoria é também "+cat2
	      #print "achei1=",achei1,"     achei22=",achei22,"       achei11=",achei11
	  
    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
      if resposta != "   ":
        print resposta
        falei = 1
        anterior = resposta

    # De categoria feminina para masculina
    achei1 = 0
    achei11 = 0.0
    achei2 = 0
    achei22 = 0.0
    cat1 = "   "
    cat2 = "   "
    itens1 = [" "]
    x = -1
    resposta = "   "
    # Procurar o digitado nas categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
	#item1 = linha[0].encode('utf-8')
        cat1 = linha[1].encode('utf-8')
        # checa quantos itens tem na categoria
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
	  if (cat1 == linha[1].encode('utf-8')):
	    achei1 = achei1 + 1
	#print "total de itens: ",achei1
	# Colocando todos os itens da categoria numa lista
	itens1 = range(achei1)
	for linha in cursor.execute("SELECT * FROM memo1"):
	    if (cat1 == linha[1].encode('utf-8')):
	      itens1[x+1] = linha[0].encode('utf-8')
	      #print "item q foi pra lista1:",linha[0].encode('utf-8')
	      x = x + 1
	#print itens1
	# identificando a candidata a 2º categoria entre as masculinas
	for linha in cursor.execute("SELECT * FROM memo2"):
	  for y in range(achei1):
	    if (itens1[y] == linha[0].encode('utf-8')) and (cat1 != linha[1].encode('utf-8')):
	      cat2 = linha[1].encode('utf-8')
	      #print "cat2: ", cat2
	      cursor.execute("SELECT * FROM memo2")
              for linha in cursor:
	        if cat2 == linha[1].encode('utf-8'):
	  	  if linha[0].encode('utf-8') in itens1:
		    #print "item encontrado na lista2:",linha[0].encode('utf-8')
		    achei2 = achei2 + 1    
        #print "itens na cat2", achei2
        achei11 = (achei1 / 2.0)
        #print achei11
        achei22 = achei2
	if (achei1 != 0) and (achei11 >= achei22) and (cat2 != "   ") and (achei2 != 0) and (achei11 != achei22):
	      resposta = " - considerando cada "+cat1+" que conheço, a minoria é também "+cat2
	      #print "achei1=",achei1,"     achei22=",achei22,"       achei11=",achei11
    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
      if resposta != "   ":
        print resposta
        falei = 1
        anterior = resposta

    # De categoria masculina para feminina
    achei1 = 0
    achei11 = 0.0
    achei2 = 0
    achei22 = 0.0
    cat1 = "   "
    cat2 = "   "
    itens1 = [" "]
    x = -1
    resposta = "   "
    # Procurar o digitado nas categorias masculinas
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
	#item1 = linha[0].encode('utf-8')
        cat1 = linha[1].encode('utf-8')
        # checa quantos itens tem na categoria
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
	  if (cat1 == linha[1].encode('utf-8')):
	    achei1 = achei1 + 1
	#print "total de itens: ",achei1
	# Colocando todos os itens da categoria numa lista
	itens1 = range(achei1)
	for linha in cursor.execute("SELECT * FROM memo2"):
	    if (cat1 == linha[1].encode('utf-8')):
	      itens1[x+1] = linha[0].encode('utf-8')
	      #print "item q foi pra lista1:",linha[0].encode('utf-8')
	      x = x + 1
	#print itens1
	# identificando a candidata a 2º categoria entre as masculinas
	for linha in cursor.execute("SELECT * FROM memo1"):
	  for y in range(achei1):
	    if (itens1[y] == linha[0].encode('utf-8')) and (cat1 != linha[1].encode('utf-8')):
	      cat2 = linha[1].encode('utf-8')
	      #print "cat2: ", cat2
	      cursor.execute("SELECT * FROM memo1")
              for linha in cursor:
	        if cat2 == linha[1].encode('utf-8'):
	  	  if linha[0].encode('utf-8') in itens1:
		    #print "item encontrado na lista2:",linha[0].encode('utf-8')
		    achei2 = achei2 + 1   
        #print "itens na cat2", achei2
        achei11 = (achei1 / 2.0)
        #print achei11
        achei22 = achei2
	if (achei1 != 0) and (achei11 >= achei22) and (cat2 != "   ") and (achei2 != 0) and (achei11 != achei22):
	      resposta = " - considerando cada "+cat1+" que conheço, a minoria é também "+cat2
	      #print "achei1=",achei1,"     achei22=",achei22,"       achei11=",achei11
    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
      if resposta != "   ":
        print resposta
        falei = 1
        anterior = resposta

    # De categoria masculina para masculina
    achei1 = 0
    achei11 = 0.0
    achei2 = 0
    achei22 = 0.0
    cat1 = "   "
    cat2 = "   "
    itens1 = [" "]
    x = -1
    resposta = "   "
    # Procurar o digitado nas categorias masculinas
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
        cat1 = linha[1].encode('utf-8')
        #print cat1
        # checa quantos itens tem na categoria
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
	  if (cat1 == linha[1].encode('utf-8')):
	    achei1 = achei1 + 1
	#print "total de itens: ",achei1
	# Colocando todos os itens da categoria numa lista
	itens1 = range(achei1)
	cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
	    if (cat1 == linha[1].encode('utf-8')):
	      itens1[x+1] = linha[0].encode('utf-8')
	      #print "item q foi pra lista1:",linha[0].encode('utf-8')
	      x = x + 1
	#print itens1
	# identificando a candidata a 2º categoria entre as masculinas
	cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
	  for y in range(achei1):
	    if (itens1[y] == linha[0].encode('utf-8')) and (cat1 != linha[1].encode('utf-8')):
	      cat2 = linha[1].encode('utf-8')
	      #print "cat2: ", cat2
	      cursor.execute("SELECT * FROM memo2")
              for linha in cursor:
	        if cat2 == linha[1].encode('utf-8'):
	  	  if linha[0].encode('utf-8') in itens1:
		    #print "item encontrado na lista2:",linha[0].encode('utf-8')
		    achei2 = achei2 + 1     
        #print "itens na cat2", achei2
        achei11 = (achei1 / 2.0)
        #print achei11
        achei22 = achei2
	if (achei1 != 0) and (achei11 >= achei22) and (cat2 != "   ") and (achei2 != 0) and (achei11 != achei22):
	      resposta = " - considerando cada "+cat1+" que conheço, a minoria é também "+cat2
	      #print "achei1=",achei1,"     achei22=",achei22,"       achei11=",achei11
    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
      if resposta != "   ":
        print resposta
        falei = 1
        anterior = resposta





    # NÍVEL 2 a infinito? (2 frases anteriores no mínimo) ++++++++++++++++++++++++

    # raciocinio (todos itens de Y também são itens de X) 
    #print "raciocinio (todos itens de Y também são itens de X) "

    # De categoria feminina para feminina
    achei1 = 0
    achei2 = 0
    resposta = "   "
    cat1 = "   "
    cat2 = "   "
    itens2 = [" "]
    x = -1
    # Procurar o digitado nas categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
	#item1 = linha[0].encode('utf-8')
        cat1 = linha[1].encode('utf-8')
        # checa quantos itens tem na categoria
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
	  if (cat1 == linha[1].encode('utf-8')):
	    achei1 = achei1 + 1
	#print "total de itens: ",achei1
	# Colocando todos os itens da categoria numa lista
	itens1 = range(achei1)
	for linha in cursor.execute("SELECT * FROM memo1"):
	    if (cat1 == linha[1].encode('utf-8')):
	      itens1[x+1] = linha[0].encode('utf-8')
	      #print "item q foi pra lista1:",linha[0].encode('utf-8')
	      x = x + 1
	#print itens1
	# identificando a candidata a 2º categoria entre as femininas
	for linha in cursor.execute("SELECT * FROM memo1"):
	  if (itens1[0] == linha[0].encode('utf-8')) and (cat1 != linha[1].encode('utf-8')) and (cat1 != "   "):
	    cat2 = linha[1].encode('utf-8')
	    #print "cat2: ", cat2
	    for linha in cursor.execute("SELECT * FROM memo1"):
	      if cat2 == linha[1].encode('utf-8'):
		if linha[0].encode('utf-8') in itens1:
		  #print "item encontrado na lista2:",linha[0].encode('utf-8')
		  achei2 = achei2 + 1     
        #print "itens na cat2", achei2
	if (achei1 != 0) and (achei1 == achei2):
	      resposta = " - cada "+cat1+" que conheço também é uma "+cat2
	      #print "tenho uma resposta"
    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
      if resposta != "   ":
        print resposta
        falei = 1
        anterior = resposta





    # raciocínios de nível 3: 3333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333

    # Partindo de itens de categorias

    # racicínio nível 3 partindo de itens de categorias femininas
    #print "racicínio nível 3 partindo de itens de categorias"
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    link1 = "   "
    link2 = "   "
    item1 = "   "
    item2 = "   "
    # Procurar o digitado nos itens das categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8')+" " in diga) or (" "+diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        link1 = linha[1].encode('utf-8')
        #print "primeira cat:",cat1,"     link1:",link1
    # Procurar o link1 nos sinonimos (nível 2)
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if link1 == linha[0].encode('utf-8'):
        link2 = linha[1].encode('utf-8')
        #print "link2:",link2
      elif link1 == linha[1].encode('utf-8'):
        link2 = linha[0].encode('utf-8')
        #print "link2:",link2 
    # procurar por link2 nos itens das categorias femininas (nível 3)
    # maçã é uma fruta; fruta é igual a fruto; fruto é uma parte de um vegetal. então: maçã é uma parte de um vegetal
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
          #print "link2:",link2
    # checa se a frase proposta não foi DITA antes
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
	  resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é uma "+item2
	  resposta4 = "   - "+item1+" não é uma "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1

    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é uma "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # procurar por link2 nos itens das categorias masculinas (nível 3)
    # maçã é uma fruta; fruta é igual a fruto; fruto é uma parte de um vegetal. então: maçã é uma parte de um vegetal
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
          #print "link2:",link2
    # checa se a frase proposta não foi DITA antes
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é um "+item2
	  resposta4 = "   - "+item1+" não é um "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1
          
    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é um "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # procurar por link2 nos sinonimos (nível 3)
    # maçã é uma fruta; fruta é igual a fruto; fruto é igual a parte de vegetal onde ficam as sementes. então: maçã é um(a) parte de vegetal onde ficam as sementes
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
          #print "link2:",link2
        if link2 == linha[1].encode('utf-8'):
          item2 = linha[0].encode('utf-8')
          #print "link2:",link2 
    # checa se a frase proposta não foi DITA antes
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é igual a "+item2
	  resposta4 = "   - "+item1+" não é uma "+item2
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é igual a "+item2
	  resposta4 = "   - "+item1+" não é um "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1
          
    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é um(a) "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # racicínio nível 3 partindo de itens de categorias masculinas
    achei = 0
    resposta = "   "
    link1 = "   "
    link2 = "   "
    item1 = "   "
    item2 = "   "
    # Procurar o digitado nos itens das categorias masculinas
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8')+" " in diga) or (" "+diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        link1 = linha[1].encode('utf-8')
        #print "primeira cat:",cat1,"     link1:",link1
        
    # Procurar o link1 nos sinonimos (nível 2)
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if link1 == linha[0].encode('utf-8'):
        link2 = linha[1].encode('utf-8')
        #print "link2:",link2
      elif link1 == linha[1].encode('utf-8'):
        link2 = linha[0].encode('utf-8')
        #print "link2:",link2 
        
    # procurar por link2 nos itens das categorias femininas (nível 3)
    # maçã é um item de supermercado; item de supermercado é igual a coisa vendida no super; coisa vendida no super é uma coisa com preço. então: maçã é uma coisa com preço
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
          #print "link2:",link2
    # checa se a frase proposta não foi DITA antes
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é uma "+item2
	  resposta4 = "   - "+item1+" não é uma "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1
          
          
    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é uma "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # procurar por link2 nos itens das categorias masculinas (nível 3)
    # maçã é um item de supermercado; item de supermercado é igual a coisa vendida no super; coisa vendida no super é um produto. então: maçã é um produto
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
          #print "link2:",link2
    # checa se a frase proposta não foi DITA antes
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é um "+item2
	  resposta4 = "   - "+item1+" não é um "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1
          
    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é um "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # procurar por link2 nos sinonimos (nível 3)
    # maçã é um item de supermercado; item de supermercado é igual a coisa vendida no super; coisa vendida no super é igual a coisa com preço. então: maçã é um(a) coisa com preço
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    for linha in cursor.execute("SELECT * FROM memo5"):
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
          #print "link2:",link2
        if link2 == linha[1].encode('utf-8'):
          item2 = linha[0].encode('utf-8')
          #print "link2:",link2 
    # checa se a frase proposta não foi DITA antes
    for linha in cursor.execute("SELECT * FROM memo1"):
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    for linha in cursor.execute("SELECT * FROM memo2"):
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    for linha in cursor.execute("SELECT * FROM memo3"):
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é igual a "+item2
	  resposta4 = "   - "+item1+" não é uma "+item2
    for linha in cursor.execute("SELECT * FROM memo4"):
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
          resposta1 = "   - "+item1+" é uma "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é igual a "+item2
	  resposta4 = "   - "+item1+" não é um "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1
          
          
    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é um(a) "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta








   # Partindo de itens de possibilidades
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    link1 = "   "
    link2 = "   "
    item1 = "   "
    item2 = "   "
    # Procurar o digitado nos itens das possibilidades
    for linha in cursor.execute("SELECT * FROM memo7"):
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8')+" " in diga) or (" "+diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        link1 = linha[1].encode('utf-8')
    # Procurar o link1 nos sinonimos (nível 2)
    for linha in cursor.execute("SELECT * FROM memo5"):
      if link1 == linha[0].encode('utf-8'):
        link2 = linha[1].encode('utf-8')
      elif link1 == linha[1].encode('utf-8'):
        link2 = linha[0].encode('utf-8')
    # procurar por link2 nos sinonimos (nível 3)
    # maçã pode ser podre; ser podre é igual a ser ruim; ser ruim é igual a ser lixo. então: maçã pode ser lixo
    for linha in cursor.execute("SELECT * FROM memo5"):
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
        elif link2 == linha[1].encode('utf-8'):
	  item2 = linha[0].encode('utf-8')
    # checa se a frase proposta não foi DITA antes
    for linha in cursor.execute("SELECT * FROM memo7"):
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    for linha in cursor.execute("SELECT * FROM memo8"):
        if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
          achei = 1
	  resposta1 = "   - "+item1+" pode "+link1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é igual a "+item2
	  resposta4 = "   - "+item1+" não pode "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - As coisas não estão se encaixando para mim... Uma destas frases está errada:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1

    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" pode "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta



   # Partindo de categorias femininas
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    link1 = "   "
    link2 = "   "
    item1 = "   "
    item2 = "   "
    # Procurar o digitado nas categorias femininas
    for linha in cursor.execute("SELECT * FROM memo1"):
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8')+" " in diga) or (" "+diga2 in linha[1].encode('utf-8')):
        item1 = linha[1].encode('utf-8')
        link1 = linha[0].encode('utf-8')
    # Procurar o link1 nos sinonimos (nível 2)
    for linha in cursor.execute("SELECT * FROM memo5"):
      if link1 == linha[0].encode('utf-8'):
        link2 = linha[1].encode('utf-8')
      elif link1 == linha[1].encode('utf-8'):
        link2 = linha[0].encode('utf-8')
        
    # procurar por link2 nos sinonimos (nível 3)
    # maçã é uma fruta; maçã é igual a fruta da macieira; fruta da macieira é igual a fruta do pecado. então: fruta do pecado é uma fruta
    for linha in cursor.execute("SELECT * FROM memo5"):
        if link2 == linha[0].encode('utf-8'):
          item2 = linha[1].encode('utf-8')
        elif link2 == linha[1].encode('utf-8'):
	  item2 = linha[0].encode('utf-8')
    # checa se a frase proposta não foi DITA antes
    for linha in cursor.execute("SELECT * FROM memo1"):
        if item1 == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
          achei = 1
    # checa se a frase proposta não foi NEGADA antes
    for linha in cursor.execute("SELECT * FROM memo3"):
        if item1 == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
          achei = 1
	  resposta1 = "   - "+link1+" é uma "+item1
	  resposta2 = "   - "+link1+" é igual a "+link2
	  resposta3 = "   - "+link2+" é igual a "+item2
	  resposta4 = "   - "+item2+" não é uma "+item1

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - Alguma coisa está errada, uma dessas frases está incorreta:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1

    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item2+" é uma "+item1
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # procurar por link2 nos itens das possibilidades (nível 3)
    # maçã é uma fruta; maçã é igual a fruta da macieira; fruta da macieira pode ficar podre; então: uma fruta pode ficar podre
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    for linha in cursor.execute("SELECT * FROM memo7"):
      if link2 == linha[0].encode('utf-8'):
	item2 = linha[1].encode('utf-8')
    # checa se a frase proposta não foi DITA antes
    for linha in cursor.execute("SELECT * FROM memo7"):
      if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
	achei = 1
    # checa se a frase proposta não foi NEGADA antes
    for linha in cursor.execute("SELECT * FROM memo8"):
      if item1 == linha[0].encode('utf-8') and item2 == linha[1].encode('utf-8'):
	achei = 1
	resposta1 = "   - "+link1+" é uma "+item1
	resposta2 = "   - "+link1+" é igual a "+link2
	resposta3 = "   - "+link2+" pode "+item2
	resposta4 = "   - "+item1+" não pode "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - Alguma coisa está errada, uma dessas frases está incorreta:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1

    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - uma "+item1+" pode "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta

    # procurar por link2 nas categorias femininas e masculinas (nível 3)
    # fruta é uma parte da árvore; fruta é igual a fruto; maçã é um(a) fruto; maçã é uma parte da árvore
    achei = 0
    resposta = "   "
    resposta1 = "   "
    resposta2 = "   "
    resposta3 = "   "
    resposta4 = "   "
    item2 = "   "
    for linha in cursor.execute("SELECT * FROM memo1"):
      if link2 == linha[1].encode('utf-8'):
	item2 = linha[0].encode('utf-8')
    for linha in cursor.execute("SELECT * FROM memo2"):
      if link2 == linha[1].encode('utf-8'):
	item2 = linha[0].encode('utf-8')
    # checa se a frase proposta não foi DITA antes
    for linha in cursor.execute("SELECT * FROM memo1"):
      if item1 == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
	achei = 1
    # checa se a frase proposta não foi NEGADA antes
    for linha in cursor.execute("SELECT * FROM memo3"):
      if item1 == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
	achei = 1
	resposta1 = "   - "+link1+" é uma "+item1
	resposta2 = "   - "+link1+" é igual a "+link2
	resposta3 = "   - "+link2+" é um(a) "+item2
	resposta4 = "   - "+item1+" não é uma "+item2

    # imprime a contradição identificada
    if achei == 1 and item2 != "   ":
      if ((falei == 0) and (anterior != resposta1)) or (pergunta == 1):
        if resposta1 != "   ":
          print " - Alguma coisa está errada, uma dessas frases está incorreta:"
          print resposta1
          print resposta2
          print resposta3
          print resposta4
          falei = 1
          anterior = resposta1

    # imprime a conclusão
    if achei == 0 and item2 != "   ":
      resposta = " - "+item1+" é uma "+item2
      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
        if resposta != "   ":
          print resposta
          falei = 1
          anterior = resposta





    # Raciocinio (4 iguais)
    #print "raciocíno 4 iguais"
    achei = 0
    resposta = "   "
    link1 = "   "
    link2 = "   "
    item1 = "   "
    item2 = "   "
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      # Procurar o digitado nos sinonimos
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8')+" " in diga) or (" "+diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        link1 = linha[1].encode('utf-8')
        #print "primeiro item:",item1,"     link1:",link1
      elif (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
        item1 = linha[1].encode('utf-8')
        link1 = linha[0].encode('utf-8')
        #print "primeiro item:",item1,"     link1:",link1
    # procurar por outra citação do link1
    if item1 != "   ":
      for linha in cursor.execute("SELECT * FROM memo5"):
        if (item1 == (linha[0].encode('utf-8')) or (link1 == linha[0].encode('utf-8'))):
	  if (item1 != (linha[1].encode('utf-8')) and (link1 != linha[1].encode('utf-8'))):
            link2 = linha[1].encode('utf-8')
            #print "link2:",link2
        elif (item1 == (linha[1].encode('utf-8')) or (link1 == linha[1].encode('utf-8'))):
          if (item1 != (linha[0].encode('utf-8')) and (link1 != linha[0].encode('utf-8'))):
            link2 = linha[0].encode('utf-8')
            #print "link2:",link2
          
    # procurar por outra citação do link2
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
          if ((linha[0].encode('utf-8') != link1) and (link2 == linha[1].encode('utf-8')) and ("   " != item1)):
            item2 = linha[0].encode('utf-8')
            #print "item2:",item2
          elif ((linha[1].encode('utf-8') != link1) and (link2 == linha[0].encode('utf-8')) and ("   " != item1)):
            item2 = linha[1].encode('utf-8')
            #print "item2:",item2
    #checa se item1 já não foi antes associado a item2
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
          if ((linha[0].encode('utf-8') == item1) and (linha[1].encode('utf-8') == item2)) or ((linha[1].encode('utf-8') == item1) and (linha[0].encode('utf-8') == item2)):
	    achei = 1
	    #print "achei o item1 já associado ao item2"
            # confere se o item1 também faz parte desta outra categoria
          elif achou == 0 and item2 != "   " and item1 != item2:
	    resposta = " - "+item1+" é igual a "+item2
    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
      if resposta != "   ":
        print resposta
        falei = 1
        anterior = resposta
        






    # Raciocinio por analogia
    #print "tentando achar analogias"
    achou = 0
    item2 = " "
    categ2 = " "
    
    # Percorre os itens da memória das categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      # Procurar o digitado nos itens das categorias femininas
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8') == diga) or (" "+diga in linha[0].encode('utf-8')) or (" "+diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        categ = linha[1].encode('utf-8')
        #print "primeiro item:",item1
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
          if ((linha[0].encode('utf-8') != item1) and (categ == linha[1].encode('utf-8'))):
            item2 = linha[0].encode('utf-8')
            #print cursor.fetchall()
            #print "segundo item:",item2
        #procurar segundo item em outra categoria feminina
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
          if ((linha[0].encode('utf-8') == item2) and (categ != linha[1].encode('utf-8'))):
	    categ2 = linha[1].encode('utf-8')
	    #print "achei o item em outra categoria feminina"
            # confere se o item1 também faz parte desta outra categoria
            cursor.execute("SELECT * FROM memo1")
	    for linha in cursor:
	      if categ2 == linha[1].encode('utf-8'):
	        if linha[0].encode('utf-8') == item1:
	          achou = 1
            if achou == 0:
                  cursor.execute("SELECT * FROM memo3")
	          for linha in cursor:
		    #print "checando se o item suspeito não foi negado antes"
		    if categ2 == linha[1].encode('utf-8') and linha[0].encode('utf-8') == item1:
		      achou = 1
		      #print "o item foi negado"
		  # checar se o palpite já não foi afirmado antes    
		  cursor.execute("SELECT * FROM memo1")
	          for linha in cursor:
		    if categ2 == linha[1].encode('utf-8') and linha[0].encode('utf-8') == item1:
		      achou = 1    
		  if achou == 0:
	            resposta = " - "+palpite+" "+item1+" também é uma "+categ2
                    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
                      print resposta
                      falei = 1
                      anterior = resposta

        #procurar segundo item em outra categoria masculina
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
          if ((linha[0].encode('utf-8') == item2) and (categ != linha[1].encode('utf-8'))):
	    categ2 = linha[1].encode('utf-8')
	    #print "achei o item em outra categoria masculina"
            # confere se o item1 também faz parte desta outra categoria
            cursor.execute("SELECT * FROM memo2")
	    for linha in cursor:
	      if categ2 == linha[1].encode('utf-8'):
	        if linha[0].encode('utf-8') == item1:
	          achou = 1
	    # checar se o palpite já não foi afirmado antes    
	    cursor.execute("SELECT * FROM memo2")
	    for linha in cursor:
	      if categ2 == linha[1].encode('utf-8') and linha[0].encode('utf-8') == item1:
		achou = 1    
            if achou == 0 and categ2 != " ":
	          resposta = " - "+palpite+" "+item1+" também é um "+categ2
                  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
                    print resposta
                    falei = 1
                    anterior = resposta

    # Percorre os itens da memória das categorias masculinas
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      # Procurar o digitado nos itens das categorias masculinas
      if (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8') == diga) or (" "+diga in linha[0].encode('utf-8')) or (" "+diga2 in linha[0].encode('utf-8')):
        item1 = linha[0].encode('utf-8')
        categ = linha[1].encode('utf-8')
        #print "primeiro item:",item1
        item2 = " "
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
          if ((linha[0].encode('utf-8') != item1) and (categ == linha[1].encode('utf-8'))):
            item2 = linha[0].encode('utf-8')
            #print cursor.fetchall()
            #print "segundo item:",item2
        #procurar segundo item em outra categoria feminina
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
          if ((linha[0].encode('utf-8') == item2) and (categ != linha[1].encode('utf-8'))):
	    categ2 = linha[1].encode('utf-8')
	    #print "achei o item em outra categoria feminina 2"
            # confere se o item1 também faz parte desta outra categoria
            cursor.execute("SELECT * FROM memo1")
	    for linha in cursor:
	      if categ2 == linha[1].encode('utf-8'):
	        if linha[0].encode('utf-8') == item1:
	          achou = 1
            if achou == 0 and categ2 != " ":
              cursor.execute("SELECT * FROM memo3")
	    for linha in cursor:
		    #print "checando se o item suspeito não foi negado antes 2"
		    if categ2 == linha[1].encode('utf-8') and linha[0].encode('utf-8') == item1:
		      achou = 1
		      #print "o item foi negado 2"
	    # checar se o palpite já não foi afirmado antes    
	    cursor.execute("SELECT * FROM memo1")
	    for linha in cursor:
		    if categ2 == linha[1].encode('utf-8') and linha[0].encode('utf-8') == item1:
		      achou = 1    
	    if achou == 0:
	            resposta = " - "+palpite+" "+item1+" também é uma "+categ2
                    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
                      print resposta
                      falei = 1
                      anterior = resposta

        #procurar segundo item em outra categoria masculina
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
          if ((linha[0].encode('utf-8') == item2) and (categ != linha[1].encode('utf-8'))):
	    categ2 = linha[1].encode('utf-8')
	    #print "achei o item em outra categoria masculina 2"
            # confere se o item1 também faz parte desta outra categoria
            cursor.execute("SELECT * FROM memo2")
	    for linha in cursor:
	      if categ2 == linha[1].encode('utf-8'):
	        if linha[0].encode('utf-8') == item1:
	          achou = 1
	    # checar se o palpite já não foi afirmado antes    
	    cursor.execute("SELECT * FROM memo2")
	    for linha in cursor:
	      if categ2 == linha[1].encode('utf-8') and linha[0].encode('utf-8') == item1:
		achou = 1    
            if achou == 0 and categ2 != " ":
	            resposta = " - "+palpite+" "+item1+" também é um "+categ2
                    if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
                      print resposta
                      falei = 1
                      anterior = resposta



    # Raciocinios nível 2 22222222222222222222222222222222222222222222222222222222222222222
    #print "Raciocínios de nível 2"
    
    # x pode y: trocando x por sinonimo    
    achou = 0
    item1 = " "
    item2 = "   "
    resposta = "   "
    link1 = "   "
    
    # Procurar o digitado nos estados possiveis
    cursor.execute("SELECT * FROM memo7")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8') == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
        item1 = linha[1].encode('utf-8')
        link1 = linha[0].encode('utf-8')
        #print "primeiro item:",item1,"     link1:",link1
        # procurar por citação do link1 nos sinonimos
        cursor.execute("SELECT * FROM memo5")
        for linha in cursor:
          if ((link1 == linha[1].encode('utf-8')) and ("   " != item1)):
            item2 = linha[0].encode('utf-8')
            #print "link2:",item2
          elif ((link1 == linha[0].encode('utf-8')) and ("   " != item1)):
            item2 = linha[1].encode('utf-8')
            #print "item2:",item2
        #checa se não foi dito isso antes
        cursor.execute("SELECT * FROM memo7")
        for linha in cursor:
          if (item2 == linha[0].encode('utf-8')) and (item1 == linha[1].encode('utf-8')):
            achou = 1
            #print "item2:",item2
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo8")
        for linha in cursor:
          if ((linha[0].encode('utf-8') == item2) and (linha[1].encode('utf-8') == item1)):
	    achou = 1
	    #print "achei o item1 já associado ao item2"
        if achou == 0 and item2 != "   " and item1 != item2:
	    resposta = " - "+item2+" pode "+item1
        if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
          if resposta != "   ":
            print resposta
            falei = 1
            anterior = resposta



    # todos raciocínios de nível 2 partindo de 'x é igual a y'    
    #print "raciocínios partindo de 'x é igual a y'"
    sinon1 = "   "
    sinon2 = "   "
    achou = 0
    item2 = "   "
    resposta = "   "
    
    # Procurar o digitado nos sinonimos
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if (" "+linha[1].encode('utf-8') in diga) or (linha[1].encode('utf-8')+" " in diga) or (" "+diga2 in linha[1].encode('utf-8')):
        sinon1 = linha[0].encode('utf-8')
        sinon2 = linha[1].encode('utf-8')
      elif (" "+linha[0].encode('utf-8') in diga) or (linha[0].encode('utf-8')+" " in diga) or (" "+diga2 in linha[0].encode('utf-8')):
	sinon1 = linha[1].encode('utf-8')
        sinon2 = linha[0].encode('utf-8')
      # sinon2 é o digitado pelo usuário

    # associando com itens de categorias femininas o sinon1
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo1")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo3")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon2+" é uma "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com categorias femininas sinon 1
    achou = 0
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo1")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo3")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+item2+" é um(a) "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com itens de categorias masculinas o sinon1
    achou = 0
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo2")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo4")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon2+" é um "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com categorias masculinas sinon 1
    item2 = "   "
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo2")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo4")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	    # checa os requesitos e imprime a resposta
	    if achou == 0 and item2 != "   " and sinon1 != item2:
	      resposta = " - "+item2+" é um "+sinon2
	      if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
		if resposta != "   ":
		  print resposta
		  falei = 1
		  anterior = resposta
		  achou = 1

    # associando com sinonimos o sinon1
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo5")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo6")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon2 != item2:
	  resposta = " - "+sinon2+" é igual a "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com sinonimos sinon 1
    item2 = "   "
    cursor.execute("SELECT * FROM memo5")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo5")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo6")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon2 != item2:
	  resposta = " - "+item2+" é igual a "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      #achou = 1

    # associando com possibilidades sinon1
    item2 = "   "
    for linha in cursor.execute("SELECT * FROM memo7"):
      if ((sinon2 == linha[0].encode('utf-8')) and ("   " != sinon1)):
	item2 = linha[1].encode('utf-8')
	achou = 0
	#print "item2:",item2
	#checa se não foi dito isso antes
	for linha2 in cursor.execute("SELECT * FROM memo7"):
	  if (sinon1 == linha2[0].encode('utf-8')) and (item2 == linha2[1].encode('utf-8')):
	    achou = 1
	    #print "- item2:",item2
	    #checa se não foi negada frase concluida
	for linha3 in cursor.execute("SELECT * FROM memo8"):
	  if (sinon1 == linha3[0].encode('utf-8')) and (item2 == linha3[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	    # checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon1+" pode "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1) and resposta != "   ":
	    print resposta
	    falei = 1
	    anterior = resposta

    # associando com categorias femininas sinon 1
    item2 = "   "
    resposta = "   "
    for linha in cursor.execute("SELECT * FROM memo7"):
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	achou = 0
	#print "item2:",item2
	#checa se não foi dito isso antes
	for linha in cursor.execute("SELECT * FROM memo7"):
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        for linha in cursor.execute("SELECT * FROM memo8"):
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
      # checa os requesitos e imprime a resposta
      if achou == 0 and item2 != "   " and sinon2 != item2:
	  resposta = " - "+item2+" pode "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      #achou = 1

    # associando com item hierarquico o sinon1
    item2 = "   "
    conector = "   "
    for linha in cursor.execute("SELECT * FROM memo9"):
      if ((sinon2 == linha[0].encode('utf-8')) and ("   " != sinon1)):
	item2 = linha[2].encode('utf-8')
	conector = linha[1].encode('utf-8')
	achou = 0
	#print "item2:",item2
	#checa se não foi dito isso antes
	for linha2 in cursor.execute("SELECT * FROM memo9"):
	  if (sinon1 == linha2[0].encode('utf-8')) and (conector == linha2[1].encode('utf-8')) and (item2 == linha2[2].encode('utf-8')):
	    achou = 1
	    #print "- item2:",item2
	#checa se não foi negada frase concluida
	for linha3 in cursor.execute("SELECT * FROM memo10"):
	  if (sinon1 == linha2[0].encode('utf-8')) and (conector == linha2[1].encode('utf-8')) and (item2 == linha2[2].encode('utf-8')):
	    achou = 1
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon1+" "+conector+"e "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1) and resposta != "   ":
	    print resposta
	    falei = 1
	    anterior = resposta

    # Negando ------------- Negando -------------Negando -------------Negando -------------Negando -------------Negando -------------Negando -------------



    # associando com itens de categorias femininas o sinon1
    item2 = "   "
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo3")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon2+" não é uma "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com categorias femininas sinon 1
    achou = 0
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo3")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo3")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+item2+" não é uma "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com itens de categorias masculinas o sinon1
    achou = 0
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo4")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon2+" não é um "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com categorias masculinas sinon 1
    item2 = "   "
    cursor.execute("SELECT * FROM memo4")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo4")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+item2+" não é um "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com sinonimos o sinon1
    achou = 0
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo6")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo6")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo5")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2 and sinon1 != sinon2:
	  resposta = " - "+sinon2+" não é igual a "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com sinonimos sinon 1
    item2 = "   "
    cursor.execute("SELECT * FROM memo6")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo6")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo5")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2 and sinon1 != sinon2:
	  resposta = " - "+item2+" não é igual a "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com possibilidades o sinon1
    item2 = "   "
    cursor.execute("SELECT * FROM memo8")
    for linha in cursor:
      if ((sinon1 == linha[0].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[1].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo8")
	for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo7")
        for linha in cursor:
	  if (sinon2 == linha[0].encode('utf-8')) and (item2 == linha[1].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+sinon2+" não pode "+item2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    # associando com categorias femininas sinon 1
    achou = 0
    item2 = "   "
    resposta = "   "
    cursor.execute("SELECT * FROM memo8")
    for linha in cursor:
      if ((sinon1 == linha[1].encode('utf-8')) and ("   " != sinon2)):
	item2 = linha[0].encode('utf-8')
	#print "item2:",item2
	#checa se não foi dito isso antes
	cursor.execute("SELECT * FROM memo8")
	for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "- foi dito antes"
        #checa se não foi negada frase concluida
        cursor.execute("SELECT * FROM memo7")
        for linha in cursor:
	  if (sinon2 == linha[1].encode('utf-8')) and (item2 == linha[0].encode('utf-8')):
	    achou = 1
	    #print "achei o sinon1 já associado ao item2"
	# checa os requesitos e imprime a resposta
	if achou == 0 and item2 != "   " and sinon1 != item2:
	  resposta = " - "+item2+" não pode "+sinon2
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if resposta != "   ":
	      print resposta
	      falei = 1
	      anterior = resposta
	      achou = 1

    if falei == 0 and pergunta == 1:
      print " - Não cheguei a nenhuma conclusão sobre isso"
      falei = 1






    # ++++++++++++++++++++++++
    # + PERGUNTAS AO USUARIO +
    # ++++++++++++++++++++++++
  
    if falei == 0 and diga != "fui":
      #print "procurando o que perguntar"

      # se foi digitada uma categoria feminina só com um item:
      achei = 0
      item1 = "   "
      cat = "   "
      for linha in cursor.execute("SELECT * FROM memo1"):
	  if (" "+linha[1].encode('utf-8') in diga) or (" "+diga in linha[1].encode('utf-8')):
	    item1 = linha[0].encode('utf-8')
	    cat = linha[1].encode('utf-8')
	    for linha in cursor.execute("SELECT * FROM memo1"):
	      if cat == linha[1].encode('utf-8') and item1 != linha[0].encode('utf-8'):
		achei = 1
      if achei == 0:
	  resposta = " - poderia me citar outra "+cat+" além de "+item1+"?"
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if cat != "   ":
	      print resposta
	      print "(Digite: ________ é uma "+cat+")"
	      falei = 1
	      anterior = resposta
	      
      # se foi digitada uma categoria masculina só com um item:
      achei = 0
      item1 = "   "
      cat = "   "
      for linha in cursor.execute("SELECT * FROM memo2"):
	  if (" "+linha[1].encode('utf-8') in diga) or (" "+diga in linha[1].encode('utf-8')):
	    item1 = linha[0].encode('utf-8')
	    cat = linha[1].encode('utf-8')
	    for linha in cursor.execute("SELECT * FROM memo1"):
	      if cat == linha[1].encode('utf-8') and item1 != linha[0].encode('utf-8'):
		achei = 1
      if achei == 0:
	  resposta = " - poderia me citar outro "+cat+" além de "+item1+"?"
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if cat != "   ":
	      print resposta
	      print "(Digite: ________ é um "+cat+")"
	      falei = 1
	      anterior = resposta

      # se foi digitado um item de categoria feminina sem sinônimo:
      achei = 0
      item1 = "   "
      for linha in cursor.execute("SELECT * FROM memo1"):
	if (" "+linha[1].encode('utf-8') in diga) or (" "+diga in linha[1].encode('utf-8')):
	    item1 = linha[0].encode('utf-8')
      for linha in cursor.execute("SELECT * FROM memo5"):
	if item1 == linha[1].encode('utf-8') or item1 == linha[0].encode('utf-8'):
	  achei = 1
      if achei == 0:
	  resposta = " - poderia me citar um sinônimo de "+item1+"?"
	  if ((falei == 0) and (anterior != resposta)) or (pergunta == 1):
	    if item1 != "   ":
	      print resposta
	      print "(Digite: "+item1+" é igual a _______)"
	      falei = 1
	      anterior = resposta


      # se o usuário digitou uma palavra solta que não tem significado
      achou = 0
      #print "checando se a palavra nunca foi dita antes"
      if " " in diga:
	achou = 1
	#parte1, parte2 = diga.split(' ')
	#print " - o que é "+parte1+"?"
	#print "("+parte1+" é um _______)"
	#falei = 1
      else:
	#procura a palavra em cada tabela
	for linha in cursor.execute("SELECT * FROM memo1"):
	  if (linha[0].encode('utf-8') == diga) or (linha[1].encode('utf-8') == diga):
	    achou = 1
	for linha in cursor.execute("SELECT * FROM memo2"):
          if (linha[0].encode('utf-8') == diga) or (linha[1].encode('utf-8') == diga):
	    achou = 1
	for linha in cursor.execute("SELECT * FROM memo3"):
          if (linha[0].encode('utf-8') == diga) or (linha[1].encode('utf-8') == diga):
	    achou = 1
	for linha in cursor.execute("SELECT * FROM memo4"):
          if (linha[0].encode('utf-8') == diga) or (linha[1].encode('utf-8') == diga):
	    achou = 1
	for linha in cursor.execute("SELECT * FROM memo5"):
          if (linha[0].encode('utf-8') == diga) or (linha[1].encode('utf-8') == diga):
	    achou = 1
	  
      # se não achou na memória, imprime a pergunta
      if (achou == 0) and (falei == 0):
	resposta = " - o que é "+diga+"? (Digite: "+diga+" é um _______)"
	if (anterior != resposta):
	  print resposta
	  falei = 1
	  anterior = resposta



      # se o usuário digitou um sinonimo que não está em nenhuma categoria
      achou = 0
      for linha in cursor.execute("SELECT * FROM memo5"):
        if (" "+linha[0].encode('utf-8') in diga) or (" "+diga in linha[0].encode('utf-8')):
    	  sinon1 = linha[0].encode('utf-8')
      	  sinon2 = linha[1].encode('utf-8')
	  # Procurar nas categorias femininas:
          for linha in cursor.execute("SELECT * FROM memo1"):
	    if (sinon1 == linha[0].encode('utf-8')) or (sinon2 == linha[0].encode('utf-8')):
	      achou = 1
	  # Procurar nas categorias masculinas:
          for linha in cursor.execute("SELECT * FROM memo2"):
	    if (sinon1 == linha[0].encode('utf-8')) or (sinon2 == linha[0].encode('utf-8')):
	      achou = 1
          if achou == 0:
	    resposta = " - em que grupo está "+sinon1+"?"
	    if (anterior != resposta) and (falei == 0):
	      print resposta
	      print "("+sinon1+" é um _______)"
	      falei = 1
	      anterior = resposta
        if (" "+linha[1].encode('utf-8') in diga) or (" "+diga in linha[1].encode('utf-8')):
    	  sinon1 = linha[0].encode('utf-8')
      	  sinon2 = linha[1].encode('utf-8')
	  # Procurar nas categorias femininas:
          for linha in cursor.execute("SELECT * FROM memo1"):
	    if (sinon1 == linha[0].encode('utf-8')) or (sinon2 == linha[0].encode('utf-8')):
	      achou = 1
	  # Procurar nas categorias masculinas:
          for linha in cursor.execute("SELECT * FROM memo2"):
	    if (sinon1 == linha[0].encode('utf-8')) or (sinon2 == linha[0].encode('utf-8')):
	      achou = 1
          if achou == 0 and (falei == 0):
	    resposta = " - em que grupo está "+sinon1+"?"
	    if (anterior != resposta):
	      print resposta
	      print "("+sinon1+" é um _______)"
	      falei = 1
	      anterior = resposta

    # pergunta um sinonimo do item que foi dito e que não tem sinonimos"
    #print "pergunta por um sinonimo"
    achou = 0
    item = " "
    # procura o dito entre os itens das categorias femininas
    cursor.execute("SELECT * FROM memo1")
    for linha in cursor:
      if ((" "+linha[0].encode('utf-8')+" ") in diga) or (linha[0].encode('utf-8') == diga) or (" "+diga in linha[0].encode('utf-8')):
	item = linha[0].encode('utf-8')
      # procura o item entre os sinonimos
	for linha in cursor.execute("SELECT * FROM memo5"):
	  if item == linha[0].encode('utf-8'):
	    achou = 1
	  if item == linha[1].encode('utf-8'):
	    achou = 1
      if achou == 0:
	resposta = " - poderia me dizer um sinonimo de "+item+"?"
	if (falei == 0) and (anterior != resposta) and (item != " "):
	    print resposta
	    print "("+item+" é igual a _______)"
	    falei = 1
	    anterior = resposta

    # procura o dito entre os itens das categorias masculinas
    achou = 0
    item = " "
    cursor.execute("SELECT * FROM memo2")
    for linha in cursor:
      if ((" "+linha[0].encode('utf-8')+" ") in diga) or (linha[0].encode('utf-8') == diga) or (" "+diga in linha[0].encode('utf-8')):
	item = linha[0].encode('utf-8')
      # procura o item entre os sinonimos
	for linha in cursor.execute("SELECT * FROM memo5"):
	  if item == linha[0].encode('utf-8'):
	    achou = 1
	  if item == linha[1].encode('utf-8'):
	    achou = 1
      if achou == 0:
	resposta = " - poderia me dizer um sinonimo de "+item+"?"
	if (falei == 0) and (anterior != resposta) and (item != " "):
	    print resposta
	    print "("+item+" é igual a _______)"
	    falei = 1
	    anterior = resposta


    # +++++++++++++++++++++++
    # + resposta de nível 1 +
    # +++++++++++++++++++++++

    # Responde o que foi dito com um sinonimo
    #print "Respostas de nível 1"
    if falei == 0 and diga != "fui" and pergunta != 1:
      achou = 0
      cursor.execute("SELECT * FROM memo5")
      for linha in cursor:
        if linha[0].encode('utf-8') == diga:
          achei = 1
          resposta = " - "+linha[1].encode('utf-8')
          if (anterior != resposta):
	    print resposta
            falei = 1
            anterior = resposta
        if linha[1].encode('utf-8') == diga:
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')
          if (anterior != resposta):
	    print resposta
            falei = 1
            anterior = resposta
            
            
            
      # Respondendo com algo da memóriaaaaaaaaaaaaaaaaaaaaaaaa
      achou = 0
      #print "Respondendo com algo da memória"
      cursor.execute("SELECT * FROM memo1")
      for linha in cursor:
        if ((" "+linha[0].encode('utf-8')) in diga) or ((linha[0].encode('utf-8')) == diga) or (" "+diga in linha[0].encode('utf-8')) or (" "+diga2 in linha[0].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" é uma "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta
        elif ((" "+linha[1].encode('utf-8')) in diga) or ((linha[1].encode('utf-8')) == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" é uma "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta
            
      # buscando nas categorias masculinas      
      cursor.execute("SELECT * FROM memo2")
      for linha in cursor:
        if ((" "+linha[0].encode('utf-8')) in diga) or ((linha[0].encode('utf-8')) == diga) or (" "+diga in linha[0].encode('utf-8')) or (" "+diga2 in linha[0].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" é um "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta
        elif ((" "+linha[1].encode('utf-8')) in diga) or ((linha[1].encode('utf-8')) == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" é um "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta
    
      # buscando nos sinonimos
      cursor.execute("SELECT * FROM memo5")
      for linha in cursor:
        if ((" "+linha[0].encode('utf-8')) in diga) or ((linha[0].encode('utf-8')) == diga) or (" "+diga in linha[0].encode('utf-8')) or (" "+diga2 in linha[0].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" é igual a "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta
        elif ((" "+linha[1].encode('utf-8')) in diga) or ((linha[1].encode('utf-8')) == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" é igual a "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta

      # buscando nas possibilidades
      cursor.execute("SELECT * FROM memo7")
      for linha in cursor:
        if ((" "+linha[0].encode('utf-8')) in diga) or ((linha[0].encode('utf-8')) == diga) or (" "+diga in linha[0].encode('utf-8')) or (" "+diga2 in linha[0].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" pode "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta
        if ((" "+linha[1].encode('utf-8')) in diga) or ((linha[1].encode('utf-8')) == diga) or (" "+diga in linha[1].encode('utf-8')) or (" "+diga2 in linha[1].encode('utf-8')):
          achei = 1
          resposta = " - "+linha[0].encode('utf-8')+" pode "+linha[1].encode('utf-8')
          if (anterior != resposta) and (resposta != (" - "+diga)) and (falei == 0):
	    print resposta
            falei = 1
            anterior = resposta




    if falei == 0:
      print " - Preciso saber mais sobre isso"

# confirma os dados para o banco de dados e fecha o banco de dados
conn.commit()
cursor.close()
conn.close()      
exit

# Copyright 2012, 2016 Carlos Adrian Rupp