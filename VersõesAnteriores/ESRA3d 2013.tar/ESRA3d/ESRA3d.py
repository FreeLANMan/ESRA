# -*- coding: UTF-8 -*-
# Versão Linux
#from __future__ import unicode_literals
from pysqlite2 import dbapi2 as sqlite


# ESRA v.3 objetivo: Responder a partir de frases não-lógicas

# o que funciona:
# está identificando e guardando definições/sinonimos
# está identificando e guardando categorias
# estabelece relações com categorias
# estabelece relações entre categorias e definições
# aceita acentos e cedilha
# Faz buscar por palavras conhecidas nas frases digitadas

# Problemas:

# Na busca por expressões, ele não retorna tudo q pode concluir sobre a expressão: 
# Ex.: - maçã é uma fruta. - fruta é um alimento. Ele deveria retornar: maçã é um alimento
# dificuldades com artigos
# não faz nada com o 11' item de uma categoria



diga = "oi"
conn=sqlite.connect('memoria.db')
cursor=conn.cursor()
# apaga as tabelas anteriores:
#cursor.execute("DROP TABLE IF EXISTS memo1")
#cursor.execute("DROP TABLE IF EXISTS memo2")
#cursor.execute("DROP TABLE IF EXISTS memo3")
# sql1 = tebela de definições
sql1 = """CREATE TABLE MEMO1 (
         sinon1  CHAR(100) NOT NULL,
         sinon2  CHAR(100) NOT NULL,
         sinon3  CHAR(100),
         sinon4  CHAR(100))"""
# sql2 = tabela de categorias e itens
sql2 = """CREATE TABLE MEMO2 (
         categ  CHAR(64) NOT NULL,
         item1  CHAR(20) NOT NULL,
         item2  CHAR(20) NOT NULL,
         item3  CHAR(20),
         item4  CHAR(20),
         item5  CHAR(20),
         item6  CHAR(20),
         item7  CHAR(20),
         item8  CHAR(20),
         item9  CHAR(20),
         item10  CHAR(20))"""
# sql3 = tabela de categorias femininas (frutas, ferramentas, roupas, etc.)
sql3= """CREATE TABLE MEMO3 (
categ  CHAR(64) NOT NULL,
item1  CHAR(20) NOT NULL,
item2  CHAR(20) NOT NULL,
item3  CHAR(20),
item4  CHAR(20),
item5  CHAR(20),
item6  CHAR(20),
item7  CHAR(20),
item8  CHAR(20),
item9  CHAR(20),
item10  CHAR(20))"""
# Cria a tabela de definições no banco de dados:
#cursor.execute(sql1)
# Cria a tabela para categorias no banco de dados:
#cursor.execute(sql2)
# Cria a tabela para categorias femininas no banco de dados:
#cursor.execute(sql3)

# Mensagens iniciais para o usuário:
print "   "
print "   "
print "Olá, bem vindo ao ESRA (Esboço de Sistema de Raciocinio Artificial)"
print " "
print "Comece as frases com letra minuscula"
print "Não use apóstrofos '"
#print "Não esqueça dos artigos"
print "Digite 'fui' para sair"
print "Digite 'o que sabe sobre x' para que o sistema diga tudo que está gravado sobre uma palavra ou expressão"
print "O ESRA só está identificando definições 'é'"
print "e categorias 'é um' ou 'é uma'"
#conn.commit()
cursor.execute("INSERT INTO memo1(sinon1, sinon2, sinon3, sinon4) VALUES('%s', '%s', '%s', '%s')" %("None", "None", "None", "None"))
while diga != "fui":
    print " "
    sei = 0
    achou = 0
    achou2 = 0
    achou3 = 0
    # pegar a entrada do usuário:
    diga=raw_input("Diga: ")
    #.decode('utf-8')

 # buscar conectivo 'é uma' na entrada e repartir em 2as partes:
    if ' é uma ' in diga:
        sei = 1
        parte1, catega = diga.split(' é uma ')
        achou = 0        
        # Busca por catega e parte1 na memória, se achou adiciona item
        cursor.execute("SELECT * FROM memo3")
        for linha in cursor:  
            if catega == linha[0].encode('utf-8'):
                #print "humm"
                achou = 1
                # Adicionar a parte1 se categ for = a linha[0] e se parte1 um não foi gravada antes
                if (parte1 != linha[1].encode('utf-8')) and (linha[2] == 'None'):
                    cursor.execute("UPDATE memo3 SET item2='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[1], "também é uma",linha[0]
                elif (parte1 != linha[2].encode('utf-8')) and (linha[3] == 'None'):
                    cursor.execute("UPDATE memo3 SET item3='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[2], "também é uma",linha[0]
                elif (parte1 != linha[3].encode('utf-8')) and (linha[4] == 'None'):
                    cursor.execute("UPDATE memo3 SET item4='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[3], "também é uma",linha[0]
                elif (parte1 != linha[4].encode('utf-8')) and (linha[5] == 'None'):
                    cursor.execute("UPDATE memo3 SET item5='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[4], "também é uma",linha[0]
                elif (parte1 != linha[5].encode('utf-8')) and (linha[6] == 'None'):
                    cursor.execute("UPDATE memo3 SET item6='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[5], "também é uma",linha[0]
                elif (parte1 != linha[6].encode('utf-8')) and (linha[7] == 'None'):
                    cursor.execute("UPDATE memo3 SET item7='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[6], "também é uma",linha[0]
                elif (parte1 != linha[7].encode('utf-8')) and (linha[8] == 'None'):
                    cursor.execute("UPDATE memo3 SET item8='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[7], "também é uma",linha[0]
                elif (parte1 != linha[8].encode('utf-8')) and (linha[9] == 'None'):
                    cursor.execute("UPDATE memo3 SET item9='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[8], "também é uma",linha[0]
                elif (parte1 != linha[9].encode('utf-8')) and (linha[10] == 'None'):
                    cursor.execute("UPDATE memo3 SET item10='%s' WHERE categ='%s'" % (parte1,catega))
                    print linha[9], "também é uma",linha[0]
        # adiciona na memoria.db se a categoria é nova
        if achou == 0:
            print "Ok"
            cursor.execute("INSERT INTO memo3(categ, item1, item2, item3, item4, item5, item6, item7, item8, item9, item10) VALUES('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(catega, parte1, "None", "None", "None", "None", "None", "None", "None", "None", "None"))

        # Busca por itens (parte1) na memória de definições, se achou apresentar relação
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8'):
                print linha[1], "é uma",catega
            elif parte1 == linha[1].encode('utf-8'):
                print linha[0], "é uma",catega
            elif parte1 == linha[2].encode('utf-8'):
                print linha[1], "é uma",catega
            elif parte1 == linha[3].encode('utf-8'):
                print linha[2], "é uma",catega

        # Busca por categorias(cataga) entre os itens já conhecidos, se achou apresenta relação
        cursor.execute("SELECT * FROM memo3")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8'):
                print linha[1], "é uma",catega
                
	# Busca por categorias(cataga) entre os itens já conhecidos, se achou apresenta relação
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8'):
                print linha[1], "é uma",catega

    # buscar conectivo 'é um' na entrada e repartir em 2as partes:
    elif ' é um ' in diga:
        sei = 1
        parte1, catego = diga.split(' é um ')
        achou = 0        
        # Busca por catego e parte1 na memória, se achou adiciona item
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:  
            if catego == linha[0].encode('utf-8'):
                #print "humm"
                achou = 1
                # Adicionar a parte1 se categ for = a linha[0] e se parte1 um não foi gravada antes
                if (parte1 != linha[1].encode('utf-8')) and (linha[2] == 'None'):
                    cursor.execute("UPDATE memo2 SET item2='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[1], "também é um",linha[0]
                elif (parte1 != linha[2].encode('utf-8')) and (linha[3] == 'None'):
                    cursor.execute("UPDATE memo2 SET item3='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[2], "também é um",linha[0]
                elif (parte1 != linha[3].encode('utf-8')) and (linha[4] == 'None'):
                    cursor.execute("UPDATE memo2 SET item4='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[3], "também é um",linha[0]
                elif (parte1 != linha[4].encode('utf-8')) and (linha[5] == 'None'):
                    cursor.execute("UPDATE memo2 SET item5='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[4], "também é um",linha[0]
                elif (parte1 != linha[5].encode('utf-8')) and (linha[6] == 'None'):
                    cursor.execute("UPDATE memo2 SET item6='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[5], "também é um",linha[0]
                elif (parte1 != linha[6].encode('utf-8')) and (linha[7] == 'None'):
                    cursor.execute("UPDATE memo2 SET item7='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[6], "também é um",linha[0]
                elif (parte1 != linha[7].encode('utf-8')) and (linha[8] == 'None'):
                    cursor.execute("UPDATE memo2 SET item8='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[7], "também é um",linha[0]
                elif (parte1 != linha[8].encode('utf-8')) and (linha[9] == 'None'):
                    cursor.execute("UPDATE memo2 SET item9='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[8], "também é um",linha[0]
                elif (parte1 != linha[9].encode('utf-8')) and (linha[10] == 'None'):
                    cursor.execute("UPDATE memo2 SET item10='%s' WHERE categ='%s'" % (parte1,catego))
                    print linha[9], "também é um",linha[0]
        # adiciona na memoria.db se a categoria é nova
        if achou == 0:
            print "Ok"
            cursor.execute("INSERT INTO memo2(categ, item1, item2, item3, item4, item5, item6, item7, item8, item9, item10) VALUES('%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s')" %(catego, parte1, "None", "None", "None", "None", "None", "None", "None", "None", "None"))

        # Busca por itens (parte1) na memória de definições, se achou apresentar relação
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8'):
                print linha[1], "é um",catego
            elif parte1 == linha[1].encode('utf-8'):
                print linha[0], "é um",catego
            elif parte1 == linha[2].encode('utf-8'):
                print linha[1], "é um",catego
            elif parte1 == linha[3].encode('utf-8'):
                print linha[2], "é um",catego

        # Busca por categorias(catago) entre os itens já conhecidos, se achou apresenta relação
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8'):
                print linha[1], "é um",catego
                
	# Busca por categorias(catago) entre os itens já conhecidos, se achou apresenta relação
        cursor.execute("SELECT * FROM memo3")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8'):
                print linha[1], "é um",catego
    
    # buscar conectivo 'é ' na entrada e repartir em 2as partes:
    elif ' é ' in diga:
        sei = 1
        parte1, parte2 = diga.split(' é ')
        achou = 0
        # adiciona na memoria.db se a entrada é nova
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:  
            if parte1 == linha[0].encode('utf-8') or parte1 == linha[1].encode('utf-8') or parte1 == linha[2].encode('utf-8') or parte1 == linha[3].encode('utf-8') or parte2 == linha[0].encode('utf-8') or parte2 == linha[1].encode('utf-8') or parte2 == linha[2].encode('utf-8') or parte2 == linha[3].encode('utf-8'):
                #print "humm"
                achou = 1
        if achou == 0:
            print "Ok"
            cursor.execute("INSERT INTO memo1(sinon1, sinon2, sinon3, sinon4) VALUES('%s', '%s', '%s', '%s')" %(parte1, parte2, "None", "None"))
        # Busca por parte1 e parte2 na memória, se achou adiciona sinonimo
        cursor.execute("SELECT * FROM memo1")
        for linha in cursor:           
            # Adicionar a parte2 se parte1 for = a linha[0] apos imprime uma frase nova
            if (parte1 == linha[0].encode('utf-8')) and (parte2 != linha[1].encode('utf-8')) and (parte2 != linha[2].encode('utf-8')) and (parte2 != linha[3].encode('utf-8')) and (linha[2] == 'None'):
                cursor.execute("UPDATE memo1 SET sinon3='%s' WHERE sinon1='%s'" % (parte2,parte1))
                print parte2, "é", linha[1]
            elif (parte1 == linha[0].encode('utf-8')) and (parte2 != linha[1].encode('utf-8')) and (parte2 != linha[2].encode('utf-8')) and (parte2 != linha[3].encode('utf-8')) and (linha[2] != 'None'):
                cursor.execute("UPDATE memo1 SET sinon4='%s' WHERE sinon1='%s'" % (parte2,parte1))
                print parte2, "é", linha[1]
            # Adicionar a parte1 se parte2 for = a linha[0] apos imprime uma frase nova
            elif (parte2 == linha[0].encode('utf-8')) and (parte1 != linha[1].encode('utf-8')) and (parte1 != linha[2].encode('utf-8')) and (parte1 != linha[3].encode('utf-8')) and (linha[2] == 'None'):
                cursor.execute("UPDATE memo1 SET sinon3='%s' WHERE sinon1='%s'" % (parte1,parte2))
                print parte2, "é", linha[1]
            elif (parte2 == linha[0].encode('utf-8')) and (parte1 != linha[1].encode('utf-8')) and (parte1 != linha[2].encode('utf-8')) and (parte1 != linha[3].encode('utf-8')) and (linha[2] != 'None'):
                cursor.execute("UPDATE memo1 SET sinon4='%s' WHERE sinon1='%s'" % (parte1,parte2))
                print parte2, "é", linha[1]
            # Adicionar a parte2 se parte1 for = a linha[1] apos imprime uma frase nova
            elif (parte1 == linha[1].encode('utf-8')) and (parte2 != linha[0].encode('utf-8')) and (parte2 != linha[2].encode('utf-8')) and (parte2 != linha[3].encode('utf-8')):
                cursor.execute("UPDATE memo1 SET sinon3='%s' WHERE sinon2='%s'" % (parte2,parte1))
                print parte2, "é", linha[0]
            # Adicionar a parte2 se parte1 for = a linha[2] apos imprime uma frase nova
            elif (parte1 == linha[2].encode('utf-8')) and (parte2 != linha[0].encode('utf-8')) and (parte2 != linha[1].encode('utf-8')) and (parte2 != linha[3].encode('utf-8')):
                cursor.execute("UPDATE memo1 SET sinon4='%s' WHERE sinon3='%s'" % (parte2,parte1))
                print parte2, "é", linha[0]
            # Adicionar a parte1 se parte2 for = a linha[2] apos imprime uma frase nova
            elif (parte2 == linha[2].encode('utf-8')) and (parte1 != linha[0].encode('utf-8')) and (parte1 != linha[1].encode('utf-8')) and (parte2 != linha[3].encode('utf-8')):
                cursor.execute("UPDATE memo1 SET sinon4='%s' WHERE sinon3='%s'" % (parte1,parte2))
                print linha[0], "é", parte1

        # Busca por parte1 e parte2 na memória de categorias, se achou imprime frase nova
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:           
            # Busca por parte1 entre categorias apos imprime uma frase nova
            if (parte1 == linha[0].encode('utf-8')):
                print parte2, "é um", linha[0]
            # Busca por parte2 entre categorias apos imprime uma frase nova
            elif (parte2 == linha[0].encode('utf-8')):
                print parte1, "é um", linha[0]
            # Busca por parte1 entre os itens apos imprime uma frase nova
            elif (parte1 == linha[1].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[2].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[3].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[4].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[5].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[6].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[7].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[8].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[9].encode('utf-8')):
                print parte2, "é um", linha[0]
            elif (parte1 == linha[10].encode('utf-8')):
                print parte2, "é um", linha[0]
                
            # Busca por parte2 entre os itens apos imprime uma frase nova
            elif (parte2 == linha[1].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[2].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[3].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[4].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[5].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[6].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[7].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[8].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[9].encode('utf-8')):
                print parte1, "é um", linha[0]
            elif (parte2 == linha[10].encode('utf-8')):
                print parte1, "é um", linha[0]

    #imprime o que sabe sobre a expressão !*!*!*!*!*!*!*!*!*!**!*!*!*!*!*!*!*!*!**!*!*!*!*!**!*!*!*!*!*!**!*!*!*!*!*!**!*!*!*!*!*!**!*!
    elif 'o que sabe sobre ' in diga:
        sei = 1
        diga1,diga2 = diga.split('o que sabe sobre ')
        #print diga2
    # busca entre as definições
        cursor.execute("SELECT * FROM memo1")
        achou2 = 0
        for linha in cursor:
            # print linha
            if diga2 == linha[0].encode('utf-8'):
                print diga2, "é", linha[1]
                achou2 = 1
                if linha[2] != 'None':
                    print diga2, "é", linha[2]
                    achou2 = 1
                if linha[3] != 'None':
                    print diga2, "é", linha[3]
                    achou2 = 1
            elif diga2 == linha[1].encode('utf-8'):
                print diga2, "é", linha[0]
                achou2 = 1
                if linha[2] != 'None':
                    print diga2, "é", linha[2]
                    achou2 = 1
                if linha[3] != 'None':
                    print diga2, "é", linha[3]
                    achou2 = 1
            elif diga2 == linha[2].encode('utf-8'):
                print diga2, "é", linha[0]
                print diga2, "é", linha[1]
                achou2 = 1
                if linha[3] != 'None':
                    print diga2, "é", linha[3]
                    achou2 = 1
            elif diga == linha[3].encode('utf-8'):
                print diga2, "é", linha[0]
                print diga2, "é", linha[1]
                print diga2, "é", linha[2]
                achou2 = 1
        

        # busca entre as categorias masculinas
        cursor.execute("SELECT * FROM memo2")
        achou3 = 0
        for linha in cursor:
            # print linha
            if diga2 == linha[0].encode('utf-8'): 
                achou3 = 1
                if linha[2] == 'None':
                    #print "%s eh um%s" % (linha[1], linha[0])
                    print linha[1], "é um",linha[0]
                    achou3 = 1
                elif linha[3] == 'None':
                    print linha[2], "e", linha[1], "são",linha[0],'s'
                    achou3 = 1
                elif linha[4] == 'None':
                    #print "%s,%s e %s sao %ss" % (linha[3], linha[2], linha[1], linha[0])
                    print linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[5] == 'None':
                    print linha[4],",",linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[6] == 'None':
                    print linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[7] == 'None':
                    print linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[8] == 'None':
                    print linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[9] == 'None':
                    print linha[8],',', linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[10] == 'None':
                    print linha[9],',', linha[8],',', linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[10] != 'None':
                    print linha[10],',', linha[9],',', linha[8],',', linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                    
            # buscando entre os itens para ver se é igual ao que foi digitado         
            elif diga2 == linha[1].encode('utf-8'):
                print diga2, "é um",linha[0]
                catego = linha[0]
                # verifica se categoria do diga2 é um item de outra categoria masculina
                #cursor.execute("SELECT * FROM memo2")
		#for linha in cursor:
                #	if (catego == linha[1])^(catego == linha[2])^(catego == linha[3])^(catego == linha[4])^(catego == linha[5])^(catego == lgo == linha[2])^(categinha[6])^(catego == linha[7])^(catego == linha[8])^(catego == linha[9])^(catego == linha[10])
               # 		print diga, "é um", linha[0]
                # verifica se categoria do diga é um item de outra categoria feminina
                #cursor.execute("SELECT * FROM memo3")
                #for linha in cursor:
                #	if (catego == linha[1]) ^ (catego == linha[2]) ^ (catego == linha[3]) ^ (catego == linha[4]) ^ (catego == linha[5]) ^ (catego == lgo == linha[2]) ^ (categinha[6]) ^ (catego == linha[7]) ^ (catego == linha[8]) ^ (catego == linha[9]) ^ (catego == linha[10])
               # 		print diga, "é uma", linha[0]
        	#achou3 = 0
            elif diga2 == linha[2].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[3].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[4].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[5].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[6].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[7].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[8].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[9].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
            elif diga2 == linha[10].encode('utf-8'):
                print diga2, "é um",linha[0]
                achou3 = 1
                
        # busca entre as categorias femininas
        cursor.execute("SELECT * FROM memo3")
        #achou3 = 0
        for linha in cursor:
            # print linha
            if diga2 == linha[0].encode('utf-8'): 
                achou3 = 1
                if linha[2] == 'None':
                    print linha[1], "é uma",linha[0]
                    achou3 = 1
                elif linha[3] == 'None':
                    print linha[2], "e", linha[1], "são",linha[0],'s'
                    achou3 = 1
                elif linha[4] == 'None':
                    #print "%s,%s e %s sao %ss" % (linha[3], linha[2], linha[1], linha[0])
                    print linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[5] == 'None':
                    print linha[4],",",linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[6] == 'None':
                    print linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[7] == 'None':
                    print linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[8] == 'None':
                    print linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[9] == 'None':
                    print linha[8],',', linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[10] == 'None':
                    print linha[9],',', linha[8],',', linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                elif linha[10] != 'None':
                    print linha[10],',', linha[9],',', linha[8],',', linha[7],',', linha[6],',', linha[5],',', linha[4],',', linha[3],',', linha[2], "e", linha[1], "são",linha[0],"s"
                    achou3 = 1
                    
            # buscando entre os itens para ver se é igual ao que foi digitado         
            elif diga2 == linha[1].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[2].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[3].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[4].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[5].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[6].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[7].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[8].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[9].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1
            elif diga2 == linha[10].encode('utf-8'):
                print diga2, "é uma",linha[0]
                achou3 = 1



    #imprime algo relacionado ao que foi dito !*!*!*!*!*!*!*!*!*!**!*!*!*!*!*!*!*!*!**!*!*!*!*!*
    else:
        # busca entre os itens das categorias masculinas
        cursor.execute("SELECT * FROM memo2")
        for linha in cursor:
                if linha[1].encode('utf-8') in diga:
                        if linha[2] != 'None':
                                print linha[2], "também é um",linha[0]
                                sei = 1
                        else:
                                print linha[1], "é um",linha[0]
                                sei = 1
                elif linha[2].encode('utf-8') in diga:
                                print linha[1], "também é um",linha[0]
                                sei = 1
                elif linha[3].encode('utf-8') in diga:
                                print linha[2], "também é um",linha[0]
                                sei = 1
                elif linha[4].encode('utf-8') in diga:
                                print linha[3], "também é um",linha[0]
                                sei = 1
                elif linha[5].encode('utf-8') in diga:
                                print linha[4], "também é um",linha[0]
                                sei = 1
                elif linha[6].encode('utf-8') in diga:
                                print linha[5], "também é um",linha[0]
                                sei = 1
                elif linha[7].encode('utf-8') in diga:
                                print linha[6], "também é um",linha[0]
                                sei = 1
                elif linha[8].encode('utf-8') in diga:
                                print linha[7], "também é um",linha[0]
                                sei = 1
                elif linha[9].encode('utf-8') in diga:
                                print linha[8], "também é um",linha[0]
                                sei = 1
                elif linha[10].encode('utf-8') in diga:
                                print linha[9], "também é um",linha[0]
                                sei = 1

        # busca entre os itens das categorias femininas
        if sei == 0:
                cursor.execute("SELECT * FROM memo3")
                for linha in cursor:
                        if linha[1].encode('utf-8') in diga:
                                if linha[2] != 'None':
                                        print linha[2], "também é uma",linha[0]
                                        sei = 1
                                else:
                                        print linha[1], "é uma",linha[0]
                                        sei = 1
                        elif linha[2].encode('utf-8') in diga:
                                        print linha[1], "também é uma",linha[0]
                                        sei = 1
                        elif linha[3].encode('utf-8') in diga:
                                        print linha[2], "também é uma",linha[0]
                                        sei = 1
                        elif linha[4].encode('utf-8') in diga:
                                        print linha[3], "também é uma",linha[0]
                                        sei = 1
                        elif linha[5].encode('utf-8') in diga:
                                        print linha[4], "também é uma",linha[0]
                                        sei = 1
                        elif linha[6].encode('utf-8') in diga:
                                        print linha[5], "também é uma",linha[0]
                                        sei = 1
                        elif linha[7].encode('utf-8') in diga:
                                        print linha[6], "também é uma",linha[0]
                                        sei = 1
                        elif linha[8].encode('utf-8') in diga:
                                        print linha[7], "também é uma",linha[0]
                                        sei = 1
                        elif linha[9].encode('utf-8') in diga:
                                        print linha[8], "também é uma",linha[0]
                                        sei = 1
                        elif linha[10].encode('utf-8') in diga:
                                        print linha[9], "também é uma",linha[0]
                                        sei = 1

        # busca entre as definições,sinonimos
        if sei == 0:
                cursor.execute("SELECT * FROM memo1")
                for linha in cursor:
                        if linha[0].encode('utf-8') in diga:
                                print linha[0], "é",linha[1]
                                sei = 1
                        elif linha[1].encode('utf-8') in diga:
                                print linha[0], "é",linha[1]
                                sei = 1
                        elif linha[2].encode('utf-8') in diga:
                                print linha[0], "é",linha[2]
                                sei = 1
                        elif linha[3].encode('utf-8') in diga:
                                print linha[0], "é",linha[2]
                                sei = 1

        # busca entre as categorias masculinas
        if sei == 0:
                cursor.execute("SELECT * FROM memo2")
                for linha in cursor:
                        if linha[0].encode('utf-8') in diga:
                                print linha[1], "é um",linha[0]
                                sei = 1

                # busca entre as categorias femininas
        if sei == 0:
                cursor.execute("SELECT * FROM memo3")
                for linha in cursor:
                        if linha[0].encode('utf-8') in diga:
                                print linha[1], "é uma",linha[0]
                                sei = 1
                
    if achou2 == 0 and achou3 == 0 and sei == 0 and diga != "fui":
            print "Não sei sobre isso"

# confirma os dados para o banco de dados e fecha o banco de dados
conn.commit()
cursor.close()
conn.close()      
exit
