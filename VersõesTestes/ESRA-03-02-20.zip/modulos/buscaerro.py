# -*- coding: UTF-8 -*-
# Versão Linux
# Copyright 2012, 2016 Carlos Adrian Rupp
#from __future__ import unicode_literals
import sqlite3
import shutil
# módulo que busca contradições

conn=sqlite3.connect('memoria2.db',timeout=30000)
cursor=conn.cursor()

# função que fecha a conexão com o DB
def fecha():
  cursor.close()
  conn.close()   

# função que abre a conexão com o DB
def abre():
  conn=sqlite3.connect('memoria2.db',timeout=30000)
  cursor=conn.cursor()

# função que apresenta e trata o erro, casos normais
def mostra_erro_n(parte1,conectivo,parte2,conectivob):
  print " - Não foi isso que tu me disse antes. Qual das opções está correta?"
  print "   1. "+parte1+conectivob+parte2
  print "   2. "+parte1+conectivo+parte2
  print "   3. Não sei"
  print " "
  opcao=raw_input("Número: ")
  #.decode('utf-8')
  print " "
  if opcao == "1":
    return 1
  # se antiga estava certa
  elif opcao == "2":
    cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
    conn.commit()
    # Se essa mesma frase está nas conclusões:
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
        cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
        conn.commit()
  elif opcao == "3":
    cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
    conn.commit()
    # Se essa mesma frase está nas conclusões:
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
        cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
        conn.commit()
    return 1

# função que apresenta e trata o erro, casos normais - entre o que foi dito e o que foi concluido
def mostra_erro_n2(parte1,conectivo,parte2,conectivob):
  abre()
  print " - Achei uma contradição. Qual das opções está correta?"
  print "   1. "+parte1+conectivob+parte2
  print "   2. "+parte1+conectivo+parte2
  print "   3. Não sei"
  print " "
  opcao=raw_input("Número: ")
  #.decode('utf-8')
  if opcao == "1":
    return 1
  # se a frase pesquisada está correta e não a da conclusão:
  elif opcao == "2":
    cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
    conn.commit()
    # Se essa mesma frase está nas frases digitadas:
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
        cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
        conn.commit()
    print " "
    print " - Então uma das seguintes frases está errada também. Por favor, reescreva a frase errada tirando ou incluindo o 'não':"
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[0].encode('utf-8') or parte1 == linha[2].encode('utf-8') or parte2 == linha[0].encode('utf-8') or parte2 == linha[2].encode('utf-8'):
        if linha[1].encode('utf-8') == " foi depois d" or linha[1].encode('utf-8') == " não foi depois d" or linha[1].encode('utf-8') == " foi antes d" or linha[1].encode('utf-8') == " não foi antes d":
          print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+"o(a) "+linha[2].encode('utf-8')
        else:
          print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
  elif opcao == "3":
    cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivo, parte2))
    conn.commit()
    # Se essa mesma frase está nas conclusões:
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
        cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
        conn.commit()
    return 1


# Função que busca contradições
def buscaerro(parte1, conectivo, parte2):
  shutil.copyfile("memoria.db","memoria2.db")
  conn=sqlite3.connect('memoria2.db')
  cursor=conn.cursor()
  parte1 = parte1
  conectivo = conectivo
  parte2 = parte2
  # buscando contradições diretas de negação entre frases do usuário
  # variável para os conectivos que tem versão masculina, feminina e neutra
  coneca = 0
  # variável para os conectivos que aceitam troca entre parte1 e parte2
  invertido = 0
  # variável que guarda a versão negativa do conectivo que entrou nesta função
  conectivob = "   "

  # x NÃO é o oposto de y com x é o oposto de y
  if conectivo == " não é o oposto de ":
    conectivob = " é o oposto de "
    invertido = 1
  elif conectivo == " é o oposto de ":
    conectivob = " não é o oposto de "
    invertido = 1
    
  elif conectivo == " não é igual a ":
    conectivob = " é igual a "
    invertido = 1
  elif conectivo == " é igual a ":
    conectivob = " não é igual a "
    invertido = 1
    
  elif conectivo == " não é uma ":
    conectivob = " é uma "
  elif conectivo == " é uma ":
    conectivob = " não é uma "

  elif conectivo == " não é um ":
    conectivob = " é um "
  elif conectivo == " é um ":
    conectivob = " não é um "

  if conectivob != "   ":
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	mostra_erro_n(parte1,conectivo,parte2,conectivob)

    # para os casos que aceitam ordem invertida de parte1 e parte2
    if invertido == 1:
      for linha in cursor.execute("SELECT * FROM entra1"):
	 if parte2 == linha[0].encode('utf-8') and parte1 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	   mostra_erro_n(parte1,conectivo,parte2,conectivob)
	   

  # contradição tipo y é igual a z, y é o oposto de z
  # variável para os conectivos que aceitam troca entre parte1 e parte2
  invertido = 0
  # variável que guarda a versão oposta do conectivo que entrou nesta função
  conectivob = "   "
  if conectivo == " é igual a ":
    conectivob = " é o oposto de "
    invertido = 1
  elif conectivo == " é o oposto de ":
    conectivob = " é igual a "
    invertido = 1

  if conectivob != "   ":
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	mostra_erro_n(parte1,conectivo,parte2,conectivob)
	
    # para os casos que aceitam ordem invertida de parte1 e parte2
    if invertido == 1:
      for linha in cursor.execute("SELECT * FROM entra1"):
	 if parte2 == linha[0].encode('utf-8') and parte1 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	   mostra_erro_n(parte1,conectivo,parte2,conectivob)

  # para os conectivos 'foi depois d' ou foi antes d'
  if conectivo == " não foi depois d":
    conectivob = " foi depois d"
    coneca = 1
  elif conectivo == " foi depois d":
    conectivob = " não foi depois d"
    coneca = 1
  elif conectivo == " não foi antes d":
    conectivob = " foi antes d"
    coneca = 1
  elif conectivo == " foi antes d":
    conectivob = " não foi antes d"
    coneca = 1
  if coneca == 1:
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	print " - Não foi isso que você me disse antes. Qual das opções está correta?"
	print "   1. "+parte1+conectivob+"o(a) "+parte2
	print "   2. "+parte1+conectivo+"o(a) "+parte2
	print "   3. Não sei"
	print " "
	opcao=raw_input("Número: ")
	#.decode('utf-8')
	print " "
	# se antiga estava certa
	if opcao == "1":
	  return 1
	# se nova frase estiver certa:
	elif opcao == "2":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM concl1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	elif opcao == "3":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
	  conn.commit()
	  return 1

  # para: 'x foi antes de y', 'x não foi antes de y', x foi depois de y', x não foi depois de y'
  if coneca == 1 and conectivo != " não foi depois d" and conectivo != " não foi antes d":
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[2].encode('utf-8') and parte2 == linha[0].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
	print " - Não foi isso que você me disse antes. Qual das opções está correta?"
	print "   1. "+parte1+conectivo+"o(a) "+parte2
	print "   2. "+parte2+conectivo+"o(a) "+parte1
	print "   3. Não sei"
	print " "
	opcao=raw_input("Número: ")
	#.decode('utf-8')
	print " "
	# se antiga estava certa
	if opcao == "1":
	  return 1
	# se nova frase estiver certa:
	elif opcao == "2":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte2, conectivo, parte1))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM concl1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	elif opcao == "3":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte2, conectivo, parte1))
	  conn.commit()
	  return 1
	
  # Contradição tipo: y foi depois de z, y foi antes de z
  conectivob = "   "
  if conectivo == " foi depois d":
    conectivob = " foi antes d"
    coneca = 1
  elif conectivo == " foi antes d":
    conectivob = " foi depois d"
    coneca = 1
  if conectivob != "   ":
    for linha in cursor.execute("SELECT * FROM entra1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	print " - Não foi isso que tu me disse antes. Qual das opções está correta?"
	print "   1. "+parte1+conectivob+"o(a) "+parte2
	print "   2. "+parte1+conectivo+"o(a) "+parte2
	print "   3. Não sei"
	print " "
	opcao=raw_input("Número: ")
	#.decode('utf-8')
	print " "
	# se antiga estava certa
	if opcao == "1":
	  return 1
	elif opcao == "2":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM concl1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	elif opcao == "3":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM concl1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	  return 1



  # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  # + Para contradições entre o que foi dito e o que o sistema concluiu +
  # +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  parte1 = parte1
  conectivo = conectivo
  parte2 = parte2
  # buscando contradições diretas de negação entre frases do usuário
  # variável para os conectivos que tem versão masculina, feminina e neutra
  coneca = 0
  # variável para os conectivos que aceitam troca entre parte1 e parte2
  invertido = 0
  # variável que guarda a versão negativa do conectivo que entrou nesta função
  conectivob = "   "

  # x NÃO é o oposto de y com x é o oposto de y
  if conectivo == " não é o oposto de ":
    conectivob = " é o oposto de "
    invertido = 1
  elif conectivo == " é o oposto de ":
    conectivob = " não é o oposto de "
    invertido = 1
    
  elif conectivo == " não é igual a ":
    conectivob = " é igual a "
    invertido = 1
  elif conectivo == " é igual a ":
    conectivob = " não é igual a "
    invertido = 1
    
  elif conectivo == " não é uma ":
    conectivob = " é uma "
  elif conectivo == " é uma ":
    conectivob = " não é uma "

  elif conectivo == " não é um ":
    conectivob = " é um "
  elif conectivo == " é um ":
    conectivob = " não é um "

  if conectivob != "   ":
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
        #fecha()
	mostra_erro_n2(parte1,conectivo,parte2,conectivob)
	abre()

    # para os casos que aceitam ordem invertida de parte1 e parte2
    if invertido == 1:
      for linha in cursor.execute("SELECT * FROM concl1"):
	 if parte2 == linha[0].encode('utf-8') and parte1 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	   mostra_erro_n2(parte1,conectivo,parte2,conectivob)

  # contradição tipo y é igual a z, y é o oposto de z
  # variável para os conectivos que aceitam troca entre parte1 e parte2
  invertido = 0
  # variável que guarda a versão oposta do conectivo que entrou nesta função
  conectivob = "   "
  if conectivo == " é igual a ":
    conectivob = " é o oposto de "
    invertido = 1
  elif conectivo == " é o oposto de ":
    conectivob = " é igual a "
    invertido = 1

  if conectivob != "   ":
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	mostra_erro_n2(parte1,conectivo,parte2,conectivob)
	
    # para os casos que aceitam ordem invertida de parte1 e parte2
    if invertido == 1:
      for linha in cursor.execute("SELECT * FROM concl1"):
	 if parte2 == linha[0].encode('utf-8') and parte1 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	   mostra_erro_n2(parte1,conectivo,parte2,conectivob)

  # para os conectivos 'foi depois d' ou foi antes d'
  if conectivo == " não foi depois d":
    conectivob = " foi depois d"
    coneca = 1
  elif conectivo == " foi depois d":
    conectivob = " não foi depois d"
    coneca = 1
  elif conectivo == " não foi antes d":
    conectivob = " foi antes d"
    coneca = 1
  elif conectivo == " foi antes d":
    conectivob = " não foi antes d"
    coneca = 1
  if coneca == 1:
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	print " - Achei uma contradição. Qual das opções está correta?"
	print "   1. "+parte1+conectivob+"o(a) "+parte2
	print "   2. "+parte1+conectivo+"o(a) "+parte2
	print "   3. Não sei"
	print " "
	opcao=raw_input("Número: ")
	#.decode('utf-8')
	print " "
	# se antiga estava certa
	if opcao == "1":
	  return 1
	# se nova frase estiver certa:
	elif opcao == "2":
            conn.commit()
            print " "
            print " - Então uma das seguintes frases está errada também. Por favor, reescreva a frase errada tirando ou incluindo o 'não':"
            for linha in cursor.execute("SELECT * FROM entra1"):
                if parte1 == linha[0].encode('utf-8') or parte1 == linha[2].encode('utf-8') or parte2 == linha[0].encode('utf-8') or parte2 == linha[2].encode('utf-8'):
                  if linha[1].encode('utf-8') == " foi depois d" or linha[1].encode('utf-8') == " não foi depois d" or linha[1].encode('utf-8') == " foi antes d" or linha[1].encode('utf-8') == " não foi antes d":
                    print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+"o(a) "+linha[2].encode('utf-8')
                  else:
                    print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
	elif opcao == "3":
	  cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM concl1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	  return 1

  # para: 'x foi antes de y', 'x não foi antes de y', x foi depois de y', x não foi depois de y'
  if coneca == 1 and conectivo != " não foi depois d" and conectivo != " não foi antes d":
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[2].encode('utf-8') and parte2 == linha[0].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
	print " - Achei uma contradição. Qual das opções está correta?"
	print "   1. "+parte1+conectivo+"o(a) "+parte2
	print "   2. "+parte2+conectivo+"o(a) "+parte1
	print "   3. Não sei"
	print " "
	opcao=raw_input("Número: ")
	#.decode('utf-8')
	print " "
	# se antiga estava certa
	if opcao == "1":
	  return 1
	# se nova frase estiver certa:
	elif opcao == "2":
	  cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte2, conectivo, parte1))
	  conn.commit()
	  print " "
	  print " - Então uma das seguintes frases está errada também. Por favor, reescreva a frase errada tirando ou incluindo o 'não':"
	  for linha in cursor.execute("SELECT * FROM entra1"):
            if parte1 == linha[0].encode('utf-8') or parte1 == linha[2].encode('utf-8') or parte2 == linha[0].encode('utf-8') or parte2 == linha[2].encode('utf-8'):
              if linha[1].encode('utf-8') == " foi depois d" or linha[1].encode('utf-8') == " não foi depois d" or linha[1].encode('utf-8') == " foi antes d" or linha[1].encode('utf-8') == " não foi antes d":
                print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+"o(a) "+linha[2].encode('utf-8')
              else:
                print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
	elif opcao == "3":
	  cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte2, conectivob, parte1))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM entra1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	  return 1
	
  # Contradição tipo: y foi depois de z, y foi antes de z
  conectivob = "   "
  if conectivo == " foi depois d":
    conectivob = " foi antes d"
    coneca = 1
  elif conectivo == " foi antes d":
    conectivob = " foi depois d"
    coneca = 1
  if conectivob != "   ":
    for linha in cursor.execute("SELECT * FROM concl1"):
      if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivob == linha[1].encode('utf-8'):
	print " - Achei uma contradição. Qual das opções está correta?"
	print "   1. "+parte1+conectivob+"o(a) "+parte2
	print "   2. "+parte1+conectivo+"o(a) "+parte2
	print "   3. Não sei"
	print " "
	opcao=raw_input("Número: ")
	#.decode('utf-8')
	print " "
	# se antiga estava certa
	if opcao == "1":
	  return 1
	elif opcao == "2":
	  cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte2, conectivob, parte1))
	  conn.commit()
	  print " - Então uma das seguintes frases está errada também. Por favor, reescreva a frase errada tirando ou incluindo o 'não':"
	  for linha in cursor.execute("SELECT * FROM entra1"):
            if parte1 == linha[0].encode('utf-8') or parte1 == linha[2].encode('utf-8') or parte2 == linha[0].encode('utf-8') or parte2 == linha[2].encode('utf-8'):
              if linha[1].encode('utf-8') == " foi depois d" or linha[1].encode('utf-8') == " não foi depois d" or linha[1].encode('utf-8') == " foi antes d" or linha[1].encode('utf-8') == " não foi antes d":
                print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+"o(a) "+linha[2].encode('utf-8')
              else:
                print " - "+linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
	elif opcao == "3":
	  cursor.execute("DELETE FROM concl1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte2, conectivob, parte1))
	  conn.commit()
          # Se essa mesma frase está nas conclusões:
          for linha in cursor.execute("SELECT * FROM entra1"):
            if parte1 == linha[0].encode('utf-8') and conectivob == linha[1].encode('utf-8') and parte2 == linha[2].encode('utf-8'):
              cursor.execute("DELETE FROM entra1 WHERE parte1 = '%s' AND conec = '%s' AND parte2 = '%s'" %(parte1, conectivob, parte2))
              conn.commit()
	  return 1

  shutil.copyfile("memoria2.db","memoria.db")
  
#cursor.close()
#conn.close()    