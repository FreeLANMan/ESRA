# -*- coding: UTF-8 -*-
# Versão Linux
# Copyright 2012, 2020 Carlos Adrian Rupp
#from __future__ import unicode_literals
#from random import *
import sqlite3
from modulos.buscaerro import *
import shutil


# função que grava a conclusão nova
def grava_indutivo(bloco, conector, item2):
  achou = 0
  # testar para ver se entra em contradição com o discurso do usuário
  #fecha()
  #contra = buscaerro(bloco,conector,item2)
  #abre()
  #if contra != 1:
  #print " cheguei a uma conclusão e não encontrei contradições, conector: "+conector

  # checa se não tá concluindo algo tipo "maçã é igual a maçã"
  if bloco != item2:
    
    # checa se está tentando gravar com uma categoria neutra (é um(a)) algo q tem gênero conhecido.
    # para afirmação
    if conector == " é um(a) ":
      for linha in cursor.execute("SELECT * FROM ENTRA1"):
          if (linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " não é um ") and linha[2].encode('utf-8') == item2:
            conector = " é um "
          if (linha[1].encode('utf-8') == " é uma " or linha[1].encode('utf-8') == " não é uma ") and linha[2].encode('utf-8') == item2:
            conector = " é uma "
    # para negação
    if conector == " não é um(a) ":
      for linha in cursor.execute("SELECT * FROM ENTRA1"):
          if (linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " não é um ") and linha[2].encode('utf-8') == item2:
            conector = " não é um "
          if (linha[1].encode('utf-8') == " é uma " or linha[1].encode('utf-8') == " não é uma ") and linha[2].encode('utf-8') == item2:
            conector = " não é uma "

    # checa se já não tinha essa conclusão, só que com sinônimo
    # 1º reunir todos os sinônimos:
    sinonimos = ["    "]
    sinonimos.remove('    ')
    x = -1
    for linha in cursor.execute("SELECT * FROM concl1"):
      if (bloco == linha[0].encode('utf-8') or bloco == linha[2].encode('utf-8')) and " é igual a " == linha[1].encode('utf-8'):
        sinonimos.insert(x+1, linha[2].encode('utf-8'))
        x = x + 1
        print "achei sinonimo: "+ linha[2].encode('utf-8')
    for linha in cursor.execute("SELECT * FROM ENTRA1"):
      if (bloco == linha[0].encode('utf-8') or bloco == linha[2].encode('utf-8')) and " é igual a " == linha[1].encode('utf-8'):
        sinonimos.insert(x+1, linha[2].encode('utf-8'))
        x = x + 1
        print "achei sinonimo: "+ linha[2].encode('utf-8')
    # e se esses sinônimos tiverem sinônimos
    for i in sinonimos:
      for linha in cursor.execute("SELECT * FROM concl1"):
        if i == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
          sinonimos.insert(x+1, linha[2].encode('utf-8'))
          x = x + 1
      for linha in cursor.execute("SELECT * FROM ENTRA1"):
        if i == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
          sinonimos.insert(x+1, linha[2].encode('utf-8'))
          x = x + 1

    # 2º comparar pra ver se não tinha essa conclusão com sinônimo:
    for i in sinonimos:
      for linha in cursor.execute("SELECT * FROM concl1"):
        if i == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and item2 == linha[2].encode('utf-8'):
          achou = 1
          print "achei sinonimo"

    for i in sinonimos:
      # checa se essa frase não tinha sido dita pelo usuário, se não tinha grava
      for linha in cursor.execute("SELECT * FROM ENTRA1"):
        if i == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and item2 == linha[2].encode('utf-8'):
          achou = 1
          print "achei sinonimo"


    # checa se já não tinha essa indução, se não tinha grava
    for linha in cursor.execute("SELECT * FROM indutivo"):
      if bloco == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[2].encode('utf-8'):
        achou = 1
      elif bloco == linha[2].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
          achou = 1

    # checa se essa frase não tinha sido dita pelo usuário, se não tinha grava
    for linha in cursor.execute("SELECT * FROM ENTRA1"):
      if bloco == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[2].encode('utf-8'):
        achou = 1
      elif bloco == linha[2].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
          achou = 1

    if achou == 0:
      #print "indutiva: "+bloco+conector+item2
      cursor.execute("INSERT INTO indutivo(parte1, conec, parte2) VALUES('%s', '%s', '%s')" %(bloco, conector, item2))
      conn.commit()

# Função principal que chega nas conclusões partindo das falas do usuário ou de outras conclusões anteriores
def rindutivo(bloco):
  shutil.copyfile("memoria.db","memoria2.db")
  entendi = 0
  achou = 0
  achou2 = 0
  achou3 = 0
  diga1 = "   "
  diga2 = "   "

  # +++++++++++++++
  # + RACIOCÍNIOS +
  # +++++++++++++++
  
  if achou == 0:

    # Raciocínios ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #print "Raciocínios de nível 222222222222222222222222222222"

    # raciocinios para falas do usuário, quando bloco é a parte1
    


    # raciocínio: A é um y, b é um y, a é um x, b é um x, então se c é um y, c é um x, e com y
    conector = "   "
    tipo1 = "   "
    tipo2 = "   "
    item = "   "
    item3 = "   "
    itens = ["    "]
    itens.remove('    ')
    x = -1
    achei = 0
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo 
    # Buscando no que foi dito
    for linha in cursor.execute("SELECT * FROM ENTRA1"):
      if bloco == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')):
        #Achou a expressão buscada numa frase com 'é um' ou 'é uma'
        tipo1 = linha[2].encode('utf-8')
        #print "tipo1"+linha[2].encode('utf-8')
        # Agora achar outra coisa na mesma categoria.
        # 2º premissa ' é um '
        #conector = " é um "
        # Buscando nas falas do usuário
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM ENTRA1"):
          if tipo1 == linha[2].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and bloco != linha[0].encode('utf-8'):
            #encontramos o 2º item da categoria.
            item2 = linha[0].encode('utf-8')
            #print "item2 "+item2
            if item2 != "   ":
              # agora precisamos achar a 2º categoria em comum.
              # buscando nas falas do usuário:
              for linha in cursor.execute("SELECT * FROM ENTRA1"):
                if bloco == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and (tipo1 != linha[2].encode('utf-8')):
                  tipo2 = linha[2].encode('utf-8')
                  #print "tipo2 "+tipo2
                  conector = linha[1].encode('utf-8')
                  # encontramos outra categoria/tipo onde também está o bloco/expressão procurada
                  # agora buscamos ver se nosso item2 também está no tipo2:
                  for linha in cursor.execute("SELECT * FROM ENTRA1"):
                    if item2 == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and (tipo2 == linha[2].encode('utf-8')):
                      # Pronto, agora temos 2 itens que compartilham 2 categorias.
                      # Precisamos agora do item3, primeiro vamos procurar no tipo1/categoria, nas falas do usuário 
                      for linha in cursor.execute("SELECT * FROM ENTRA1"):
                        if item2 != linha[0].encode('utf-8') and bloco != linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and (tipo1 == linha[2].encode('utf-8')):
                          itens.insert(x+1, linha[0].encode('utf-8'))
                          x = x + 1
                      # vamos procurar no tipo1/categoria, nas conclusões
                      for linha in cursor.execute("SELECT * FROM concl1"):
                        if item2 != linha[0].encode('utf-8') and bloco != linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and (tipo1 == linha[2].encode('utf-8')):
                          itens.insert(x+1, linha[0].encode('utf-8'))
                          x = x + 1
                      # vamos procurar no tipo1/categoria, no indutivo
                      for linha in cursor.execute("SELECT * FROM indutivo"):
                        if item2 != linha[0].encode('utf-8') and bloco != linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and (tipo1 == linha[2].encode('utf-8')):
                          itens.insert(x+1, linha[0].encode('utf-8'))
                          x = x + 1


                          # Pronto, agora temos um item3 na categoria1/tipo1, e de modo descuidado, concluimos que ele tá na categoria2/tipo2 tamb.
                      # gravar cada item
                      for i in itens:
                        #print "item "+i
                        grava_indutivo(i, conector, tipo2)







    # Buscando no que foi concluido
    # Buscando no que foi imaginado (indutivo)










  shutil.copyfile("memoria2.db","memoria.db")

  #conn.commit()

  # confirma os dados para o banco de dados e fecha o banco de dados
  
  #conn.close()      

  
