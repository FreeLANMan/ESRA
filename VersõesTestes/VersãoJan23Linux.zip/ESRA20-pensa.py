# -*- coding: UTF-8 -*-
# Versão Linux
# Copyright 2012, 2020 Carlos Adrian Rupp
#from __future__ import unicode_literals
import sqlite3
from random import *
from modulos.raciocinio import *
#from modulos.buscaerro import *
#from modulos.buscaresposta import *
from modulos.indutivo import *
#import shutil

# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

# ESRA versão 2020

#shutil.copyfile("memoria2.db","memoria.db")

#diga = "oi"
conn=sqlite3.connect('memoria.db')
cursor=conn.cursor()

bloco = " "

print "   "
print "Olá, bem vindo ao ESRA (Esboço de Sistema de Raciocinio Artificial)"
print "Versão 2020 - Para Linux- Versão teste"
print "   "
print "Utilitário de reflexão"
print "Utilitário de reflexão"

# testa se o banco de dados está vazio
cursor.execute("SELECT * FROM ENTRA1")
conteudo = cursor.fetchone()
if conteudo is None:
  print "ATENÇÃO! Memória vazia!"
  cursor.close()
  conn.close()  
  exit

print "Refletindo sobre..."

# Refletindo sobre o que já foi dito pelo usuário
for linha in cursor.execute("SELECT * FROM entra1"):
  bloco = linha[0].encode('utf-8')
  print bloco
  raciocinio(bloco)
  bloco = linha[2].encode('utf-8')
  print bloco
  raciocinio(bloco)

# Refletindo sobre o que já foi concluido
for linha in cursor.execute("SELECT * FROM concl1"):
  bloco = linha[0].encode('utf-8')
  print bloco
  raciocinio(bloco)
  rindutivo(bloco)
  bloco = linha[2].encode('utf-8')
  print bloco
  raciocinio(bloco)
  rindutivo(bloco)

# Refletindo sobre o que já foi concluido indutivo
for linha in cursor.execute("SELECT * FROM indutivo"):
  bloco = linha[0].encode('utf-8')
  print bloco
  raciocinio(bloco)
  rindutivo(bloco)
  bloco = linha[2].encode('utf-8')
  print bloco
  raciocinio(bloco)
  rindutivo(bloco)

# Refletindo sobre o que já foi dito pelo usuário - Agora indutivo
for linha in cursor.execute("SELECT * FROM entra1"):
  bloco = linha[0].encode('utf-8')
  print bloco
  rindutivo(bloco)
  bloco = linha[2].encode('utf-8')
  print bloco
  rindutivo(bloco)

# Refletindo sobre o que já foi concluido - Agora indutivo
for linha in cursor.execute("SELECT * FROM concl1"):
  bloco = linha[0].encode('utf-8')
  print bloco
  rindutivo(bloco)
  bloco = linha[2].encode('utf-8')
  print bloco
  rindutivo(bloco)






print "... Terminei."
cursor.close()
conn.close()  
exit
