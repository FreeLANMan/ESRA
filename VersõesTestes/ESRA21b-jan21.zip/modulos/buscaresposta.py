# -*- coding: UTF-8 -*-
# Versão Linux
# Copyright 2012, 2020 Carlos Adrian Rupp
#from __future__ import unicode_literals
import sqlite3
from modulos.raciocinio import *
import shutil

conn=sqlite3.connect('memoria2.db')
cursor=conn.cursor()


# função que confere se o que seria dito pelo sistema não foi dito antes na sessão
def checadito(parte1,conector,parte2):
  for linha in cursor.execute("SELECT * FROM dito1"):
    if linha[0].encode('utf-8') == parte1 and linha[1].encode('utf-8') == conector and linha[2].encode('utf-8') == parte2:
      return 1
    if linha[1].encode('utf-8') == " não é igual a " or linha[1].encode('utf-8') == " é igual a " or linha[1].encode('utf-8') == " não é o oposto de " or linha[1].encode('utf-8') == " é o oposto de ":
      if linha[2].encode('utf-8') == parte1 and linha[0].encode('utf-8') == parte2:
        return 1
  return 0



# função que busca nas conclusões expressão exata
def busca_concl1(bloco):
  falei = 0
  for linha in cursor.execute("SELECT * FROM concl1"):
    if bloco == linha[0].encode('utf-8') and falei == 0:
      if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
        conector = linha[1].encode('utf-8')
        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
          conector = conector+"o(a) "
        #print " - Encontrei uma conclusão baseada em expressão com x itens (parte1)"
        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
        falei = 1
        return 1
  for linha in cursor.execute("SELECT * FROM concl1"):
    if bloco == linha[2].encode('utf-8') and falei == 0:
      checa = checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
      if checa != 1:
        conector = linha[1].encode('utf-8')
        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
          conector = conector+"o(a) "
        #print " - Encontrei uma conclusão baseada em expressão com x itens (parte2)"
        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
        falei = 1
        return 1
  return 0


# função que busca nas conclusões
def busca_concl1(bloco):
  falei = 0
  for linha in cursor.execute("SELECT * FROM concl1"):
    if bloco in linha[0].encode('utf-8') and falei == 0:
      if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
        conector = linha[1].encode('utf-8')
        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
          conector = conector+"o(a) "
        #print " - Encontrei uma conclusão baseada em expressão com x itens (parte1)"
        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
        falei = 1
        return 1
  for linha in cursor.execute("SELECT * FROM concl1"):
    if bloco in linha[2].encode('utf-8') and falei == 0:
      checa = checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
      if checa != 1:
        conector = linha[1].encode('utf-8')
        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
          conector = conector+"o(a) "
        #print " - Encontrei uma conclusão baseada em expressão com x itens (parte2)"
        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
        falei = 1
        return 1
  return 0

# função que busca nas falas dos usuários
def busca_entra1(bloco):
  falei = 0
  for linha in cursor.execute("SELECT * FROM entra1"):
    if bloco in linha[0].encode('utf-8') and falei == 0:
      checa = checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
      if checa != 1:
        conector = linha[1].encode('utf-8')
        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
          conector = conector+"o(a) "
        #print " - Encontrei uma conclusão baseada em expressão com x itens (parte1)"
        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
        falei = 1
        return 1
    if bloco in linha[2].encode('utf-8') and falei == 0:
      checa = checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
      if checa != 1:
        conector = linha[1].encode('utf-8')
        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
          conector = conector+"o(a) "
        #print " - Encontrei uma conclusão baseada em expressão com x itens (parte2)"
        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
        falei = 1
        return 1
  return 0

# função que quarda o que foi dito na sessão
def grava_dito1(parte1, conectivo, parte2):
  achou = 0
  #print "Gravando o que foi dito... (buscaresposta)"
  for linha in cursor.execute("SELECT * FROM dito1"):
    if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
      achou = 1
    if conectivo == " não é igual a " or conectivo == " é igual a " or conectivo == " não é o oposto de " or conectivo == " é o oposto de ":
      if parte1 == linha[2].encode('utf-8') and parte2 == linha[0].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
        achou = 1
  if achou == 0:
    cursor.execute("INSERT INTO dito1(parte1, conec, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
    conn.commit()



# Função principal que busca algo para dizer
def buscaresposta(diga):
  #conn=sqlite3.connect('memoria.db')
  #cursor=conn.cursor()
  falei = 0
  #raciocinio(diga)
  shutil.copyfile("memoria.db","memoria2.db")
  
  # Resposta 1: Responder com sinônimo não dito 1111111111111111111111111111111111111111111111111111111111111111 (funcionando!)
  # Buscando nas conclusões
  for linha in cursor.execute("SELECT * FROM concl1"):
    if linha[1].encode('utf-8') == " é igual a ":
      if linha[0].encode('utf-8') == diga:
        checa = checadito(linha[2].encode('utf-8'),"-","-")
        if checa != 1:
          print " - "+linha[2].encode('utf-8')
          parte1 = linha[0].encode('utf-8')
          falei = 1
          grava_dito1(parte1,"-","-")
          
      elif linha[2].encode('utf-8') == diga:
        checa = checadito(linha[0].encode('utf-8'),"-","-")
        if checa != 1:
          print " - "+linha[0].encode('utf-8')
          parte1 = linha[0].encode('utf-8')
          falei = 1
          grava_dito1(parte1,"-","-")

  # Buscando nas falas do usuário
  if falei == 0:
    for linha in cursor.execute("SELECT * FROM entra1"):
      if linha[1].encode('utf-8') == " é igual a ":
        if linha[0].encode('utf-8') == diga:
          checa = checadito(linha[2].encode('utf-8'),"-","-")
          if checa != 1:
            print " - "+linha[2].encode('utf-8')
            falei = 1
            grava_dito1(linha[2].encode('utf-8'),"-","-")
            
        elif linha[2].encode('utf-8') == diga:
          checa = checadito(linha[0].encode('utf-8'),"-","-")
          if checa != 1:
            print " - "+linha[0].encode('utf-8')
            falei = 1
            grava_dito1(linha[0].encode('utf-8'),"-","-")
            





  # Respostas avançadas

  # Resposta baseada em bloco da fala do usuário que está presente nas conclusões ou falas do usuário
  if falei == 0:
    palavras = ["    "]
    palavras.remove('    ')
    x = -1
    blocos = ["    "]
    blocos.remove('    ')
    i = -1
    # Divide o dito em palavras
    if ' ' in diga:
      if 'que eu disse sobre ' in diga:
        falei = 1
      elif 'que concluiu sobre ' in diga:
        falei = 1
      elif (diga.count(' ') >= 1):
        palavras = diga.split(' ')
    #print "palavras:",palavras

    # Junta o dito em blocos
    for p in palavras:
      #print "p:",p
      i = i+1
      x = x+1
      #if p != "da" and p != "de" and p != "do" and p != "dos" and p != "das" and p != "isso" and p != "disso" and p != "já" and p != "o" and p != "que" and p != "a" and p != "daquilo" and p != "parte" and p != "os" and p != "as" and p != "com" and p != "e" and p != "não" and p != "sem" and p != "era" and p != "vez" and p != "na" and p != "no" and p != "nas" and p != "nos" and p != "por" and p != "é" and p != "só":
        #blocos.insert(x+1, p)
      if i < (len(palavras) - 1):
        blocos.insert(x+1, (palavras[i]+" "+palavras[i+1]))
        #print blocos
        if i < (len(palavras) - 2):
          if (diga.count(' ') >= 2):
            blocos.insert(x+1, (palavras[i]+" "+palavras[i+1]+" "+palavras[i+2]))
            if i < (len(palavras) - 3):
              if (diga.count(' ') >= 3):
                blocos.insert(x+1, (palavras[i]+" "+palavras[i+1]+" "+palavras[i+2]+" "+palavras[i+3]))
                if i < (len(palavras) - 4):
                  if (diga.count(' ') >= 4):
                    blocos.insert(x+1, (palavras[i]+" "+palavras[i+1]+" "+palavras[i+2]+" "+palavras[i+3]+" "+palavras[i+4]))

    #print blocos

    # Ordenando para pegar primeiro os blocos maiores
    blocos.sort(key=len, reverse=True)

    # apaga blocos irrelevantes
    #y = 0
    for b in blocos:
      #print b
      if b == "e o" or b == "e a" or b == "e os" or b == "e as" or b == "que é" or b == " que" or b == "que " or b == " que ":
        blocos.remove(b)
        #del blocos[y]
        #print "bloco",b,"apagado"
      if b == "que são" or b == "o que" or b == "sim e":
        #del blocos[y]
        blocos.remove(b)
        #print "bloco",b,"apagado"
      #y = y + 1

    #blocos = filter("o que", blocos)
    #print blocos
    
    # Ordenando para pegar primeiro os blocos maiores
    blocos.sort(key=len, reverse=True)

    # Percorrendo os blocos e buscando eles nas indutivas
    conclusoes = ["    "]
    conclusoes.remove('    ')
    for b in blocos:
      #print "pesquisando por:",b
      for linha in cursor.execute("SELECT * FROM indutivo"):
        if b == linha[0].encode('utf-8'):
          conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))

      # percorrendo as falas relacionadas e imprime a que não foi dita
      conclusoes.sort(key=len, reverse=True)
      for c in conclusoes:
        #print c
        #parte1, conectivo, parte2 = c.split(', ')
        if falei == 0:
          if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
              print " - "+c[0]+conector+c[2]
              grava_dito1(c[0], c[1], c[2])
              falei = 1


    # Percorrendo os blocos e buscando eles nas conclusões
    conclusoes = ["    "]
    conclusoes.remove('    ')
    for b in blocos:
      #print "pesquisando por:",b
      for linha in cursor.execute("SELECT * FROM concl1"):
        if (b == linha[0].encode('utf-8') or b == linha[2].encode('utf-8') or " "+b == linha[0].encode('utf-8')+" " or " "+b == linha[2].encode('utf-8')+" ") and falei == 0:
          conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))

      # percorrendo as falas relacionadas e imprime a que não foi dita
      conclusoes.sort(key=len, reverse=True)
      for c in conclusoes:
        #print c
        #parte1, conectivo, parte2 = c.split(', ')
        if falei == 0:
          if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
              print " - "+c[0]+conector+c[2]
              grava_dito1(c[0], c[1], c[2])
              falei = 1


    #print "fim2"

    # Percorrendo os blocos e buscando eles nas falas do usuário
    conclusoes = ["    "]
    conclusoes.remove('    ')
    if falei == 0:
      for b in blocos:
        #print "pesquisando por:",b
        for linha in cursor.execute("SELECT * FROM entra1"):
          if (b == linha[0].encode('utf-8') or b == linha[2].encode('utf-8') or " "+b == linha[0].encode('utf-8')+" " or " "+b == linha[2].encode('utf-8')+" ") and falei == 0:
            conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))

        # percorrendo as falas relacionadas e imprime a que não foi dita
        conclusoes.sort(key=len, reverse=True)
        for c in conclusoes:
          #print c
          #parte1, conectivo, parte2 = c.split(', ')
          if falei == 0:
            if checadito(c[0], c[1], c[2]) != 1:
                conector = c[1]
                if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                  c[1] = conector+"o(a) "
                  print " - "+c[0]+c[1]+c[2]
                  grava_dito1(c[0], c[1], c[2])
                  falei = 1


  #print "fim1"


  # resposta com indução: palavra solta que tinha em induções

  conclusoes = ["    "]
  conclusoes.remove('    ')
  # variável para guardar todas as palavras que foram ditas:
  palavras = ["    "]
  palavras.remove('    ')
  x = -1
  y = -1
  item = "   "
  relacionado2 = "   "
  # Divide o dito em palavras
  if ' ' in diga and falei == 0:
    if 'que eu disse sobre ' in diga:
      falei = 1
    elif 'que concluiu sobre ' in diga:
      falei = 1
    elif (diga.count(' ') >= 1):
      palavras = diga.split(' ')
      palavras.sort(key=len, reverse=True)
      #print palavras
      for palavra in palavras:
        if palavra != "da" and palavra != "de" and palavra != "do" and palavra != "dos" and palavra != "das" and palavra != "isso" and palavra != "disso" and palavra != "já" and palavra != "o" and palavra != "que" and palavra != "a" and palavra != "as" and palavra != "os" and palavra != "e" and palavra != "não" and palavra != "sem" and palavra != "era" and palavra != "vez" and palavra != "na" and palavra != "no" and palavra != "nas" and palavra != "nos" and palavra != "por" and palavra != "é" and palavra != "só":
          # buscando cada palavra dita nas induções
          for linha in cursor.execute("SELECT * FROM indutivo"):
            if palavra == linha[0].encode('utf-8'):
                conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))
            if palavra == linha[2].encode('utf-8'):
                conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))

  # checa cada frase que tem a palavra para ver se já foi dita antes, se não foi diz
  for c in conclusoes:
    if falei == 0:
      if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            #print " cheguei até aqui"
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
            # Agora vamos efetivamente dizer ao usuário:
            print " - acho que "+c[0]+conector+c[2]
            grava_dito1(c[0], c[1], c[2])
            falei = 1



  # resposta com conclusões: palavra solta que tinha em conclusões

  conclusoes = ["    "]
  conclusoes.remove('    ')
  # variável para guardar todas as palavras que foram ditas:
  palavras = ["    "]
  palavras.remove('    ')
  x = -1
  y = -1
  item = "   "
  relacionado2 = "   "
  # Divide o dito em palavras
  if ' ' in diga and falei == 0:
    if 'que eu disse sobre ' in diga:
      falei = 1
    elif 'que concluiu sobre ' in diga:
      falei = 1
    elif (diga.count(' ') >= 1):
      palavras = diga.split(' ')
      palavras.sort(key=len, reverse=True)
      #print palavras
      for palavra in palavras:
        if palavra != "da" and palavra != "de" and palavra != "do" and palavra != "dos" and palavra != "das" and palavra != "isso" and palavra != "disso" and palavra != "já" and palavra != "o" and palavra != "que" and palavra != "a" and palavra != "as" and palavra != "os" and palavra != "e" and palavra != "não" and palavra != "sem" and palavra != "era" and palavra != "vez" and palavra != "na" and palavra != "no" and palavra != "nas" and palavra != "nos" and palavra != "por" and palavra != "é" and palavra != "só":
          # buscando cada palavra dita nas conclusões
          for linha in cursor.execute("SELECT * FROM concl1"):
            if palavra == linha[0].encode('utf-8'):
                conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))
            if palavra == linha[2].encode('utf-8'):
                conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))

  # checa cada frase que tem a palavra para ver se já foi dita antes, se não foi diz
  for c in conclusoes:
    if falei == 0:
      if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
            print " - "+c[0]+conector+c[2]
            grava_dito1(c[0], c[1], c[2])
            falei = 1



  # resposta com fala do usuário: palavra solta que tinha em fala do usuário

  conclusoes = ["    "]
  conclusoes.remove('    ')

  # variável para guardar todas as palavras que foram ditas:
  palavras = ["    "]
  palavras.remove('    ')
  x = -1
  y = -1
  item = "   "
  relacionado2 = "   "

  # Divide o dito em palavras
  if ' ' in diga and falei == 0:
    if 'que eu disse sobre ' in diga:
      falei = 1
    elif 'que concluiu sobre ' in diga:
      falei = 1
    elif (diga.count(' ') >= 1):
      palavras = diga.split(' ')
      palavras.sort(key=len, reverse=True)
      for palavra in palavras:
        if palavra != "da" and palavra != "de" and palavra != "do" and palavra != "dos" and palavra != "das" and palavra != "isso" and palavra != "disso" and palavra != "já" and palavra != "o" and palavra != "que" and palavra != "a" and palavra != "as" and palavra != "os" and palavra != "e" and palavra != "não" and palavra != "sem" and palavra != "era" and palavra != "vez" and palavra != "na" and palavra != "no" and palavra != "nas" and palavra != "nos" and palavra != "por" and palavra != "é" and palavra != "só":
          # buscando cada palavra dita nas falas do usuário
          for linha in cursor.execute("SELECT * FROM entra1"):
            if palavra == linha[0].encode('utf-8'):
                conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))
            if palavra == linha[2].encode('utf-8'):
                conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))

  # checa cada frase que tem a palavra para ver se já foi dita antes, se não foi diz
  for c in conclusoes:
    if falei == 0:
      if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
            print " - "+c[0]+conector+c[2]
            grava_dito1(c[0], c[1], c[2])
            falei = 1




    # resposta com conclusão que tem parte em diga (funcionando)
    #print " chegou aqui"
    #print linha
    # variável para guardar todas conclusões que tem relação com o que foi dito:
    conclusoes = ["    "]
    conclusoes.remove('    ')
    x = -1
    for linha in cursor.execute("SELECT * FROM concl1"):
      if (linha[0].encode('utf-8') in diga or linha[2].encode('utf-8') in diga) and falei == 0:
        conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))
    conclusoes.sort(key=len, reverse=True)
    for c in conclusoes:
      #print c
      #parte1, conectivo, parte2 = c.split(', ')
      if falei == 0:
        if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
            print " - "+c[0]+conector+c[2]
            grava_dito1(c[0], c[1], c[2])
            falei = 1





  # resposta com fala do usuário que tem parte em diga
  # variável para guardar todas falas do usuário que tem relação com o que foi dito:
  conclusoes = ["    "]
  conclusoes.remove('    ')
  x = -1
  for linha in cursor.execute("SELECT * FROM entra1"):
    if (linha[0].encode('utf-8') in diga or linha[2].encode('utf-8') in diga) and falei == 0:
      conclusoes.insert(x+1, (linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')))
  conclusoes.sort(key=len, reverse=True)
  for c in conclusoes:
    #print c
    #parte1, conectivo, parte2 = c.split(', ')
    if falei == 0:
      if checadito(c[0], c[1], c[2]) != 1:
            conector = c[1]
            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
              conector = conector+"o(a) "
            print " - "+c[0]+conector+c[2]
            grava_dito1(c[0], c[1], c[2])
            falei = 1




  #print "fim"




  # identificando expressões relacionáveis no que foi digitado pelo usuário
  # variável onde ficam as expressões relacionáveis identificadas
  blocos = ["    "]
  blocos.remove('    ')
  # variável para guardar todas as palavras que foram ditas:
  palavras = ["    "]
  palavras.remove('    ')
  x = -1
  y = -1
  item = "   "
  relacionado2 = "   "

  # Divide o dito em palavras
  if ' ' in diga and falei == 0:
    if 'que eu disse sobre ' in diga:
      falei = 1
    elif 'que concluiu sobre ' in diga:
      falei = 1
    elif (diga.count(' ') >= 1):
      palavras = diga.split(' ')
      for palavra in palavras:
        # buscando cada palavra dita nas conclusões
        for linha in cursor.execute("SELECT * FROM concl1"):
            if linha[0].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
            if linha[2].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
        # buscando cada palavra dita nas falas do usuário
        for linha in cursor.execute("SELECT * FROM entra1"):
            if linha[0].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
            if linha[2].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)

    
      # resposta2: expressão relacionada + expressão relacionada !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      
      # buscando nas conclusões
      for bloco in blocos:
          #print "bloco analizado: "+bloco
          for linha in cursor.execute("SELECT * FROM concl1"):
            relacionado1 = "   "
            if bloco == linha[0].encode('utf-8') and falei == 0:
              relacionado1 = linha[2].encode('utf-8')
              #print "expressão relacionada1: "+linha[2].encode('utf-8')
              for bloco2 in blocos:
                if bloco != bloco2:
                    #print "bloco2 analizado: "+bloco2
                    for linha in cursor.execute("SELECT * FROM concl1"):
                      if bloco2 == linha[0].encode('utf-8') and falei == 0:
                                relacionado2 = linha[2].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[2].encode('utf-8')
                                for linha in cursor.execute("SELECT * FROM concl1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            # Este código foi desenvolvido por Carlos Adrian Rupp
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                      elif bloco2 == linha[2].encode('utf-8') and falei == 0:
                                relacionado2 = linha[0].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[0].encode('utf-8')
                                #for relac in relacionado1:
                                #print relac
                                for linha in cursor.execute("SELECT * FROM concl1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
              
              
            elif bloco == linha[2].encode('utf-8') and falei == 0:
              relacionado1 = linha[0].encode('utf-8')
              #print "expressão relacionada1: "+linha[0].encode('utf-8')
              for bloco2 in blocos:
                if bloco != bloco2:
                    #print "bloco2 analizado: "+bloco2
                    for linha in cursor.execute("SELECT * FROM concl1"):
                      if bloco2 == linha[0].encode('utf-8') and falei == 0:
                                relacionado2 = linha[2].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[2].encode('utf-8')
                                for linha in cursor.execute("SELECT * FROM concl1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                      elif bloco2 == linha[2].encode('utf-8') and falei == 0:
                                relacionado2 = linha[0].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[0].encode('utf-8')
                                #for relac in relacionado1:
                                #print relac
                                for linha in cursor.execute("SELECT * FROM concl1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1


  
      # buscando nas falas do usuário (expressão relacionada + expressão relacionada)
      for bloco in blocos:
          #print "bloco analizado: "+bloco
          for linha in cursor.execute("SELECT * FROM entra1"):
            relacionado1 = "   "
            if bloco == linha[0].encode('utf-8') and falei == 0:
              relacionado1 = linha[2].encode('utf-8')
              #print "expressão relacionada1: "+linha[2].encode('utf-8')
              for bloco2 in blocos:
                if bloco != bloco2:
                    #print "bloco2 analizado: "+bloco2
                    for linha in cursor.execute("SELECT * FROM entra1"):
                      if bloco2 == linha[0].encode('utf-8') and falei == 0:
                                relacionado2 = linha[2].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[2].encode('utf-8')
                                for linha in cursor.execute("SELECT * FROM entra1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            # Este código foi desenvolvido por Carlos Adrian Rupp
                                            conector = linha[1].encode('utf-8')
                                        if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                            conector = conector+"o(a) "
                                        #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                        print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                        grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                        falei = 1
                      elif bloco2 == linha[2].encode('utf-8') and falei == 0:
                                relacionado2 = linha[0].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[0].encode('utf-8')
                                #for relac in relacionado1:
                                #print relac
                                for linha in cursor.execute("SELECT * FROM entra1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                                conector = conector+"o(a) "
                                            #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                            falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                                conector = conector+"o(a) "
                                            #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                            falei = 1
              
              
            elif bloco == linha[2].encode('utf-8') and falei == 0:
              relacionado1 = linha[0].encode('utf-8')
              #print "expressão relacionada1: "+linha[0].encode('utf-8')
              for bloco2 in blocos:
                if bloco != bloco2:
                    #print "bloco2 analizado: "+bloco2
                    for linha in cursor.execute("SELECT * FROM entra1"):
                      if bloco2 == linha[0].encode('utf-8') and falei == 0:
                                relacionado2 = linha[2].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[2].encode('utf-8')
                                for linha in cursor.execute("SELECT * FROM entra1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                                conector = conector+"o(a) "
                                            #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                            falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                                conector = conector+"o(a) "
                                            #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                            falei = 1
                      elif bloco2 == linha[2].encode('utf-8') and falei == 0:
                                relacionado2 = linha[0].encode('utf-8')
                                #print "expressão relacionada do bloco2: "+linha[0].encode('utf-8')
                                #for relac in relacionado1:
                                #print relac
                                for linha in cursor.execute("SELECT * FROM entra1"):
                                    if relacionado1 in linha[0].encode('utf-8') and relacionado2 in linha[2].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                                conector = conector+"o(a) "
                                            #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                            falei = 1
                                    elif relacionado1 in linha[2].encode('utf-8') and relacionado2 in linha[0].encode('utf-8'):
                                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                                            conector = linha[1].encode('utf-8')
                                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                                conector = conector+"o(a) "
                                            #print " - Encontrei uma conclusão baseada em 2as expressões relacionadas"
                                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                                            falei = 1












      #print "fim da tentativa de encontrar expressão relacionada + expressão relacionada"





      # resposta com dois termos relevantes encontrados!

      # busca cada palavra nas conclusões
      for bloco in blocos:
      	#print "bloco analizado: "+bloco
      	for linha in cursor.execute("SELECT * FROM concl1"):
            if bloco in linha[0].encode('utf-8') and falei == 0:
                # busca segundo termo relevante na mesma frase da conclusão
                for bloco2 in blocos:
                    #print "bloco2 analizado: "+bloco2
                    if bloco2 in linha[2].encode('utf-8') and falei == 0:
                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                            conector = linha[1].encode('utf-8')
                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                conector = conector+"o(a) "
                            #print " - Encontrei uma conclusão baseada em 2as expressão"
                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                            falei = 1
                            
      # busca cada palavra nas frases anteriores do usuário
      for bloco in blocos:
      	#print "bloco analizado: "+bloco
      	for linha in cursor.execute("SELECT * FROM entra1"):
            if bloco in linha[0].encode('utf-8') and falei == 0:
                # busca segundo termo relevante na mesma frase da conclusão
                for bloco2 in blocos:
                    #print "bloco2 analizado: "+bloco2
                    if bloco2 in linha[2].encode('utf-8') and falei == 0:
                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                            conector = linha[1].encode('utf-8')
                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                conector = conector+"o(a) "
                            #print " - Encontrei uma conclusão baseada em 2as expressão"
                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                            falei = 1 

      # resposta com um termo relevante encontrado!

      # busca cada palavra nas conclusões
      for bloco in blocos:
      	#print "bloco analizado: "+bloco
      	for linha in cursor.execute("SELECT * FROM concl1"):
            if bloco == linha[0].encode('utf-8') and falei == 0:
                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                            conector = linha[1].encode('utf-8')
                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                conector = conector+"o(a) "
                            #print " - Encontrei uma conclusão baseada em expressão"
                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                            falei = 1
            if bloco == linha[2].encode('utf-8') and falei == 0:
                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                            conector = linha[1].encode('utf-8')
                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                onector = conector+"o(a) "
                            #print " - Encontrei uma conclusão baseada em expressão"
                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                            falei = 1
                            
      # busca cada palavra nas frases anteriores do usuário
      for bloco in blocos:
      	#print "bloco analizado: "+bloco
      	for linha in cursor.execute("SELECT * FROM entra1"):
            if bloco == linha[0].encode('utf-8') and falei == 0:
                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                            conector = linha[1].encode('utf-8')
                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                conector = conector+"o(a) "
                            #print " - Encontrei uma frase anterior baseada em expressão"
                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                            falei = 1 
            if bloco == linha[2].encode('utf-8') and falei == 0:
                        if checadito(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8')) != 1:
                            conector = linha[1].encode('utf-8')
                            if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
                                conector = conector+"o(a) "
                            #print " - Encontrei uma frase anterior baseada em expressão"
                            print " - "+linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
                            grava_dito1(linha[0].encode('utf-8'),linha[1].encode('utf-8'),linha[2].encode('utf-8'))
                            falei = 1 
  
  



  
    # Resposta com perguntas: Responder com Perguntas 1111111111111111111111111111111111111111111111111111111111111111
  
  # variável onde ficam as expressões relevantes identificadas
  blocos = ["    "]
  blocos.remove('    ')
  # variável para guardar todas as palavras que foram ditas:
  palavras = ["    "]
  palavras.remove('    ')
  x = -1
  y = -1
  item = "   "
  relacionado2 = "   "

  # Divide o dito em palavras
  if ' ' in diga and falei == 0:
    if 'que eu disse sobre ' in diga:
      falei = 1
    elif 'que concluiu sobre ' in diga:
      falei = 1
    elif (diga.count(' ') >= 1):
      palavras = diga.split(' ')
      for palavra in palavras:
        # buscando cada palavra dita nas conclusões
        for linha in cursor.execute("SELECT * FROM concl1"):
            if linha[0].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
            if linha[2].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
        # buscando cada palavra dita nas falas do usuário
        for linha in cursor.execute("SELECT * FROM entra1"):
            if linha[0].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
            if linha[2].encode('utf-8') == palavra:
                blocos.insert(x+1, palavra)
  
      # percorre todas as palavras relevantes
      for bloco in blocos:
      	#print "bloco analizado: "+bloco
      	
      	# checar se o sistema tem a definição dessa palavra (é igual a)       (é igual a) FUNCIONANDO!
      	definicao = 0
      	for linha in cursor.execute("SELECT * FROM entra1"):
            if bloco == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
                definicao = 1
            elif bloco == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
                # Desenvolvido por Carlos Adrian R.u.p.p
                definicao = 1
      	for linha in cursor.execute("SELECT * FROM concl1"):
            if bloco == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
                definicao = 1
            elif bloco == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
                definicao = 1
        if definicao == 0 and falei == 0:
            checa = checadito("o que é","-",bloco)
            if checa != 1:
                print " - o que é "+bloco+"? (Responda no formato: "+bloco+" é igual a xxxxx)"
                grava_dito1("o que é","-",bloco)
                falei = 1
            
      	# checar se o sistema tem essa palavra em alguma categoria (bloco é um(a) xxxx)      
      	definicao = 0
      	for linha in cursor.execute("SELECT * FROM entra1"):
            if bloco == linha[0].encode('utf-8') and " é um " == linha[1].encode('utf-8'):
                definicao = 1
            elif bloco == linha[0].encode('utf-8') and " é uma " == linha[1].encode('utf-8'):
                # Este código foi desenvolvido por Carlos A Rupp
                definicao = 1
      	for linha in cursor.execute("SELECT * FROM concl1"):
            if bloco == linha[0].encode('utf-8') and " é um " == linha[1].encode('utf-8'):
                definicao = 1
            elif bloco == linha[0].encode('utf-8') and " é uma " == linha[1].encode('utf-8'):
                # Este código foi desenvolvido por Carlos A Rupp
                definicao = 1
        if definicao == 0 and falei == 0:
            checa = checadito("Em que categoria está","-",bloco)
            if checa != 1:
                print " - Em que categoria está "+bloco+"? (Responda no formato: "+bloco+" é um xxxxx)"
                grava_dito1("Em que categoria está","-",bloco)
                falei = 1
  
      	# checar se o sistema tem algum conteúdo associado a essa palavra (bloco é tem xxxx)      
      	definicao = 0
      	for linha in cursor.execute("SELECT * FROM entra1"):
            if bloco == linha[0].encode('utf-8') and " tem " == linha[1].encode('utf-8'):
                definicao = 1
      	for linha in cursor.execute("SELECT * FROM concl1"):
            if bloco == linha[0].encode('utf-8') and " tem " == linha[1].encode('utf-8'):
                definicao = 1
        if definicao == 0 and falei == 0:
            checa = checadito("O que tem em ","-",bloco)
            if checa != 1:
                print " - O que tem em "+bloco+"? (Responda no formato: "+bloco+" tem xxxxx)"
                grava_dito1("O que tem em ","-",bloco)
                falei = 1
  
  
    # Resposta final: Responder com frase definida 1111111111111111111111111111111111111111111111111111111111111111
  
  if falei == 0:
    checa = checadito("Tenho que aprender mais sobre isso","-","-")
    if checa != 1:
        print " - Tenho que aprender mais sobre isso"
        grava_dito1("Tenho que aprender mais sobre isso","-","-")
        falei = 1
                
  if falei == 0:
      checa = checadito("Não conheço bem esse assunto","-","-")
      if checa != 1:
          print " - Não conheço bem esse assunto"
          grava_dito1("Não conheço bem esse assunto","-","-")
          falei = 1

  if falei == 0:
    checa = checadito("Não entendo disso","-","-")
    if checa != 1:
        print " - Não entendo disso"
        grava_dito1("Não entendo disso","-","-")
        falei = 1

  if falei == 0:
    checa = checadito("Preciso aprender mais sobre isso","-","-")
    if checa != 1:
        print " - Preciso aprender mais sobre isso"
        grava_dito1("Preciso aprender mais sobre isso","-","-")
        falei = 1
  
  if falei == 0:
    #5
    checa = checadito("Me falta conhecimento sobre isso","-","-")
    if checa != 1:
        print " - Me falta conhecimento sobre isso"
        grava_dito1("Me falta conhecimento sobre isso","-","-")
        falei = 1
  
  if falei == 0:
    checa = checadito("Não domino esse assunto","-","-")
    if checa != 1:
        print " - Não domino esse assunto"
        grava_dito1("Não domino esse assunto","-","-")
        falei = 1
  
  if falei == 0:
    checa = checadito("Não sei sobre isso","-","-")
    if checa != 1:
        print " - Não sei sobre isso"
        grava_dito1("Não sei sobre isso","-","-")
        falei = 1
  
  if falei == 0:
    checa = checadito("Isso está além do meu conhecimento","-","-")
    if checa != 1:
        print " - Isso está além do meu conhecimento"
        grava_dito1("Isso está além do meu conhecimento","-","-")
        falei = 1
        

        
  shutil.copyfile("memoria2.db","memoria.db")

# Este código desenvolvido por Carlos Adrian Rupp
