# -*- coding: UTF-8 -*-
# Versão Linux
# Copyright 2012, 2016 Carlos Adrian Rupp
#from __future__ import unicode_literals
import sqlite3
from modulos.buscaerro import *
from random import *
import shutil

#conn=sqlite3.connect('memoria2.db',timeout=30000)
conn=sqlite3.connect('/sdcard/memoria2.db')
cursor=conn.cursor()

# Ordem dos raciocínios programados:


# raciocínio: x é um y, y tem z, então x tem z ou com x é uma y
# raciocínio: x tem y, y é um z, então x tem z ou com y é uma z
# raciocínio: x é igual a y, y é um z, então x é um z ou com y é uma z
# raciocínio: x não é igual a y, y é igual z, então x não é igual a z


# função que fecha a conexão com o DB
def fecha():
  cursor.close()
  conn.close()   

# função que abre a conexão com o DB
def abre():
  #conn=sqlite3.connect('memoria2.db',timeout=30000)
  conn=sqlite3.connect('/sdcard/memoria2.db')
  cursor=conn.cursor()

# função que grava a conclusão nova
def grava_concl1(bloco, conector, item2):
  achou = 0
  # testar para ver se entra em contradição com o discurso do usuário
  #fecha()
  #contra = buscaerro(bloco,conector,item2)
  #abre()
  #if contra != 1:
  #print " cheguei a uma conclusão e não encontrei contradições, conector: "+conector
  # checa se não tá concluindo algo tipo "maçã é igual a maçã"
  if bloco != item2:
    
    # checa se está tentando gravar com uma categoria neutra (é um(a)) algo q tem gênero conhecido.
    # para afirmação
    if conector == " é um(a) ":
      for linha in cursor.execute("SELECT * FROM entra1"):
          if (linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " não é um ") and linha[2].encode('utf-8') == item2:
            conector = " é um "
          if (linha[1].encode('utf-8') == " é uma " or linha[1].encode('utf-8') == " não é uma ") and linha[2].encode('utf-8') == item2:
            conector = " é uma "
    # para negação
    if conector == " não é um(a) ":
      for linha in cursor.execute("SELECT * FROM entra1"):
          if (linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " não é um ") and linha[2].encode('utf-8') == item2:
            conector = " não é um "
          if (linha[1].encode('utf-8') == " é uma " or linha[1].encode('utf-8') == " não é uma ") and linha[2].encode('utf-8') == item2:
            conector = " não é uma "

    # checa se já não tinha essa conclusão, se não tinha grava
    for linha in cursor.execute("SELECT * FROM concl1"):
      if bloco == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[2].encode('utf-8'):
        achou = 1
      elif bloco == linha[2].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
          achou = 1
    # checa se essa frase não tinha sido dita pelo usuário, se não tinha grava
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[2].encode('utf-8'):
        achou = 1
      elif bloco == linha[2].encode('utf-8') and conector == linha[1].encode('utf-8') and item2 == linha[0].encode('utf-8'):
          achou = 1

    if achou == 0:
      #print "conclusão: "+bloco+conector+item2
      cursor.execute("INSERT INTO concl1(parte1, conec, parte2) VALUES('%s', '%s', '%s')" %(bloco, conector, item2))
      conn.commit()

# Função principal que chega nas conclusões partindo das falas do usuário ou de outras conclusões anteriores
def raciocinio(bloco):
  #shutil.copyfile("memoria.db","memoria2.db")
  shutil.copyfile("/sdcard/memoria.db","/sdcard/memoria2.db")
  entendi = 0
  achou = 0
  achou2 = 0
  achou3 = 0
  diga1 = "   "
  diga2 = "   "

  # +++++++++++++++
  # + RACIOCÍNIOS +
  # +++++++++++++++
  
  if achou == 0:

    # Raciocínios ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    #print "Raciocínios de nível 222222222222222222222222222222"

    # raciocinios para falas do usuário, quando bloco é a parte1
    


    # raciocínio: x é um y, y é um z, então x é um z ou com x é uma y
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')):
	  link = linha[2].encode('utf-8')

          # 2º premissa ' é um '
          conector = " é um "
          # Buscando nas falas do usuário
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM entra1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            grava_concl1(bloco, conector, item2)
          # Buscando nas conclusões
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM concl1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            grava_concl1(bloco, conector, item2)
            #print bloco+conector+link

          # 2º premissa ' é uma '
          conector = " é uma "
          # Buscando nas falas do usuário
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM entra1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            grava_concl1(bloco, conector, item2)
          # Buscando nas conclusões
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM concl1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            grava_concl1(bloco, conector, item2)
            #print bloco+conector+link

          # 2º premissa ' é um(a) '
          conector = " é um(a) "
          # Buscando nas conclusões
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM concl1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            grava_concl1(bloco, conector, item2)
            #print bloco+conector+link



    # raciocínio: x é um y, y tem z, então x tem z ou com x é uma y
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8') or " é um(a) " == linha[1].encode('utf-8') ):
	  link = linha[2].encode('utf-8')
          # 2º premissa ' tem '
          conector = " tem "
          # Buscando nas falas do usuário
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM entra1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            #conector = " tem "
            grava_concl1(bloco, conector, item2)
          # Buscando nas conclusões
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM concl1"):
            if link == linha[0].encode('utf-8') and conector == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            #conector = " tem "
            grava_concl1(bloco, conector, item2)
            # print bloco+conector+link



    # raciocínio: x tem y, y é um z, então x tem z ou com y é uma z
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    conector = "   "
    link = "   "
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and " tem " == linha[1].encode('utf-8'):
	  link = linha[2].encode('utf-8')
          # 2º premissa ' tem '
          # Buscando nas falas do usuário
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM entra1"):
            if link == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')) and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            conector = " tem "
            grava_concl1(bloco, conector, item2)
          # Buscando nas conclusões
          item2 = "   "
          for linha in cursor.execute("SELECT * FROM concl1"):
            if link == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8') or " é um(a) " == linha[1].encode('utf-8')) and bloco != linha[2].encode('utf-8'):
              item2 = linha[2].encode('utf-8')
          if item2 != "   ":
            conector = " tem "
            grava_concl1(bloco, conector, item2)
            # print bloco+conector+link


    # raciocínio: x é igual a y, y é um z, então x é um z ou com y é uma z 
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
	  link = linha[2].encode('utf-8')
      elif bloco == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
	  link = linha[0].encode('utf-8')
      # 2º premissa ' é um '
      # Buscando nas falas do usuário
      if link != "   ":
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[0].encode('utf-8') and " é um " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
        if item2 != "   ":
          conector = " é um "
          grava_concl1(bloco, conector, item2)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[0].encode('utf-8') and " é um " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
        if item2 != "   ":
          conector = " é um "
          grava_concl1(bloco, conector, item2)
          # print bloco+conector+link
        # 2º premissa ' é uma '
        # Buscando nas falas do usuário
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[0].encode('utf-8') and " é uma " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
        if item2 != "   ":
          conector = " é uma "
          grava_concl1(bloco, conector, item2)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[0].encode('utf-8') and " é uma " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
        if item2 != "   ":
          conector = " é uma "
          grava_concl1(bloco, conector, item2)
          # print bloco+conector+link
        # 2º premissa ' é um(a) '
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[0].encode('utf-8') and " é um(a) " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
        if item2 != "   ":
          conector = " é um(a) "
          grava_concl1(bloco, conector, item2)
          # print bloco+conector+link



    # raciocínio: x não é igual a y, y é igual z, então x não é igual a z
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and " não é igual a " == linha[1].encode('utf-8'):
	  link = linha[2].encode('utf-8')
      elif bloco == linha[2].encode('utf-8') and " não é igual a " == linha[1].encode('utf-8'):
	  link = linha[0].encode('utf-8')
      # 2º premissa ' é igual '
      # Buscando nas falas do usuário
      if link != "   ":
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
          elif link == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é igual a "
          grava_concl1(bloco, conector, item2)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
          elif link == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é igual a "
          grava_concl1(bloco, conector, item2)


    # raciocínio: x foi depois de y, y foi depois de z, então z foi antes d x ---- ou com y foi antes de x
    #print "raciocinio x foi depois de y, y foi depois de z, então z foi antes d x ---- ou com y foi antes de x"
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    for linha in cursor.execute("SELECT * FROM entra1"):
      # x foi depois de y
      #print "bloco = "+bloco
      if bloco == linha[0].encode('utf-8') and " foi depois d" == linha[1].encode('utf-8'):
        link = linha[2].encode('utf-8')
        #print "achei o bloco"
      #elif bloco == linha[2].encode('utf-8') and " foi antes d" == linha[1].encode('utf-8'):
	  #link = linha[0].encode('utf-8')
    # 2º premissa ' foi depois d' ou ' foi antes d'
    if link != "   ":
      # Buscando nas falas do usuário
      item2 = "   "
      for linha in cursor.execute("SELECT * FROM entra1"):
        if link == linha[0].encode('utf-8') and " foi depois d" == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
          item2 = linha[2].encode('utf-8')
          #print "achei o item2"
        #elif link == linha[2].encode('utf-8') and " foi antes d" == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
          #item2 = linha[0].encode('utf-8')
      if item2 != "   ":
        conector = " foi antes d"
        grava_concl1(item2, conector, bloco)
      # Buscando nas conclusões
      item2 = "   "
      for linha in cursor.execute("SELECT * FROM concl1"):
        if link == linha[0].encode('utf-8') and " foi depois d" == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
          item2 = linha[2].encode('utf-8')
        #elif link == linha[2].encode('utf-8') and " foi antes d" == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
          #item2 = linha[0].encode('utf-8')
      if item2 != "   ":
        conector = " foi antes d"
        grava_concl1(item2, conector, bloco)


    # raciocínio: x é igual a y, y é igual z, então x é igual a z
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
	  link = linha[2].encode('utf-8')
      elif bloco == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
	  link = linha[0].encode('utf-8')
      # 2º premissa ' é igual '
      # Buscando nas falas do usuário
      if link != "   ":
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
          elif link == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é igual a "
          grava_concl1(bloco, conector, item2)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[2].encode('utf-8'):
            item2 = linha[2].encode('utf-8')
          elif link == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é igual a "
          grava_concl1(bloco, conector, item2)




    # raciocínio: x é igual a y, z é um y, então z é um x ou com z é uma y (sinonimo de categoria)
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário) (acha o sinônimo)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
	  link = linha[2].encode('utf-8')
      elif bloco == linha[2].encode('utf-8') and " é igual a " == linha[1].encode('utf-8'):
	  link = linha[0].encode('utf-8')
      # 2º premissa ' é um '
      # Buscando nas falas do usuário
      if link != "   ":
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[2].encode('utf-8') and " é um " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é um(a) "
          grava_concl1(item2, conector, bloco)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[2].encode('utf-8') and " é um " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é um(a) "
          grava_concl1(item2, conector, bloco)
          # print bloco+conector+link
        # 2º premissa ' é uma '
        # Buscando nas falas do usuário
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[2].encode('utf-8') and " é uma " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é um(a) "
          grava_concl1(item2, conector, bloco)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[2].encode('utf-8') and " é uma " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é um(a) "
          grava_concl1(item2, conector, bloco)
          # print bloco+conector+link
        # 2º premissa ' é um(a) '
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[2].encode('utf-8') and " é um(a) " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " é um(a) "
          grava_concl1(item2, conector, bloco)
          # print bloco+conector+link


    # raciocínio: y é o oposto de z, x é um y, então x não é um(a) z (se Adrian é um inteligente, Adrian não é um burro)
    conector = "   "
    link = "   "
    # Procurar o bloco na PARTE1, se achar, guarda o link e o conectivo (para falas do usuário) (acha o sinônimo)
    for linha in cursor.execute("SELECT * FROM entra1"):
      if bloco == linha[0].encode('utf-8') and " é o oposto de " == linha[1].encode('utf-8'):
	  link = linha[2].encode('utf-8')
      elif bloco == linha[2].encode('utf-8') and " é o oposto de " == linha[1].encode('utf-8'):
	  link = linha[0].encode('utf-8')
      # 2º premissa ' é um '
      # Buscando nas falas do usuário
      if link != "   ":
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[2].encode('utf-8') and " é um " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é um(a) "
          grava_concl1(item2, conector, bloco)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[2].encode('utf-8') and " é um " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é um(a) "
          grava_concl1(item2, conector, bloco)
          # print bloco+conector+link
        # 2º premissa ' é uma '
        # Buscando nas falas do usuário
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM entra1"):
          if link == linha[2].encode('utf-8') and " é uma " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é um(a) "
          grava_concl1(item2, conector, bloco)
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[2].encode('utf-8') and " é uma " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é um(a) "
          grava_concl1(item2, conector, bloco)
          # print bloco+conector+link
        # 2º premissa ' é um(a) '
        # Buscando nas conclusões
        item2 = "   "
        for linha in cursor.execute("SELECT * FROM concl1"):
          if link == linha[2].encode('utf-8') and " é um(a) " == linha[1].encode('utf-8') and bloco != linha[0].encode('utf-8'):
            item2 = linha[0].encode('utf-8')
        if item2 != "   ":
          conector = " não é um(a) "
          grava_concl1(item2, conector, bloco)
          # print bloco+conector+link



  #shutil.copyfile("memoria2.db","memoria.db")
  shutil.copyfile("/sdcard/memoria2.db","/sdcard/memoria.db")
  #conn.commit()

  # confirma os dados para o banco de dados e fecha o banco de dados
  
  #conn.close()      

  
