# -*- coding: UTF-8 -*-
# Versão Android 2024
# Copyright 2012, 2021, 2024 Carlos Adrian Rupp
#from __future__ import unicode_literals
import sqlite3
from random import *
from modulos.raciocinio import *
from modulos.buscaerro import *
from modulos.buscaresposta import *
from modulos.indutivo import *
import shutil

# This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
# This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.
# You should have received a copy of the GNU General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

# ESRA versão 2020

#shutil.copyfile("memoria2.db","memoria.db")

diga = "oi"
#conn=sqlite3.connect('memoria.db')
conn=sqlite3.connect('/sdcard/memoria.db')
cursor=conn.cursor()



# Variáveis
# entendi = quando 1 significa que o sistema identificou a entrada do usuário
# sei = quando for perguntado e souber sobre um assunto
# pergunta = 1 significa q foi perguntado o q pensa sobre algo
# resposta = variável onde fica as frases raiocinadas pelo sistema
# anterior = guarda a resposta q ele acabou de dar

# apaga as tabelas anteriores:
#cursor.execute("DROP TABLE IF EXISTS memo1")
#cursor.execute("DROP TABLE IF EXISTS memo2")
#cursor.execute("DROP TABLE IF EXISTS memo3")
#cursor.execute("DROP TABLE IF EXISTS memo4")
#cursor.execute("DROP TABLE IF EXISTS memo5")
#cursor.execute("DROP TABLE IF EXISTS memo6")
#cursor.execute("DROP TABLE IF EXISTS memo7")
#cursor.execute("DROP TABLE IF EXISTS memo8")
#cursor.execute("DROP TABLE IF EXISTS memo9")
#cursor.execute("DROP TABLE IF EXISTS memo10")

# apaga o que foi dito na sessão anterior:
cursor.execute("DROP TABLE IF EXISTS dito1")

#Cria tabela de frases com relações que foram ditas pelo usuário
#cursor.execute("CREATE TABLE ENTRA1 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
#Cria tabela de conclusões
#cursor.execute("CREATE TABLE CONCL1 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
#Cria tabela para tudo que foi dito na sessão
cursor.execute("CREATE TABLE dito1 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
#Cria tabela para tudo que foi dito alguma vez
#cursor.execute("CREATE TABLE dito2 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
#Cria tabela para o raciocinio indutivo
#cursor.execute("CREATE TABLE indutivo (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")

# Mensagens iniciais para o usuário:
print "   "
print "   "
print "   "
print "   "
print "   "
print "Olá, bem vindo ao ESRA (Esboço de Sistema de Raciocinio Artificial)"
print "Versão 2024 - Para Android- Versão teste"
print "Copyright 2012, 2021, 2024 Adrian Rupp"
print "   "
print "Instruções:"
print "   "
print "- Não use apóstrofos ', ponto final, de exclamação, de interrogação e não inicie frases com letra maiuscúla"
print "- Evite usar artigos (o, a, um, umas, etc.)"
print " "
print "- Como funciona: Você vai ensinando ele usando os tipo de frase que ele reconhece e ele vai apresentando suas conclusões."
print " "
print "- Alguns tipos de frase que o ESRA identifica:"
print "    x é um y - como: maçã é uma fruta, para associar um item a uma categoria"
print "    x é igual a y - como: bergamota é igual a tangerina, para sinônimos"
print "    x não é um y; x não é igual a y; para negar"
print "    O que eu disse sobre x - para ele repetir o que foi dito sobre um assunto"
print "    O que concluiu sobre x - para ele dar suas conclusões sobre um assunto"
print "    fui - para sair do programa"
print " "
print "Para mais detalhes veja o arquivo 'Manual.odt'"
print " "

# testa se o banco de dados está vazio
cursor.execute("SELECT * FROM ENTRA1")
conteudo = cursor.fetchone()
if conteudo is None:
  print "ATENÇÃO! Memória vazia!"


# função que fecha a conexão com o DB
def fecha():
  cursor.close()
  conn.close()   

# função que abre a conexão com o DB
def abre():
  #conn=sqlite3.connect('memoria.db',timeout=30000)
  conn=sqlite3.connect('/sdcard/memoria.db')
  cursor=conn.cursor()

# função que quarda o que foi dito na sessão
def grava_dito1(parte1, conectivo, parte2):
  # Busca por catega e parte1 na memória, se não achou adiciona item
  achou = 0        
  for linha in cursor.execute("SELECT * FROM dito1"):
    if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
      achou = 1
    if conectivo == " não é igual a " or conectivo == " é igual a " or conectivo == " não é o oposto de " or conectivo == " é o oposto de ":
      if parte1 == linha[2].encode('utf-8') and parte2 == linha[0].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
        #print "encontrei um conectivo onde não importa a ordem das partes"
	achou = 1
  if achou == 0:
    cursor.execute("INSERT INTO dito1(parte1, conec, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
    conn.commit()

# função que quarda tudo que foi dito
#def grava_dito2(parte1, conectivo, parte2):
#  conn=sqlite3.connect('memoria.db')
##  cursor=conn.cursor()
#  # Busca por catega e parte1 na memória, se não achou adiciona item
#  achou = 0        
#  for linha in cursor.execute("SELECT * FROM dito2"):
#    if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
#      achou = 1
#    elif conectivo == " não é igual a " or conectivo == " é igual a " or conectivo == " não é o oposto de " or conectivo == " é o oposto de ":
#      if parte1 == linha[2].encode('utf-8') and parte2 == linha[0].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
#	achou = 1
#  if achou == 0:
#    cursor.execute("INSERT INTO dito2(parte1, conec, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
#    conn.commit()

def grava_na_memoria(parte1, conectivo, parte2):
  # Busca por catega e parte1 na memória, se não achou adiciona item
  #conn=sqlite3.connect('memoria.db')
  #cursor=conn.cursor()
  achou = 0        
  for linha in cursor.execute("SELECT * FROM entra1"):
    if parte1 == linha[0].encode('utf-8') and parte2 == linha[2].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
      achou = 1
    elif conectivo == " não é igual a " or conectivo == " é igual a " or conectivo == " não é o oposto de " or conectivo == " é o oposto de ":
      if parte1 == linha[2].encode('utf-8') and parte2 == linha[0].encode('utf-8') and conectivo == linha[1].encode('utf-8'):
	achou = 1
  if achou == 0:
    cursor.execute("INSERT INTO entra1(parte1, conec, parte2) VALUES('%s', '%s', '%s')" %(parte1, conectivo, parte2))
    conn.commit()
    grava_dito1(parte1, conectivo, parte2)
    #grava_dito2(parte1, conectivo, parte2)


frases = ["    "]
frases.remove('    ')
conceitos = ["    "]
conceitos.remove('    ')
sinonimos = ["    "]
sinonimos.remove('    ')


# função para achar os sinônimos da expressão
def AchaSinonimos(expressao): 
  # apagando a lista antiga de sinônimos:
  del sinonimos[:]
  # Buscando sinônimos no que o usuário disse:
  for linha in cursor.execute("SELECT * FROM entra1"):
    if expressao == linha[0].encode('utf-8') and linha[1].encode('utf-8') == " é igual a ":
      if linha[2].encode('utf-8') not in sinonimos:
        sinonimos.append(linha[2].encode('utf-8'))
    if expressao == linha[2].encode('utf-8') and linha[1].encode('utf-8') == " é igual a ":
      if linha[0].encode('utf-8') not in sinonimos:
        sinonimos.append(linha[0].encode('utf-8'))
  # Buscando sinônimos no que o sistema concluiu:
  for linha in cursor.execute("SELECT * FROM concl1"):
    if expressao == linha[0].encode('utf-8') and linha[1].encode('utf-8') == " é igual a ":
      if linha[2].encode('utf-8') not in sinonimos:
        sinonimos.append(linha[2].encode('utf-8'))
    if expressao == linha[2].encode('utf-8') and linha[1].encode('utf-8') == " é igual a ":
      if linha[0].encode('utf-8') not in sinonimos:
        sinonimos.append(linha[0].encode('utf-8'))


def check_space(string): 
  count = 0
  for i in range(0, len(string)):
    if string[i] == " ": 
      count = count + 1
  return count 


# Função que checa se há mais frases sobre uma expressão
def ChecaMais(expressao):
  conta = 0
  for linha in cursor.execute("SELECT * FROM entra1"):
    if (expressao in linha[0].encode('utf-8')) or (expressao in linha[2].encode('utf-8')) or (expressao == linha[0].encode('utf-8')) or (expressao == linha[2].encode('utf-8')):
      conta = conta + 1
  for linha in cursor.execute("SELECT * FROM concl1"):
    if expressao in linha[0].encode('utf-8') or expressao in linha[2].encode('utf-8') or expressao == linha[0].encode('utf-8') or expressao == linha[2].encode('utf-8'):
      conta = conta + 1
  for linha in cursor.execute("SELECT * FROM indutivo"):
    if expressao in linha[0].encode('utf-8') or expressao in linha[2].encode('utf-8') or expressao == linha[0].encode('utf-8') or expressao == linha[2].encode('utf-8'):
      conta = conta + 1
  #print expressao+" "+str(conta)
  if conta > 1:
    return 1


# Função que checa frases e grava na lista
def Checafrase(frase):
  #print "Função Checafrase"
  achou = 0
  for item4 in frases:
    if frase == item4:
      #print "Frase testada:"+frase
      achou = 1
  #print conceitos
  # nao tá funcionado o teste abaixo:
  for item5 in conceitos:
    print "frase em conceitos testada:"+item5
    if frase == item5:
      achou = 1
  if achou == 0:
    frases.append(frase)



# Função que busca tudo o que sabe sobre determinada expressão
def BuscaSabe(expressao):
  #print 
  #frases = ["    "]
  #frases.remove('    ')
  VerMais = ["    "]
  VerMais.remove('    ')
  VerMais2 = ["    "]
  VerMais2.remove('    ')
  del VerMais[:]
  del VerMais2[:]
  #for item in frases:
  #  frases.remove(item)
  achou = 0
  x = -1
  iVerMais = 0
  # Buscando definição
  # - No que o usuário disse:
  for linha in cursor.execute("SELECT * FROM entra1"):
    if expressao == linha[0].encode('utf-8') and (linha[1].encode('utf-8') == " é igual a " or linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " é uma "):
      frase = expressao+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Definições:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
      if check_space(linha[2].encode('utf-8')) < 4:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))
    if expressao == linha[2].encode('utf-8') and linha[1].encode('utf-8') == " é igual a ":
      frase = expressao+linha[1].encode('utf-8')+linha[0].encode('utf-8')
      Checafrase("> Definições:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
      if check_space(linha[0].encode('utf-8')) < 4:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))

  # - No que o sistema concluiu:
  for linha in cursor.execute("SELECT * FROM concl1"):
    if expressao == linha[0].encode('utf-8') and (linha[1].encode('utf-8') == " é igual a " or linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " é uma " or linha[1].encode('utf-8') == " é um(a) "):
      frase = expressao+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Definições:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
      if check_space(linha[2].encode('utf-8')) < 4:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))
    if expressao == linha[2].encode('utf-8') and linha[1].encode('utf-8') == " é igual a ":
      frase = expressao+linha[1].encode('utf-8')+linha[0].encode('utf-8')
      Checafrase("> Definições:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
      if check_space(linha[0].encode('utf-8')) < 4:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))

  # Buscando definições usando sinônimos:
  AchaSinonimos(expressao)
  for sinonimo in sinonimos:
    # - No que o usuário disse:
    for linha in cursor.execute("SELECT * FROM entra1"):
      if sinonimo == linha[0].encode('utf-8') and expressao != linha[2].encode('utf-8') and (linha[1].encode('utf-8') == " é igual a " or linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " é uma "):
        frase = expressao+linha[1].encode('utf-8')+linha[2].encode('utf-8')
        Checafrase("> Definições:")
        Checafrase(frase)
        # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
        if check_space(linha[2].encode('utf-8')) < 4:
          if linha[2].encode('utf-8') not in VerMais:
            VerMais.append(linha[2].encode('utf-8'))
      if sinonimo == linha[2].encode('utf-8') and linha[1].encode('utf-8') == " é igual a " and expressao != linha[0].encode('utf-8'):
        frase = expressao+linha[1].encode('utf-8')+linha[0].encode('utf-8')
        Checafrase("> Definições:")
        Checafrase(frase)
        # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
        if check_space(linha[0].encode('utf-8')) < 4:
          if linha[0].encode('utf-8') not in VerMais:
            VerMais.append(linha[0].encode('utf-8'))

    # - No que o sistema concluiu:
    for linha in cursor.execute("SELECT * FROM concl1"):
      if sinonimo == linha[0].encode('utf-8') and expressao != linha[2].encode('utf-8') and (linha[1].encode('utf-8') == " é igual a " or linha[1].encode('utf-8') == " é um " or linha[1].encode('utf-8') == " é uma " or linha[1].encode('utf-8') == " é um(a) "):
        frase = expressao+linha[1].encode('utf-8')+linha[2].encode('utf-8')
        Checafrase("> Definições:")
        Checafrase(frase)
        # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
        if check_space(linha[2].encode('utf-8')) < 4:
          if linha[2].encode('utf-8') not in VerMais:
            VerMais.append(linha[2].encode('utf-8'))
      if sinonimo == linha[2].encode('utf-8') and linha[1].encode('utf-8') == " é igual a " and expressao != linha[0].encode('utf-8'):
        frase = expressao+linha[1].encode('utf-8')+linha[0].encode('utf-8')
        Checafrase("> Definições:")
        Checafrase(frase)
        # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
        if check_space(linha[0].encode('utf-8')) < 4:
          if linha[0].encode('utf-8') not in VerMais:
            VerMais.append(linha[0].encode('utf-8'))

  conceitos = frases[:]

  if not frases:
    print "- Não sei a definição de "+expressao
    print 
  else:
    print 
    for item in frases:
      #print "- "+ frases.pop()
      print "- "+item
    del frases[:]
  #  print len(frases)
  #for i in range(len(frases)-1):
  #  del frases[i]    
  #frases.clear()
    print 

    #print conceitos

  # Buscando mais sobre o tema:
  # - No que o usuário disse:
  for linha in cursor.execute("SELECT * FROM entra1"):
    if (expressao in linha[0].encode('utf-8')) and (expressao != linha[0].encode('utf-8')) and (expressao != linha[2].encode('utf-8')):
      #print "to aqui"
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 2 espaços
      if check_space(linha[2].encode('utf-8')) < 4:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))

    if ((expressao in linha[2].encode('utf-8')) and (expressao != linha[2].encode('utf-8')) and (expressao != linha[0].encode('utf-8'))):
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 2 espaços
      #print check_space(linha[0].encode('utf-8'))
      if check_space(linha[0].encode('utf-8')) < 4:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))

  # - No que o sistema concluiu:
  for linha in cursor.execute("SELECT * FROM concl1"):
    if (expressao in linha[0].encode('utf-8') and expressao != linha[0].encode('utf-8') and expressao != linha[2].encode('utf-8')) or (expressao in linha[2].encode('utf-8') and expressao != linha[2].encode('utf-8') and expressao != linha[0].encode('utf-8')):
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 2 espaços
      if check_space(linha[2].encode('utf-8')) < 4 and linha[2].encode('utf-8').count(' ') != expressao:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))
      # conferir se a outra parte tem no máximo 4 espaços
      if check_space(linha[0].encode('utf-8')) < 4 and linha[0].encode('utf-8').count(' ') != expressao:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))

  # Os casos que faltaram: outros conectivos e expressao exata

  # - No que o usuário disse:
  for linha in cursor.execute("SELECT * FROM entra1"):
    if (expressao == linha[0].encode('utf-8')) and ((linha[1].encode('utf-8') != " é igual a ") and (linha[1].encode('utf-8') != " é um ") and (linha[1].encode('utf-8') != " é uma ") and linha[1].encode('utf-8') != " é um(a) "):
      #print "to aqui agora"
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      #print "frase:"+frase
      #print "expressao:"+expressao
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços
      if check_space(linha[2].encode('utf-8')) < 4 and linha[2].encode('utf-8') != expressao:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))
      if check_space(linha[0].encode('utf-8')) < 4 and linha[0].encode('utf-8') != expressao:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))
    if (expressao == linha[2].encode('utf-8')) and (linha[1].encode('utf-8') != " é igual a "):
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços
      #print check_space(linha[0].encode('utf-8'))
      if check_space(linha[2].encode('utf-8')) < 4 and linha[2].encode('utf-8') != expressao:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))
      if check_space(linha[0].encode('utf-8')) < 4 and linha[0].encode('utf-8') != expressao:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))

  # - No que o sistema concluiu:
  for linha in cursor.execute("SELECT * FROM concl1"):
    if expressao == linha[0].encode('utf-8') and (linha[1].encode('utf-8') != " é igual a " and linha[1].encode('utf-8') != " é um " and linha[1].encode('utf-8') != " é uma " and linha[1].encode('utf-8') != " é um(a) "):
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      if check_space(linha[0].encode('utf-8')) < 4 and linha[0].encode('utf-8') != expressao:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))
      if check_space(linha[2].encode('utf-8')) < 4 and linha[2].encode('utf-8') != expressao:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))
    if (expressao == linha[2].encode('utf-8')) and (linha[1].encode('utf-8') != " é igual a " and linha[1].encode('utf-8') != " é um " and linha[1].encode('utf-8') != " é uma "):
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Mais detalhes:")
      Checafrase(frase)
      # conferir se a outra parte tem no máximo 4 espaços pra ir pro 'ver mais'
      if check_space(linha[0].encode('utf-8')) < 4 and linha[0].encode('utf-8') != expressao:
        if linha[0].encode('utf-8') not in VerMais:
          VerMais.append(linha[0].encode('utf-8'))
      if check_space(linha[2].encode('utf-8')) < 4 and linha[2].encode('utf-8') != expressao:
        if linha[2].encode('utf-8') not in VerMais:
          VerMais.append(linha[2].encode('utf-8'))

  #print check_space("Isso é só um teste né")

  #print conceitos
  #print "frases:"
  #print frases

  for item in frases:
    print "- "+item
  del frases[:]
  print 


  # Buscando nas induções
  for linha in cursor.execute("SELECT * FROM indutivo"):
    if expressao in linha[0].encode('utf-8') or expressao in linha[2].encode('utf-8'):
      frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
      Checafrase("> Suspeitas:")
      Checafrase(frase)
  # Buscando com os sinônimos
  for sinonimo in sinonimos:
    for linha in cursor.execute("SELECT * FROM indutivo"):
      if sinonimo in linha[0].encode('utf-8') or sinonimo in linha[2].encode('utf-8'):
        frase = linha[0].encode('utf-8')+linha[1].encode('utf-8')+linha[2].encode('utf-8')
        Checafrase("> Suspeitas:")
        Checafrase(frase)

  # mostrando na tela o que achou:
  for item in frases:
    print "- "+item
  del frases[:]
  print 

  # Ver Mais
  ListaNaoSei = ["    "]
  del ListaNaoSei[:]
  if VerMais:
    #print "- Lista inicial do ver mais:"
    #print VerMais
    iVerMais = 0
    ContaNaoSei = 0
    for item in VerMais:
      achei = 0
      achei2 = 0
      #print "avaliando: "+item
      if iVerMais < 10:
        # conferindo se o tema proposto não é apenas um sinônimo do tema procurado
        AchaSinonimos(expressao)
        for sinonimo in sinonimos:
          if item == sinonimo:
            achei = 1
            #print item+" é um sinônimo de "+expressao
        # conferindo se há mais dados sobre o tema
        if ChecaMais(item) == 1:
          #print item+", tem mais coisas"
          # conferindo se o tema proposto já não está na lista definitiva
          for item2 in VerMais2:
            if item2 == item:
              #print item+" já está na lista 2"
              achei = 1
            # conferindo se o tema proposto não é apenas um sinônimo de um item q já está na lista definitiva
            AchaSinonimos(item)
            for sinonimo in sinonimos:
              if sinonimo == item2:
                #print item2+" é um sinônimo de "+item
                achei = 1
          if achei == 0:
            iVerMais = iVerMais + 1
            VerMais2.append(item)
        # Se não tem mais sobre o tema é pq precisa aprender mais sobre:
        else:
          if ContaNaoSei < 10:
            # conferindo se o tema proposto já não está na lista nao sei
            for item2 in ListaNaoSei:
              if item2 == item:
                #print item+" já está na lista 2"
                achei2 = 1
              # conferindo se o tema proposto não é apenas um sinônimo de um item q já está na lista nao sei
              AchaSinonimos(item)
              for sinonimo in sinonimos:
                if sinonimo == item2:
                  #print item2+" é um sinônimo de "+item
                  achei2 = 1
            if achei2 == 0:
              iVerMais = iVerMais + 1
              ListaNaoSei.append(item)

  # mostrando a lista final para o nao sei
  if ListaNaoSei:
    print "- > Preciso aprender mais sobre:"
    for item in ListaNaoSei:
      print " - "+item
    print




  # mostrando a lista final para o 'ver mais'
  if VerMais2:
    #print "- Lista final do ver mais:"
    #print VerMais2
    print "- > Ver Mais:"
    i = 0
    for item in VerMais2:
      i = i + 1
      print str(i)+". "+item

    #print VerMais2
    opcao=raw_input("Opção: ")
    if opcao == '1':
      del frases[:]
      BuscaSabe(VerMais2[0])
    if opcao == '2':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[1])
    if opcao == '3':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[2])
    if opcao == '4':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[3])
    if opcao == '5':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[4])
    if opcao == '6':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[5])
    if opcao == '7':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[6])
    if opcao == '8':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[7])
    if opcao == '9':
      del frases[:]
      #del VerMais[:]
      BuscaSabe(VerMais2[8])
    print 




# início do loop principal
while diga != "fui":
  diga = "oi"
  falei = 0
  #conn=sqlite3.connect('memoria.db')
  #cursor=conn.cursor()

  rndfive = randint(0, 2)
  if rndfive == 0 or rndfive == 1:
      palpite = 'desconfio que'
  if rndfive == 2:
      palpite = 'acho que'
#  if rndfive == 3:
#      palpite = 'suponho que'
#  if rndfive == 4:
#      palpite = 'penso que'
  # pegar a entrada do usuário:
  diga=raw_input("Diga: ")
  #.decode('utf-8')
  print " "


  
  # Formatação da entrada do usuário
  # Checa se o que foi digitado tem no mínimo 2 caracteres:
  i = len(diga) 
  if i <= 1:
    print "- Diga alguma coisa!"
    falei = 1
  else: 
    ## tirar o ponto final ou ponto de interrogação no final da frase se ele digitou
    if diga[-1] == "." or diga[-1] == "," or diga[-1] == "?" or diga[-1] == " " or diga[-1] == "'":
      diga = diga[0:i-1]
    ## Se o erro de digitação é na primeira coisa dita (1)
    if diga[0] == "." or diga[0] == "," or diga[0] == "?" or diga[0] == " " or diga[0] == "'":
      diga = diga[1:i]
    ## Se o usuário usou um artigo o ou a, O ou A ou digitou dois espaços em branco no começo (2)
    if i >= 2:
      if diga[:2] == "o " or diga[:2] == "a " or diga[:2] == "O " or diga[:2] == "A " or diga[:2] == "  ":
        diga = diga[2:i]
    ## Se o usuário usou um artigo um ou Um no inicio da frase (3) ! ! ! Cuidado! ele pode querer dizer um! só tira se vem com outras coisas junto!
    #if i >= 3:
      #if diga[:3] == "um " or diga[:3] == "Um " or diga[:3] == "   ":
        #diga = diga[3:i]
    ## Se o usuário usou um artigo uma, Uma, uns, Uns no inicio da frase (4)
    if i >= 4:
      if diga[:4] == "uma " or diga[:4] == "Uma " or diga[:4] == "uns " or diga[:4] == "Uns " or diga[:4] == "    ":
        diga = diga[4:i]
    ## Se o usuário usou um artigo uma, Uma, uns, Uns no inicio da frase
    if i >= 5:
      if diga[:5] == "umas " or diga[:5] == "Umas ":
        diga = diga[5:i]

    #print "vocẽ disse:",diga



  # raciocinar sobre a frase do usuário (pura sem considerar os conectivos)
  #raciocinio(diga)
  
  # evitar que tenha mais de um 'é' na frase
  if (diga.count(' é um ') >= 2):
    print "- Não consigo identificar frases que tenham mais de um ' é um '"
  
  elif 'pare de memorizar' == diga:   
    conn=sqlite3.connect(':memory:')
    cursor=conn.cursor()
    print "- OK! Não memorizarei as próximas frases ditas"
    falei = 1
    #Cria tabela de frases com relações que foram ditas pelo usuário
    cursor.execute("CREATE TABLE ENTRA1 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
    #Cria tabela de conclusões
    cursor.execute("CREATE TABLE CONCL1 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
    #Cria tabela para tudo que foi dito na sessão
    cursor.execute("CREATE TABLE dito1 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")
    #Cria tabela para tudo que foi dito alguma vez
    cursor.execute("CREATE TABLE dito2 (parte1 CHAR(100),conec CHAR(25),parte2 CHAR(100))")



  # +++++++++++++++++++++++++++++++++++++++++++++++++
  # + IDENTIFICANDO E GRAVANDO ENTRADAS DO USUARIO  +
  # +++++++++++++++++++++++++++++++++++++++++++++++++


  # Maior antes da menor

  # buscar conectivo 'não é o oposto de' na entrada e repartir em 2as partes:
  elif ' não é o oposto de ' in diga:
    parte1, parte2 = diga.split(' não é o oposto de ')
    conectivo = " não é o oposto de "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      # raciocinar sobre a frase do usuário
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  # buscar conectivo 'NÃO foi depois d' na entrada e repartir em 2as partes:
  elif ' não foi depois do ' in diga or ' não foi depois de ' in diga or ' não foi depois da ' in diga:
    if ' não foi depois de ' in diga:
      parte1, parte2 = diga.split(' não foi depois de ')
    elif ' não foi depois da ' in diga:
      parte1, parte2 = diga.split(' não foi depois da ')
    elif ' não foi depois do ' in diga:
      parte1, parte2 = diga.split(' não foi depois do ')
    conectivo = " não foi depois d"
    grava_dito1(parte1, conectivo, parte2)
    entendi = 1
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  # buscar conectivo 'NÃO foi antes d' na entrada e repartir em 2as partes:
  elif ' não foi antes do ' in diga or ' não foi antes de ' in diga or ' não foi antes da ' in diga:
    if ' não foi antes de ' in diga:
      parte1, parte2 = diga.split(' não foi antes de ')
    elif ' não foi antes da ' in diga:
      parte1, parte2 = diga.split(' não foi antes da ')
    elif ' não foi antes do ' in diga:
      parte1, parte2 = diga.split(' não foi antes do ')
    conectivo = " não foi antes d"
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' é o oposto de ' in diga:
    parte1, parte2 = diga.split(' é o oposto de ')
    conectivo = " é o oposto de "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  # buscar conectivo ' foi depois d' na entrada e repartir em 2as partes:
  elif ' foi depois do ' in diga or ' foi depois de ' in diga or ' foi depois da ' in diga:
    if ' foi depois de ' in diga:
      parte1, parte2 = diga.split(' foi depois de ')
    elif ' foi depois da ' in diga:
      parte1, parte2 = diga.split(' foi depois da ')
    elif ' foi depois do ' in diga:
      parte1, parte2 = diga.split(' foi depois do ')
    conectivo = " foi depois d"
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  # buscar conectivo ' foi antes d' na entrada e repartir em 2as partes:
  elif ' foi antes do ' in diga or ' foi antes de ' in diga or ' foi antes da ' in diga:
    if ' foi antes de ' in diga:
      parte1, parte2 = diga.split(' foi antes de ')
    elif ' foi antes da ' in diga:
      parte1, parte2 = diga.split(' foi antes da ')
    elif ' foi antes do ' in diga:
      parte1, parte2 = diga.split(' foi antes do ')
    conectivo = " foi antes d"
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' não é igual a ' in diga:
    parte1, parte2 = diga.split(' não é igual a ')
    conectivo = " não é igual a "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' não é uma ' in diga:
    parte1, parte2 = diga.split(' não é uma ')
    conectivo = " não é uma "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' não é um ' in diga:
    parte1, parte2 = diga.split(' não é um ')
    conectivo = " não é um "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' é igual a ' in diga:
    parte1, parte2 = diga.split(' é igual a ')
    conectivo = " é igual a "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' é uma ' in diga:
    parte1, parte2 = diga.split(' é uma ')
    conectivo = " é uma "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' é um ' in diga:
    parte1, parte2 = diga.split(' é um ')
    conectivo = " é um "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' não tem ' in diga:
    parte1, parte2 = diga.split(' tem ')
    conectivo = " não tem "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1

  elif ' tem ' in diga:
    parte1, parte2 = diga.split(' tem ')
    conectivo = " tem "
    entendi = 1
    grava_dito1(parte1, conectivo, parte2)
    contra = buscaerro(parte1,conectivo,parte2)
    if contra != 1:
      grava_na_memoria(parte1,conectivo,parte2)
      raciocinio(parte1)
      raciocinio(parte2)
    else:
        falei = 1



  # Raciocinando sobre cada palavra dita pelo usuário
  if ' ' in diga and falei != 1:
    palavras = diga.split(' ')
    for palavra in palavras:
      #print "item para pensar: "+palavra
      raciocinio(palavra)
      rindutivo(palavra)


  # Identificando blocos conhecidos e raciocinando sobre eles
  # e Raciocinando em cima de sinônimos de blocos conhecidos (não importa mais se é sinônimo)
  # buscando blocos conhecidos no que foi dito
  for linha in cursor.execute("SELECT * FROM entra1"):
    if linha[0].encode('utf-8') in diga:
      raciocinio(linha[0].encode('utf-8'))
      #if " é igual a " == linha[1].encode('utf-8'):
      raciocinio(linha[2].encode('utf-8'))
    if linha[2].encode('utf-8') in diga:
      raciocinio(linha[2].encode('utf-8'))
      #if " é igual a " == linha[1].encode('utf-8'):
      raciocinio(linha[0].encode('utf-8'))


  # ++++++++++++++++++++++++
  # + PERGUNTAS DO USUARIO +
  # ++++++++++++++++++++++++

  #conn=sqlite3.connect('memoria.db')
  #cursor=conn.cursor()

  #imprime o que o usuário disse sobre a expressão 
  if 'que eu disse sobre ' in diga:
    entendi = 1
    pontos = 0
    sei = 0
    conector = "   "
    conector2 = "   "
    diga1,diga2 = diga.split('que eu disse sobre ')
    for linha in cursor.execute("SELECT * FROM entra1"):

      # buscando a expressão na parte1
      if diga2 == linha[0].encode('utf-8') or " "+diga2+" " in " "+linha[0].encode('utf-8') or " "+diga2+" " in linha[0].encode('utf-8')+" " or diga2+"s" == linha[0].encode('utf-8') or " "+diga2+"s"+" " in " "+linha[0].encode('utf-8') or " "+diga2+"s"+" " in linha[0].encode('utf-8')+" ":
	conector = linha[1].encode('utf-8')
  	if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
	  conector2 = conector+"o(a) "
	else:
	  conector2 = conector
        print " - ",linha[0].encode('utf-8')+conector2+linha[2].encode('utf-8')
        pontos = pontos + 1
        falei = 1
        sei = 1

      # buscando a expressão na parte2
      elif diga2 == linha[2].encode('utf-8') or " "+diga2+" " in " "+linha[2].encode('utf-8') or " "+diga2+" " in linha[2].encode('utf-8')+" " or diga2+"s" == linha[2].encode('utf-8') or " "+diga2+"s"+" " in " "+linha[2].encode('utf-8') or " "+diga2+"s"+" " in linha[2].encode('utf-8')+" ":
	conector = linha[1].encode('utf-8')
	if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
	  conector2 = conector+"o(a) "
	else:
	  conector2 = conector
        print " - ",linha[0].encode('utf-8')+conector2+linha[2].encode('utf-8')
        pontos = pontos + 1
        falei = 1
        sei = 1

    # Se não encontra a expressão
    if sei == 0:
      print " - você não disse nada sobre isso"
      falei = 1

    # Imprimindo a pontuação
    if pontos > 0:
      print " "
      print "(Assunto: "+diga2+" Pontos: ",pontos,")"



  #imprime o que concluiu sobre a expressão 
  elif 'que concluiu sobre ' in diga:
    entendi = 1
    pontos = 0
    sei = 0
    conector = "   "
    conector2 = "   "
    diga1,diga2 = diga.split('que concluiu sobre ')

    # Busca nas categorias femininas
    for linha in cursor.execute("SELECT * FROM concl1"):
      if " "+diga2 in linha[0].encode('utf-8') or diga2 == linha[0].encode('utf-8') or " "+diga2 in " "+linha[0].encode('utf-8'):
	conector = linha[1].encode('utf-8')
	if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
	  conector2 = conector+"o(a) "
	else:
	  conector2 = conector
        print " - ",linha[0].encode('utf-8')+conector2+linha[2].encode('utf-8')
        pontos = pontos + 1
        falei = 1
        sei = 1
      elif " "+diga2 in linha[2].encode('utf-8') or diga2 == linha[2].encode('utf-8') or " "+diga2 in " "+linha[2].encode('utf-8'):
	conector = linha[1].encode('utf-8')
	if conector == " foi antes d" or conector == " foi depois d" or conector == " não foi antes d" or conector == " não foi depois d":
	  conector2 = conector+"o(a) "
	else:
	  conector2 = conector
        print " - ",linha[0].encode('utf-8')+conector2+linha[2].encode('utf-8')
        pontos = pontos + 1
        falei = 1
        sei = 1

    if sei == 0:
      print " - não consegui concluir nada sobre isso"
      falei = 1

    if pontos > 0:
      print " "
      print "(Assunto: "+diga2+" Pontos: ",pontos,")"




  #imprime o que é x
  elif 'qual o significado de ' in diga:
    entendi = 1
    sei = 0
    conector = "   "
    conector2 = "   "
    diga1,diga2 = diga.split('qual o significado de ')

    # Busca nas conclusões
    for linha in cursor.execute("SELECT * FROM concl1"):
      if diga2 == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')):
	conector = linha[1].encode('utf-8')
        print " - ",linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        falei = 1
        sei = 1
      elif (diga2 == linha[0].encode('utf-8') or diga2 == linha[2].encode('utf-8')) and " é igual a " == linha[1].encode('utf-8'):
	conector = linha[1].encode('utf-8')
        print " - ",linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        falei = 1
        sei = 1

    # Busca nas falas do usuário
    for linha in cursor.execute("SELECT * FROM entra1"):
      if diga2 == linha[0].encode('utf-8') and (" é um " == linha[1].encode('utf-8') or " é uma " == linha[1].encode('utf-8')):
	conector = linha[1].encode('utf-8')
        print " - ",linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        falei = 1
        sei = 1
      elif (diga2 == linha[0].encode('utf-8') or diga2 == linha[2].encode('utf-8')) and " é igual a " == linha[1].encode('utf-8'):
	conector = linha[1].encode('utf-8')
        print " - ",linha[0].encode('utf-8')+conector+linha[2].encode('utf-8')
        falei = 1
        sei = 1

    if sei == 0:
      print " - ainda não sei isso"
      falei = 1



  #imprime o que sabe sobre a expressão 
  elif 'que sabe sobre ' in diga:
    pontos = 0
    sei = 0
    sei2 = 0
    conector = "   "
    conector2 = "   "
    diga1,diga2 = diga.split('que sabe sobre ')


    BuscaSabe(diga2)
    falei = 1



  # +++++++++++++++++++++
  # + RESPOSTA GENÉRICA +
  # +++++++++++++++++++++

  # Buscando uma resposta para o que o usuário disse
  if diga != "fui" and falei == 0:
    buscaresposta(diga)
    if falei == 1:
      print " "

  print " "

shutil.copyfile("/sdcard/memoria.db","/sdcard/memoria2.db")

# confirma os dados para o banco de dados e fecha o banco de dados
cursor.close()
conn.close()      
exit

# Copyleft 2012, 2021 Carlos Adrian Rupp
